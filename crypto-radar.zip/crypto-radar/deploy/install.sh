#!/usr/bin/env bash
# One-command install for a fresh Ubuntu server (EC2, Lightsail, or any VPS).
#
#   sudo bash deploy/install.sh
#
# Safe to re-run: it will not overwrite an existing /etc/radar.env or database.
set -euo pipefail

say() { printf '\n\033[1m==> %s\033[0m\n' "$1"; }
die() { printf '\n\033[31mSTOP: %s\033[0m\n' "$1" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Run this with sudo:  sudo bash deploy/install.sh"

say "Step 1 of 6 — checking this server can reach Binance"
CODE=$(curl -s --max-time 15 -o /dev/null -w '%{http_code}' \
        https://fapi.binance.com/fapi/v1/ping || echo "000")
case "$CODE" in
  200) echo "    OK - Binance answered normally." ;;
  451) die "Binance blocks this server's location (HTTP 451).
     You almost certainly launched the instance in a US region.
     Terminate it and launch a new one in Mumbai (ap-south-1),
     Singapore (ap-southeast-1) or Tokyo (ap-northeast-1).
     Nothing else here will work until you do." ;;
  000) die "No internet from this server, or Binance is unreachable.
     Check the server has outbound internet access and try again." ;;
  *)   die "Binance returned HTTP $CODE, which is unexpected. Try again in a few minutes." ;;
esac

say "Step 2 of 6 — installing Python"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip sqlite3 curl
echo "    OK - $(python3 --version) on $(uname -m)"

say "Step 3 of 6 — creating the application user and folders"
id -u radar &>/dev/null || useradd --system --home /opt/radar --shell /usr/sbin/nologin radar
mkdir -p /opt/radar/data
cd /opt/radar
[ -f main.py ] || die "The code is not in /opt/radar.
     Upload it there first, then run this script again from /opt/radar."
echo "    OK"

say "Step 4 of 6 — installing dependencies (takes 2-4 minutes, this is normal)"
python3 -m venv .venv
./.venv/bin/pip install --upgrade pip -q
./.venv/bin/pip install -r requirements.txt -q
chown -R radar:radar /opt/radar
echo "    OK"

say "Step 5 of 6 — writing configuration"
if [ -f /etc/radar.env ]; then
  echo "    /etc/radar.env already exists — leaving it alone."
  PW="(unchanged — see /etc/radar.env)"
else
  cp deploy/radar.env.example /etc/radar.env
  PW=$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
  sed -i "s|^RADAR_PASSWORD=.*|RADAR_PASSWORD=${PW}|" /etc/radar.env
  chmod 600 /etc/radar.env
  echo "    OK — generated a password"
fi

say "Step 6 of 6 — starting the service"
cp deploy/radar.service /etc/systemd/system/radar.service
systemctl daemon-reload
systemctl enable --now radar >/dev/null 2>&1
sleep 5

if systemctl is-active --quiet radar; then
  IP=$(curl -s --max-time 5 https://checkip.amazonaws.com || echo "YOUR-SERVER-IP")
  cat <<MSG

  ============================================================
   Running.

   Open in your browser:   http://${IP}:8080
   Username:               radar
   Password:               ${PW}

   The first scan takes about a minute. Until it finishes the
   page will say so rather than showing anything.
  ============================================================

  Useful later:
    sudo systemctl restart radar      restart it
    sudo journalctl -u radar -f       watch what it is doing (Ctrl-C to exit)

MSG
else
  echo
  echo "  The service did not start. The error is below:"
  echo
  journalctl -u radar --no-pager --lines=25
  exit 1
fi
