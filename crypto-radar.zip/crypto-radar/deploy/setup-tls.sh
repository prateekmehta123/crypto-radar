#!/usr/bin/env bash
# Put the dashboard on a real domain with HTTPS.
#
#   sudo bash deploy/setup-tls.sh metazeuscrypto.com
#   sudo bash deploy/setup-tls.sh metazeuscrypto.com www.metazeuscrypto.com
#
# Safe to re-run. Checks DNS before touching anything, because certbot failing
# on a domain that does not resolve yet is the most common way this goes wrong.
set -euo pipefail

say()  { printf '\n\033[1m==> %s\033[0m\n' "$1"; }
die()  { printf '\n\033[31mSTOP: %s\033[0m\n' "$1" >&2; exit 1; }
warn() { printf '\033[33m    %s\033[0m\n' "$1"; }

[ "$(id -u)" -eq 0 ] || die "Run with sudo:  sudo bash deploy/setup-tls.sh yourdomain.com"
[ $# -ge 1 ] || die "Give me the domain:  sudo bash deploy/setup-tls.sh metazeuscrypto.com"

PRIMARY="$1"
DOMAINS=("$@")
CERT_ARGS=()
for d in "${DOMAINS[@]}"; do CERT_ARGS+=(-d "$d"); done

say "Step 1 of 6 — checking DNS points here"
MYIP=$(curl -s --max-time 10 https://checkip.amazonaws.com || echo "")
[ -n "$MYIP" ] || die "Could not determine this server's public IP."
echo "    this server: $MYIP"

apt-get install -y -qq dnsutils >/dev/null 2>&1 || true
BAD=0
for d in "${DOMAINS[@]}"; do
  RES=$(dig +short "$d" A @1.1.1.1 | tail -1)
  if [ -z "$RES" ]; then
    warn "$d does not resolve yet"; BAD=1
  elif [ "$RES" != "$MYIP" ]; then
    warn "$d resolves to $RES, not $MYIP"; BAD=1
  else
    echo "    $d -> $RES  OK"
  fi
done
if [ "$BAD" = "1" ]; then
  die "DNS is not ready.
     At your domain registrar, create an A record for each name above
     pointing at $MYIP, then wait and re-run this script.
     Changes can take anywhere from 2 minutes to a few hours."
fi

say "Step 2 of 6 — checking ports 80 and 443 are reachable"
warn "If this hangs or the certificate step fails later, open 80 and 443"
warn "to 0.0.0.0/0 in the EC2 security group. Let's Encrypt must reach"
warn "port 80 from the outside to prove you own the domain."

say "Step 3 of 6 — installing nginx and certbot"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq nginx certbot python3-certbot-nginx
echo "    OK"

say "Step 4 of 6 — configuring nginx for $PRIMARY"
SERVER_NAMES="${DOMAINS[*]}"
cat > /etc/nginx/sites-available/radar <<NGINX
limit_req_zone \$binary_remote_addr zone=radar:10m rate=60r/m;

server {
    listen 80;
    server_name ${SERVER_NAMES};
    location / { proxy_pass http://127.0.0.1:8080; proxy_set_header Host \$host; }
}
NGINX
rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/radar /etc/nginx/sites-enabled/radar
nginx -t >/dev/null 2>&1 || die "nginx config rejected -- run 'nginx -t' to see why"
systemctl reload nginx
echo "    OK"

say "Step 5 of 6 — requesting the certificate"
if certbot --nginx "${CERT_ARGS[@]}" --non-interactive --agree-tos \
     --register-unsafely-without-email --redirect; then
  echo "    OK — HTTPS is live, and renewal is automatic"
else
  die "Certificate request failed.
     Most likely cause: port 80 is not open to the internet in the
     EC2 security group. Open it and re-run this script."
fi

# harden the TLS vhost certbot just wrote
if ! grep -q "Strict-Transport-Security" /etc/nginx/sites-available/radar; then
  sed -i "/listen 443/a \\
    add_header Strict-Transport-Security \"max-age=31536000\" always;\\
    add_header X-Content-Type-Options nosniff always;\\
    add_header X-Frame-Options DENY always;\\
    add_header Referrer-Policy no-referrer always;\\
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;\\
    proxy_set_header X-Forwarded-Proto \$scheme;" /etc/nginx/sites-available/radar
  nginx -t >/dev/null 2>&1 && systemctl reload nginx
fi

say "Step 6 of 6 — moving the app behind nginx"
if grep -q '^HOST=' /etc/radar.env; then
  sed -i 's|^HOST=.*|HOST=127.0.0.1|' /etc/radar.env
else
  echo "HOST=127.0.0.1" >> /etc/radar.env
fi
systemctl restart radar
sleep 4

if curl -sk "https://${PRIMARY}/healthz" -o /dev/null -w '%{http_code}' | grep -qE '200|503'; then
  cat <<MSG

  ============================================================
   Live at  https://${PRIMARY}

   Username: radar
   Password: (unchanged — sudo grep RADAR_PASSWORD /etc/radar.env)

   Your password is now encrypted in transit, which it was not
   over plain HTTP.
  ============================================================

  Last step, in the EC2 console:
    - keep 80 and 443 open to 0.0.0.0/0
    - REMOVE the port 8080 rule entirely

  The app now listens on loopback only, so 8080 is unreachable from
  outside regardless -- but removing the rule keeps things tidy and
  means you stop chasing your home IP when it changes.

MSG
else
  warn "Site is up but /healthz did not answer as expected."
  warn "Check:  sudo journalctl -u radar -n 30 --no-pager"
fi
