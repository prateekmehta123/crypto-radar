"""
Web API + background scanner.

Deliberately built on the standard library. This serves five read-only GET
endpoints and one static file to a single user polling every 20 seconds;
FastAPI and uvicorn would add two install-time dependencies and buy nothing
here. ThreadingHTTPServer handles concurrent reads fine at this scale.

The scan loop runs in a daemon thread and publishes its latest result into
memory; handlers only ever read that snapshot. Requests never trigger a scan,
so opening ten tabs cannot stampede the Binance rate limiter.

Endpoints
    GET /                    dashboard
    GET /api/latest          most recent scan (full)
    GET /api/symbol/{sym}    one symbol's candidate detail
    GET /api/whales          on-chain events from the last cycle
    GET /api/history         recorded signals from SQLite
    GET /healthz             liveness + staleness; 503 when stale
"""

from __future__ import annotations

import json
import logging
import math
import os
import threading
import time
import base64
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, urlparse

from .analyze import DEFAULT_TFS, TIMEFRAMES, Analyzer
from .client import BinanceFutures, GeoBlockedError
from .onchain import ArkhamClient, WhaleTracker
from .scan import scan_once
from .store import Store

log = logging.getLogger("radar.api")

WEB_DIR = Path(__file__).resolve().parent.parent / "web"

# HTTP Basic credentials. Unset means no auth, which is only safe on loopback --
# serve() refuses to bind a public interface without them.
AUTH_USER = os.environ.get("RADAR_USER", "radar")
AUTH_PASS = os.environ.get("RADAR_PASSWORD", "")


def _auth_ok(header: Optional[str]) -> bool:
    if not AUTH_PASS:
        return True
    if not header or not header.startswith("Basic "):
        return False
    try:
        user, _, pw = base64.b64decode(header[6:]).decode().partition(":")
    except Exception:                                     # noqa: BLE001
        return False
    # compare_digest on both halves so neither is a timing oracle
    return (hmac.compare_digest(user, AUTH_USER)
            and hmac.compare_digest(pw, AUTH_PASS))


def _jsonable(o: Any) -> Any:
    """Convert a payload into something strictly JSON-serialisable.

    Handles the two things that reach here from pandas/numpy and break a
    browser: non-finite floats (NaN, inf) become null, and numpy scalar types
    become their Python equivalents.
    """
    if o is None or isinstance(o, (str, bool, int)):
        return o
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set)):
        return [_jsonable(v) for v in o]
    # numpy scalars and anything else exposing .item()
    item = getattr(o, "item", None)
    if callable(item):
        try:
            return _jsonable(item())
        except Exception:                                 # noqa: BLE001
            pass
    if isinstance(o, (bytes, bytearray)):
        return o.decode("utf-8", "replace")
    return str(o)


def env_f(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def env_i(name: str, default: int) -> int:
    try:
        return int(float(os.environ.get(name, default)))
    except (TypeError, ValueError):
        return default


class ScannerService:
    """Owns the scan loop and the latest snapshot."""

    def __init__(self) -> None:
        self.store = Store(os.environ.get("RADAR_DB", "radar.db"))
        self.client = BinanceFutures()
        ark = ArkhamClient()
        self.whales: Optional[WhaleTracker] = (
            WhaleTracker(ark, store=self.store,
                         usd_gte=env_f("WHALE_MIN_USD", 1_000_000),
                         dormancy_days=env_f("DORMANCY_DAYS", 180),
                         dormancy_min_usd=env_f("DORMANCY_MIN_USD", 5_000_000))
            if ark.enabled else None)

        # On-demand analysis shares the scanner's client, so its rate limiter
        # covers both and a burst of searches cannot starve the scan loop.
        self.analyzer = Analyzer(self.client, ttl_s=env_f("ANALYSIS_TTL_S", 60))

        self.interval_s = env_i("SCAN_INTERVAL_S", 300)
        self.latest: Optional[Dict[str, Any]] = None
        self.status: Dict[str, Any] = {
            "state": "starting", "last_ok_ms": None, "last_error": None,
            "consecutive_failures": 0, "cycles": 0,
            "onchain": self.whales is not None,
        }
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------- lifecycle

    def start(self) -> None:
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="scanner")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            t0 = time.time()
            try:
                res = scan_once(
                    self.client, self.store,
                    interval=os.environ.get("KLINE_INTERVAL", "15m"),
                    top_n=env_i("TOP_N", 150),
                    deriv_top=env_i("DERIV_TOP", 60),
                    min_quote_vol=env_f("MIN_QUOTE_VOL", 30e6),
                    min_conviction=env_f("SCAN_MIN_CONVICTION", 0.15),
                    atr_mult=env_f("ATR_MULT", 1.5),
                    account_risk_pct=env_f("ACCOUNT_RISK_PCT", 0.5),
                    whales=self.whales,
                )
                with self._lock:
                    self.latest = res
                    self.status.update(state="ok", last_ok_ms=res["generated_at"],
                                       last_error=None, consecutive_failures=0,
                                       cycles=self.status["cycles"] + 1)
                log.info("cycle ok: %d candidates in %ss",
                         len(res["candidates"]), res["elapsed_s"])

            except GeoBlockedError as e:
                # Unrecoverable here -- keep serving so the dashboard can say why.
                with self._lock:
                    self.status.update(state="geo_blocked", last_error=str(e))
                log.error("%s", e)
                self._stop.wait(600)
                continue

            except Exception as e:                        # noqa: BLE001
                with self._lock:
                    n = self.status["consecutive_failures"] + 1
                    self.status.update(state="error",
                                       last_error=f"{type(e).__name__}: {e}",
                                       consecutive_failures=n)
                log.exception("cycle failed")

            wait = max(5.0, self.interval_s - (time.time() - t0))
            with self._lock:
                fails = self.status["consecutive_failures"]
            if fails:
                wait = min(wait * (1.5 ** min(fails, 6)), 1800)
            self._stop.wait(wait)

    # ---------------------------------------------------------------- reads

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {"status": dict(self.status),
                    "interval_s": self.interval_s,
                    "result": self.latest}

    # ------------------------------------------------------------- routing

    def route(self, path: str, query: Dict[str, list]):
        """Return (status, content_type, body_bytes)."""
        if path in ("/", "/index.html"):
            f = WEB_DIR / "index.html"
            if not f.exists():
                return 500, "text/plain", b"web/index.html is missing from the deployment"
            return 200, "text/html; charset=utf-8", f.read_bytes()

        if path == "/api/latest":
            return self._json(200, self.snapshot())

        if path.startswith("/api/symbol/"):
            sym = path.rsplit("/", 1)[-1].upper()
            res = self.snapshot().get("result") or {}
            for c in res.get("candidates", []):
                if c["symbol"].upper() == sym:
                    return self._json(200, c)
            return self._json(404, {"error": f"{sym} is not in the current candidate list"})

        if path == "/api/whales":
            res = self.snapshot().get("result") or {}
            return self._json(200, {"events": res.get("whale_events", []),
                                    "generated_at": res.get("generated_at")})

        if path == "/api/history":
            try:
                limit = max(1, min(int(query.get("limit", ["200"])[0]), 2000))
            except ValueError:
                limit = 200
            df = self.store.signals_df().tail(limit)
            return self._json(200, {"signals": df.to_dict("records")})

        if path == "/api/analyze":
            sym = (query.get("symbol") or [""])[0].strip()
            if not sym:
                return self._json(400, {"error": "pass ?symbol=BTCUSDT"})
            tf_arg = (query.get("tf") or [""])[0].strip()
            tfs = [t for t in tf_arg.split(",") if t] or None
            try:
                return self._json(200, self.analyzer.analyse(sym, tfs))
            except KeyError as e:
                return self._json(404, {"error": str(e).strip("\'\"")})
            except Exception as e:                        # noqa: BLE001
                log.exception("analysis failed")
                return self._json(502, {"error": f"{type(e).__name__}: {e}"})

        if path == "/api/symbols":
            q = (query.get("q") or [""])[0]
            return self._json(200, {"matches": self.analyzer.suggest(q)})

        if path == "/api/timeframes":
            return self._json(200, {"order": DEFAULT_TFS,
                                    "labels": {k: v["label"] for k, v in TIMEFRAMES.items()}})

        if path == "/healthz":
            s = self.snapshot()["status"]
            age = None
            if s["last_ok_ms"]:
                age = round((time.time() * 1000 - s["last_ok_ms"]) / 1000)
            stale = age is None or age > self.interval_s * 3
            code = 503 if (stale or s["state"] == "geo_blocked") else 200
            return self._json(code, {
                "state": s["state"], "seconds_since_last_scan": age,
                "stale": stale, "cycles": s["cycles"],
                "consecutive_failures": s["consecutive_failures"],
                "last_error": s["last_error"]})

        return self._json(404, {"error": "no such endpoint"})

    @staticmethod
    def _json(code: int, payload: Any):
        # allow_nan=False is the point here. Python's json module writes bare
        # NaN / Infinity by default, which is NOT valid JSON -- Python's own
        # parser accepts them, but every browser's JSON.parse rejects the
        # response outright. The feature frames are full of NaN wherever data
        # is unavailable, so this reaches the wire constantly.
        body = json.dumps(_jsonable(payload), allow_nan=False,
                          default=str).encode()
        return code, "application/json; charset=utf-8", body


svc = ScannerService()


class Handler(BaseHTTPRequestHandler):
    server_version = "radar/1.0"
    protocol_version = "HTTP/1.1"

    def do_GET(self) -> None:                             # noqa: N802
        u = urlparse(self.path)

        # /healthz stays open so load balancers and uptime monitors can reach it
        # without holding credentials. It exposes no market data.
        if u.path != "/healthz" and not _auth_ok(self.headers.get("Authorization")):
            body = b'{"error":"authentication required"}'
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="radar", charset="UTF-8"')
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        try:
            code, ctype, body = svc.route(u.path, parse_qs(u.query))
        except Exception as e:                            # noqa: BLE001
            log.exception("handler error")
            code, ctype, body = 500, "application/json", json.dumps(
                {"error": f"{type(e).__name__}: {e}"}).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args) -> None:       # quieter access log
        log.debug(fmt, *args)


def serve(host: str = "0.0.0.0", port: int = 8080) -> None:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    public = host not in ("127.0.0.1", "localhost", "::1")
    if public and not AUTH_PASS:
        # Refusing here rather than warning: on a public IP this would publish
        # your positioning and levels to anyone who scans the port, and the
        # failure is silent until someone finds it.
        raise SystemExit(
            "Refusing to bind %s without authentication.\n"
            "Set RADAR_PASSWORD (and optionally RADAR_USER), or bind to "
            "127.0.0.1 and reach it over an SSH tunnel:\n"
            "    ssh -N -L 8080:localhost:8080 user@host" % host)
    if not public:
        log.info("local only -- open http://localhost:%d in your browser "
                 "(set HOST=0.0.0.0 plus RADAR_PASSWORD to expose it)", port)

    svc.start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    log.info("dashboard on http://%s:%d", host, port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        svc.stop()
        httpd.server_close()
