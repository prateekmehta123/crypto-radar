"""
Optional ML layer.

This is where an actual *probability* can come from -- P(target hit before
stop) -- because it is fitted on labelled outcomes and then calibration-checked.

Two guards that matter more than the model choice:

* **Purged, embargoed splits.** A trade opened at bar t stays open for up to
  `max_bars`. If bar t is in train and t+10 is in test, the label leaks. Every
  fold purges overlapping samples and embargoes a buffer after the split.

* **Calibration, not just AUC.** A model with 0.60 AUC and honest probabilities
  is tradeable; a model with 0.68 AUC that says 80% when it means 55% is not.
  The reliability table is printed on every run -- read it before the AUC.

Even with both, treat the output as one input among several. Crypto regimes
shift faster than a fitted model adapts, which is why walk-forward OOS in
backtest.py is the real check and this is a refinement on top of it.
"""

from __future__ import annotations

import argparse
import json
import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import brier_score_loss, roc_auc_score

log = logging.getLogger("radar.model")

FEATURE_COLS = [
    "ema20_dist", "ema50_dist", "ema200_dist", "ema_stack", "vwap_dist",
    "ret_1h", "ret_4h", "ret_24h", "rsi14",
    "atr_pct", "atr_expansion", "bb_width", "bb_squeeze_pctile", "realized_vol",
    "vol_z", "taker_buy_ratio", "delta_norm", "cvd_slope_1h", "cvd_slope_4h",
    "cvd_price_divergence",
    "dist_swing_high", "dist_swing_low", "broke_swing_high", "broke_swing_low",
    "poc_dist", "in_value_area", "liq_up_dist", "liq_dn_dist",
    "rs_1h", "rs_4h", "rs_24h", "btc_beta", "btc_corr",
    "funding", "funding_z_7d", "funding_cum_24h",
    "oi_chg_1h", "oi_chg_4h", "oi_z_24h",
    "taker_ls_ratio", "top_pos_ls_ratio",
]


def label_barriers(df: pd.DataFrame, feats: pd.DataFrame, direction: str,
                   atr_mult: float, tp_mult: float, max_bars: int) -> pd.DataFrame:
    """Label every bar: did a `direction` trade opened next bar hit TP first?"""
    idx = feats.index
    o = df["open"].reindex(idx).values
    hi = df["high"].reindex(idx).values
    lo = df["low"].reindex(idx).values
    a = feats["atr"].values
    n = len(idx)
    y = np.full(n, np.nan)
    bars = np.full(n, np.nan)
    long = direction == "LONG"

    for i in range(n - 1):
        entry, risk = o[i + 1], atr_mult * a[i]
        if not np.isfinite(entry) or not np.isfinite(risk) or risk <= 0:
            continue
        stop = entry - risk if long else entry + risk
        tp = entry + tp_mult * risk if long else entry - tp_mult * risk
        for j in range(i + 1, min(i + 1 + max_bars, n)):
            hit_stop = (lo[j] <= stop) if long else (hi[j] >= stop)
            hit_tp = (hi[j] >= tp) if long else (lo[j] <= tp)
            if hit_stop:                     # pessimistic on same-bar ties
                y[i], bars[i] = 0.0, j - i
                break
            if hit_tp:
                y[i], bars[i] = 1.0, j - i
                break
        else:
            y[i], bars[i] = 0.0, max_bars    # timeout counts as no-win
    return pd.DataFrame({"y": y, "hold_bars": bars}, index=idx)


def assemble(panel: Dict[str, dict], direction: str, atr_mult: float,
             tp_mult: float, max_bars: int) -> pd.DataFrame:
    parts = []
    for sym, d in panel.items():
        f, df = d["feats"], d["df"]
        lab = label_barriers(df, f, direction, atr_mult, tp_mult, max_bars)
        X = f.reindex(columns=[c for c in FEATURE_COLS if c in f.columns]).copy()
        X["symbol"] = sym
        X["y"] = lab["y"]
        X["hold_bars"] = lab["hold_bars"]
        parts.append(X.dropna(subset=["y"]))
    out = pd.concat(parts).sort_index()
    return out


def purged_splits(index: pd.DatetimeIndex, n_splits: int, max_bars: int,
                  bar_ms: int, embargo_frac: float = 0.01):
    """Time-ordered splits that purge label-overlapping train samples."""
    times = index.values
    n = len(times)
    fold = n // (n_splits + 1)
    horizon = np.timedelta64(max_bars * bar_ms, "ms")
    embargo = int(n * embargo_frac)
    for k in range(n_splits):
        tr_end = fold * (k + 1)
        te_start, te_end = tr_end + embargo, min(fold * (k + 2), n)
        if te_start >= te_end:
            continue
        te_begin_time = times[te_start]
        # purge: drop train rows whose label window reaches into the test set
        train_mask = np.zeros(n, dtype=bool)
        train_mask[:tr_end] = True
        train_mask &= (times + horizon) < te_begin_time
        test_mask = np.zeros(n, dtype=bool)
        test_mask[te_start:te_end] = True
        yield np.where(train_mask)[0], np.where(test_mask)[0]


def reliability_table(y: np.ndarray, p: np.ndarray, bins: int = 10) -> pd.DataFrame:
    edges = np.linspace(0, 1, bins + 1)
    b = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    rows = []
    for k in range(bins):
        m = b == k
        if m.sum() < 10:
            continue
        rows.append({"bucket": f"{edges[k]:.1f}-{edges[k+1]:.1f}",
                     "n": int(m.sum()),
                     "predicted": round(float(p[m].mean()), 3),
                     "actual": round(float(y[m].mean()), 3)})
    return pd.DataFrame(rows)


def usable_features(data: pd.DataFrame) -> Tuple[List[str], Dict[str, str]]:
    """Select feature columns, dropping ones that carry no information.

    This matters more than it looks. build_panel() sets the OI columns to NaN
    for any backtest longer than 30 days, because that history does not exist.
    HistGradientBoosting tolerates NaN natively, so training silently succeeds
    and the model learns "oi_chg_1h is always missing".

    At inference the live scanner DOES populate those columns. The model would
    then be served real numbers in columns it only ever saw as absent -- train/
    serve skew, with no error raised and no obvious symptom beyond predictions
    that are quietly worse than the CV numbers promised.

    So: drop them once, use the same list for CV, the final fit, and inference,
    and record why each was dropped.
    """
    dropped: Dict[str, str] = {}
    keep: List[str] = []
    for c in FEATURE_COLS:
        if c not in data.columns:
            dropped[c] = "not present in panel"
            continue
        col = data[c].astype(float)
        n_valid = int(col.notna().sum())
        if n_valid == 0:
            dropped[c] = "all NaN (no history for this feature)"
        elif n_valid < max(50, 0.01 * len(col)):
            dropped[c] = f"too sparse ({n_valid} valid of {len(col)})"
        elif float(col.std(ddof=0)) == 0.0 or col.nunique(dropna=True) <= 1:
            dropped[c] = "zero variance"
        else:
            keep.append(c)
    return keep, dropped


def check_inference_features(feats: pd.Series, trained_cols: List[str],
                             dropped: Optional[Dict[str, str]] = None) -> List[str]:
    """Validate a live feature row against what the model was trained on.

    Returns a list of warnings. Call this before predicting -- a silent skew is
    the failure mode this whole module is trying to avoid.
    """
    warns = []
    for c in trained_cols:
        if c not in feats.index or not np.isfinite(float(feats.get(c, np.nan))):
            warns.append(f"{c}: trained on it, missing at inference")
    for c, why in (dropped or {}).items():
        if "all NaN" in why and c in feats.index and np.isfinite(float(feats.get(c, np.nan))):
            warns.append(f"{c}: dropped as all-NaN in training, but populated now "
                         f"-- retrain with this feature available")
    return warns


def fit_and_evaluate(data: pd.DataFrame, max_bars: int, bar_ms: int,
                     n_splits: int = 4) -> Tuple[object, dict]:
    feat_cols, dropped = usable_features(data)
    if not feat_cols:
        raise RuntimeError("no usable features -- every column was empty or constant")
    for c, why in dropped.items():
        log.info("dropping feature %s: %s", c, why)
    X = data[feat_cols].astype(float)
    y = data["y"].astype(int).values
    idx = pd.DatetimeIndex(data.index)

    aucs, briers, all_y, all_p = [], [], [], []
    for tr, te in purged_splits(idx, n_splits, max_bars, bar_ms):
        if len(tr) < 500 or len(te) < 200 or len(np.unique(y[tr])) < 2:
            continue
        base = HistGradientBoostingClassifier(
            max_depth=4, learning_rate=0.05, max_iter=300,
            l2_regularization=1.0, min_samples_leaf=50, random_state=0)
        clf = CalibratedClassifierCV(base, method="isotonic", cv=3)
        clf.fit(X.iloc[tr], y[tr])
        p = clf.predict_proba(X.iloc[te])[:, 1]
        if len(np.unique(y[te])) > 1:
            aucs.append(roc_auc_score(y[te], p))
        briers.append(brier_score_loss(y[te], p))
        all_y.append(y[te])
        all_p.append(p)

    if not all_p:
        raise RuntimeError("no usable folds -- need more history")

    ay, ap = np.concatenate(all_y), np.concatenate(all_p)
    base_rate = float(ay.mean())
    rel = reliability_table(ay, ap)
    report = {
        "n_samples": int(len(data)),
        "base_rate": round(base_rate, 4),
        "cv_auc_mean": round(float(np.mean(aucs)), 4) if aucs else None,
        "cv_auc_std": round(float(np.std(aucs)), 4) if aucs else None,
        "cv_brier": round(float(np.mean(briers)), 5),
        "brier_of_always_base_rate": round(float(np.mean((ay - base_rate) ** 2)), 5),
        "reliability": rel.to_dict("records"),
        "features": feat_cols,
        "dropped_features": dropped,
    }

    # Final model for live use -- same filtered columns as the CV above, so the
    # reported metrics describe the model you actually ship.
    final_base = HistGradientBoostingClassifier(
        max_depth=4, learning_rate=0.05, max_iter=300,
        l2_regularization=1.0, min_samples_leaf=50, random_state=0)
    final = CalibratedClassifierCV(final_base, method="isotonic", cv=3)
    final.fit(X, y)
    return final, report


def main() -> None:
    import joblib
    from .backtest import BARS_PER_HOUR, MS, build_panel
    from .client import BinanceFutures
    import time as _t

    p = argparse.ArgumentParser(description="Fit P(target before stop) model")
    p.add_argument("--symbols", default="BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,XRPUSDT,"
                                        "DOGEUSDT,AVAXUSDT,LINKUSDT")
    p.add_argument("--interval", default="15m")
    p.add_argument("--days", type=int, default=365)
    p.add_argument("--direction", default="LONG", choices=["LONG", "SHORT"])
    p.add_argument("--atr-mult", type=float, default=1.5)
    p.add_argument("--tp-mult", type=float, default=2.0)
    p.add_argument("--max-bars", type=int, default=48)
    p.add_argument("--splits", type=int, default=4)
    p.add_argument("--cache-dir", default="data")
    p.add_argument("--out", default="model.joblib")
    a = p.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    end = int(_t.time() * 1000)
    start = end - a.days * 86_400_000
    cli = BinanceFutures()
    syms = [s.strip().upper() for s in a.symbols.split(",")]
    panel = build_panel(cli, syms, a.interval, start, end, a.cache_dir)

    data = assemble(panel, a.direction, a.atr_mult, a.tp_mult, a.max_bars)
    model, report = fit_and_evaluate(data, a.max_bars, MS[a.interval], a.splits)

    print(json.dumps({k: v for k, v in report.items()
                      if k not in ("reliability", "dropped_features")}, indent=2))
    if report["dropped_features"]:
        print("\nDropped features (not used by the model):")
        for c, why in report["dropped_features"].items():
            print(f"  {c:<24} {why}")
    print("\nCalibration (predicted vs actual -- these should be close):")
    print(pd.DataFrame(report["reliability"]).to_string(index=False))
    joblib.dump({"model": model, "features": report["features"],
                 "dropped_features": report["dropped_features"],
                 "config": vars(a)}, a.out)
    with open(a.out.replace(".joblib", "_report.json"), "w") as fh:
        json.dump(report, fh, indent=2)
    print(f"\nsaved {a.out}")


if __name__ == "__main__":
    main()
