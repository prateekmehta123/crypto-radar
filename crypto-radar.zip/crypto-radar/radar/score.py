"""
Scoring and setup construction.

Two deliberate choices:

1. The score is *signed*. A single 0-100 number cannot tell you whether to be
   long or short, so each block emits a contribution in [-1, +1] and the net
   maps to long_score = 50*(1+net). short_score is its mirror.

2. Nothing here is called a "probability". These are weighted heuristics. Real
   probabilities come out of model.py, which is fitted on labelled outcomes and
   calibration-checked. Calling a hand-weighted sum an "81% pump probability"
   is the single easiest way to lose money with a tool like this.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

# Block weights. backtest.py can search over these.
DEFAULT_WEIGHTS: Dict[str, float] = {
    "order_flow": 0.28,
    "open_interest": 0.18,
    "trend": 0.16,
    "structure": 0.12,
    "funding": 0.10,
    "relative_strength": 0.09,
    "volatility": 0.07,
}


def _clip(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    if x is None or not np.isfinite(x):
        return 0.0
    return float(np.clip(x, lo, hi))


def _sign(x: float) -> float:
    """np.sign that treats missing data as neutral. `x or 0.0` does NOT do this
    -- NaN is truthy in Python, so it propagates straight through."""
    if x is None or not np.isfinite(x):
        return 0.0
    return float(np.sign(x))


def _tanh(x: float, scale: float) -> float:
    """Squash a raw feature to [-1,1] with `scale` roughly the 1-sigma move."""
    if x is None or not np.isfinite(x):
        return 0.0
    return float(np.tanh(x / scale))


def _liq_term(up: float, dn: float) -> float:
    """Neutral unless both liquidity distances are known -- otherwise a missing
    side would read as 'no liquidity there', which is the opposite of unknown."""
    if not (np.isfinite(up) and np.isfinite(dn)):
        return 0.0
    return _tanh(up - dn, 0.03)


@dataclass
class Block:
    name: str
    value: float          # -1 .. +1
    weight: float
    available: bool       # False when the inputs were missing
    detail: Dict[str, Any] = field(default_factory=dict)


def score_row(r: pd.Series, weights: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
    """Score a single feature row (the last row live, any row in backtest)."""
    w = dict(DEFAULT_WEIGHTS if weights is None else weights)
    blocks: list[Block] = []

    # ---------------------------------------------------------- order flow
    of_parts = [
        _tanh(r.get("delta_norm", np.nan), 0.10),
        _tanh(r.get("cvd_slope_1h", np.nan), 0.12),
        _tanh(r.get("cvd_slope_4h", np.nan), 0.10),
        _tanh(r.get("cvd_price_divergence", np.nan), 0.30),
        _tanh(r.get("vol_z", np.nan), 2.0) * _sign(r.get("delta_norm", np.nan)),
    ]
    of_avail = np.isfinite(r.get("cvd_slope_1h", np.nan))
    blocks.append(Block("order_flow", float(np.mean(of_parts)), w["order_flow"], bool(of_avail),
                        {"delta_norm": r.get("delta_norm"),
                         "cvd_slope_1h": r.get("cvd_slope_1h"),
                         "cvd_divergence": r.get("cvd_price_divergence")}))

    # ------------------------------------------------------ open interest
    oi_chg = r.get("oi_chg_1h", np.nan)
    ret_1h = r.get("ret_1h", np.nan)
    oi_avail = np.isfinite(oi_chg)
    if oi_avail:
        # Price up + OI up = new longs (constructive, but crowded if extreme).
        # Price up + OI down = short covering (weaker, fades more often).
        # Price down + OI up = new shorts (bearish, but squeeze fuel).
        mag = _tanh(abs(oi_chg), 0.010)
        if ret_1h > 0 and oi_chg > 0:
            oi_val = 0.9 * mag
        elif ret_1h > 0 and oi_chg < 0:
            oi_val = 0.25 * mag
        elif ret_1h < 0 and oi_chg > 0:
            oi_val = -0.9 * mag
        else:
            oi_val = -0.25 * mag
        oi_val += 0.3 * _tanh(r.get("oi_chg_4h", np.nan), 0.03)
    else:
        oi_val = 0.0
    blocks.append(Block("open_interest", _clip(oi_val), w["open_interest"], bool(oi_avail),
                        {"oi_chg_1h": oi_chg, "oi_chg_4h": r.get("oi_chg_4h"),
                         "regime": _regime_label(ret_1h, oi_chg)}))

    # -------------------------------------------------------------- trend
    tr = np.mean([
        _clip(r.get("ema_stack", 0.0)),
        _tanh(r.get("vwap_dist", np.nan), 0.015),
        _tanh(r.get("ema50_dist", np.nan), 0.030),
    ])
    blocks.append(Block("trend", _clip(tr), w["trend"],
                        bool(np.isfinite(r.get("ema_stack", np.nan))),
                        {"ema_stack": r.get("ema_stack"), "vwap_dist": r.get("vwap_dist")}))

    # ---------------------------------------------------------- structure
    st = np.mean([
        0.6 * (r.get("broke_swing_high", 0.0) - r.get("broke_swing_low", 0.0)),
        _tanh(r.get("poc_dist", np.nan), 0.02),
        # asymmetric room to run: more liquidity above than below is bullish
        _liq_term(r.get("liq_up_dist", np.nan), r.get("liq_dn_dist", np.nan)),
    ])
    blocks.append(Block("structure", _clip(st), w["structure"],
                        bool(np.isfinite(r.get("poc_dist", np.nan))),
                        {"poc_dist": r.get("poc_dist"),
                         "liq_up_dist": r.get("liq_up_dist"),
                         "liq_dn_dist": r.get("liq_dn_dist")}))

    # ------------------------------------------------------------ funding
    fz = r.get("funding_z_7d", np.nan)
    fnd = r.get("funding", np.nan)
    fund_avail = np.isfinite(fnd)
    # Contrarian: crowded positioning is a headwind, not a tailwind.
    fund_val = -_tanh(fz if np.isfinite(fz) else (fnd or 0) * 3000, 1.5)
    tls = r.get("taker_ls_ratio", np.nan)
    if np.isfinite(tls):
        fund_val += 0.3 * _tanh(np.log(max(tls, 1e-6)), 0.35)
    tps = r.get("top_pos_ls_ratio", np.nan)
    if np.isfinite(tps):
        fund_val += 0.3 * _tanh(np.log(max(tps, 1e-6)), 0.35)
    blocks.append(Block("funding", _clip(fund_val), w["funding"], bool(fund_avail),
                        {"funding": fnd, "funding_z_7d": fz,
                         "taker_ls": tls, "top_pos_ls": tps}))

    # -------------------------------------------------- relative strength
    rs = np.mean([
        _tanh(r.get("rs_1h", np.nan), 0.008),
        _tanh(r.get("rs_4h", np.nan), 0.020),
        _tanh(r.get("rs_24h", np.nan), 0.050),
    ])
    blocks.append(Block("relative_strength", _clip(rs), w["relative_strength"],
                        bool(np.isfinite(r.get("rs_4h", np.nan))),
                        {"rs_4h": r.get("rs_4h"), "rs_24h": r.get("rs_24h")}))

    # --------------------------------------------------------- volatility
    # Compression before expansion is directionally neutral but raises
    # conviction; expansion already underway slightly favours continuation.
    squeeze = r.get("bb_squeeze_pctile", np.nan)
    vol_val = 0.0
    if np.isfinite(squeeze):
        vol_val = (0.5 - squeeze) * 0.8 * _sign(r.get("ema_stack", np.nan))
    blocks.append(Block("volatility", _clip(vol_val), w["volatility"],
                        bool(np.isfinite(squeeze)),
                        {"bb_squeeze_pctile": squeeze,
                         "atr_expansion": r.get("atr_expansion")}))

    # --------------------------------------------------------- aggregation
    # Re-normalise over available blocks so a missing OI feed does not silently
    # drag the score toward neutral.
    tot_w = sum(b.weight for b in blocks if b.available) or 1.0
    net = sum(b.value * b.weight for b in blocks if b.available) / tot_w
    net = _clip(net)

    long_score = 50.0 * (1.0 + net)
    agree = [np.sign(b.value) for b in blocks if b.available and abs(b.value) > 0.05]
    agreement = float(abs(np.mean(agree))) if agree else 0.0
    coverage = tot_w / sum(b.weight for b in blocks)

    return {
        "net": net,
        "long_score": round(long_score, 1),
        "short_score": round(100 - long_score, 1),
        "direction": "LONG" if net > 0 else "SHORT" if net < 0 else "FLAT",
        "conviction": round(abs(net) * agreement * coverage, 3),
        "agreement": round(agreement, 3),
        "coverage": round(coverage, 3),
        "blocks": {b.name: {"value": round(b.value, 3), "weight": b.weight,
                            "available": b.available, **b.detail} for b in blocks},
        "squeeze": squeeze_scores(r),
    }


# ------------------------------------------------ vectorised path (backtest)
# Block values do not depend on the weights, so a weight search should compute
# them once and then only re-aggregate. This turns a ~3-hour walk-forward
# sweep into a ~2-minute one. block_frame() is checked against score_row() in
# selftest.py so the two paths cannot silently diverge.

BLOCK_NAMES = list(DEFAULT_WEIGHTS)


def _v(f: pd.DataFrame, col: str) -> np.ndarray:
    return f[col].to_numpy(dtype=float) if col in f.columns else np.full(len(f), np.nan)


def _vtanh(x: np.ndarray, scale: float) -> np.ndarray:
    return np.tanh(np.nan_to_num(x, nan=0.0) / scale)


def block_frame(f: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Vectorised equivalent of the block values inside score_row."""
    n = len(f)
    vals, avail = {}, {}

    delta = _v(f, "delta_norm")
    cvd1, cvd4 = _v(f, "cvd_slope_1h"), _v(f, "cvd_slope_4h")
    div, volz = _v(f, "cvd_price_divergence"), _v(f, "vol_z")
    vals["order_flow"] = np.mean([
        _vtanh(delta, 0.10), _vtanh(cvd1, 0.12), _vtanh(cvd4, 0.10),
        _vtanh(div, 0.30),
        _vtanh(volz, 2.0) * np.where(np.isfinite(delta), np.sign(np.nan_to_num(delta)), 0.0),
    ], axis=0)
    avail["order_flow"] = np.isfinite(cvd1)

    oi1, oi4, r1 = _v(f, "oi_chg_1h"), _v(f, "oi_chg_4h"), _v(f, "ret_1h")
    mag = _vtanh(np.abs(oi1), 0.010)
    sgn = np.select(
        [(r1 > 0) & (oi1 > 0), (r1 > 0) & (oi1 < 0), (r1 < 0) & (oi1 > 0)],
        [0.9, 0.25, -0.9], default=-0.25)
    oi_val = sgn * mag + 0.3 * _vtanh(oi4, 0.03)
    vals["open_interest"] = np.clip(np.where(np.isfinite(oi1), oi_val, 0.0), -1, 1)
    avail["open_interest"] = np.isfinite(oi1)

    stack = _v(f, "ema_stack")
    vals["trend"] = np.clip(np.mean([
        np.clip(np.nan_to_num(stack), -1, 1),
        _vtanh(_v(f, "vwap_dist"), 0.015),
        _vtanh(_v(f, "ema50_dist"), 0.030),
    ], axis=0), -1, 1)
    avail["trend"] = np.isfinite(stack)

    poc = _v(f, "poc_dist")
    lu, ld = _v(f, "liq_up_dist"), _v(f, "liq_dn_dist")
    liq_term = np.where(np.isfinite(lu) & np.isfinite(ld),
                        _vtanh(lu - ld, 0.03), 0.0)
    vals["structure"] = np.clip(np.mean([
        0.6 * (np.nan_to_num(_v(f, "broke_swing_high")) - np.nan_to_num(_v(f, "broke_swing_low"))),
        _vtanh(poc, 0.02),
        liq_term,
    ], axis=0), -1, 1)
    avail["structure"] = np.isfinite(poc)

    fz, fnd = _v(f, "funding_z_7d"), _v(f, "funding")
    fz_use = np.where(np.isfinite(fz), fz, np.nan_to_num(fnd) * 3000)
    fund = -_vtanh(fz_use, 1.5)
    tls, tps = _v(f, "taker_ls_ratio"), _v(f, "top_pos_ls_ratio")
    fund = fund + 0.3 * np.where(np.isfinite(tls),
                                 _vtanh(np.log(np.maximum(np.nan_to_num(tls, nan=1.0), 1e-6)), 0.35), 0.0)
    fund = fund + 0.3 * np.where(np.isfinite(tps),
                                 _vtanh(np.log(np.maximum(np.nan_to_num(tps, nan=1.0), 1e-6)), 0.35), 0.0)
    vals["funding"] = np.clip(fund, -1, 1)
    avail["funding"] = np.isfinite(fnd)

    rs4 = _v(f, "rs_4h")
    vals["relative_strength"] = np.clip(np.mean([
        _vtanh(_v(f, "rs_1h"), 0.008), _vtanh(rs4, 0.020), _vtanh(_v(f, "rs_24h"), 0.050),
    ], axis=0), -1, 1)
    avail["relative_strength"] = np.isfinite(rs4)

    sq = _v(f, "bb_squeeze_pctile")
    vals["volatility"] = np.clip(
        np.where(np.isfinite(sq),
                 (0.5 - np.nan_to_num(sq)) * 0.8
                 * np.where(np.isfinite(stack), np.sign(np.nan_to_num(stack)), 0.0), 0.0),
        -1, 1)
    avail["volatility"] = np.isfinite(sq)

    return (pd.DataFrame(vals, index=f.index)[BLOCK_NAMES],
            pd.DataFrame(avail, index=f.index)[BLOCK_NAMES])


def aggregate(vals: pd.DataFrame, avail: pd.DataFrame,
              weights: Dict[str, float]) -> pd.DataFrame:
    """Combine precomputed blocks under a weight vector. Fully vectorised."""
    w = np.array([weights[b] for b in BLOCK_NAMES], dtype=float)
    V = vals[BLOCK_NAMES].to_numpy(dtype=float)
    A = avail[BLOCK_NAMES].to_numpy(dtype=bool)
    W = A * w
    tot = W.sum(axis=1)
    net = np.divide((np.nan_to_num(V) * W).sum(axis=1), tot,
                    out=np.zeros_like(tot), where=tot > 0)
    net = np.clip(net, -1, 1)

    active = A & (np.abs(np.nan_to_num(V)) > 0.05)
    signs = np.sign(np.nan_to_num(V)) * active
    cnt = active.sum(axis=1)
    agreement = np.divide(np.abs(signs.sum(axis=1)), cnt,
                          out=np.zeros(len(cnt), dtype=float), where=cnt > 0)
    coverage = tot / w.sum()
    return pd.DataFrame({
        "net": net,
        "conviction": np.abs(net) * agreement * coverage,
        "agreement": agreement,
        "coverage": coverage,
        "direction": np.where(net > 0, "LONG", np.where(net < 0, "SHORT", "FLAT")),
    }, index=vals.index)


def _regime_label(dp: float, doi: float) -> str:
    if not (np.isfinite(dp) and np.isfinite(doi)):
        return "unknown"
    if dp > 0 and doi > 0:
        return "new longs"
    if dp > 0 and doi < 0:
        return "short covering"
    if dp < 0 and doi > 0:
        return "new shorts"
    return "long liquidation"


def squeeze_scores(r: pd.Series) -> Dict[str, float]:
    """Heuristic 0-100 squeeze pressure scores. NOT probabilities.

    Short squeeze fuel: crowded shorts (negative funding, low taker L/S,
    OI built while price fell) plus price now reclaiming levels.
    Long squeeze fuel: the mirror image.
    """
    fnd = r.get("funding", np.nan)
    fz = r.get("funding_z_7d", np.nan)
    tls = r.get("taker_ls_ratio", np.nan)
    oi4 = r.get("oi_chg_4h", np.nan)
    ret4 = r.get("ret_4h", np.nan)
    ret1 = r.get("ret_1h", np.nan)

    crowded_short = 0.0
    crowded_long = 0.0
    if np.isfinite(fz):
        crowded_short += _clip(-fz / 2.0, 0, 1)
        crowded_long += _clip(fz / 2.0, 0, 1)
    elif np.isfinite(fnd):
        crowded_short += _clip(-fnd * 3000, 0, 1)
        crowded_long += _clip(fnd * 3000, 0, 1)
    if np.isfinite(tls):
        crowded_short += _clip((1.0 - tls) * 2, 0, 1)
        crowded_long += _clip((tls - 1.0) * 2, 0, 1)
    if np.isfinite(oi4) and np.isfinite(ret4):
        if oi4 > 0 and ret4 < 0:
            crowded_short += _clip(oi4 * 40, 0, 1)
        if oi4 > 0 and ret4 > 0:
            crowded_long += _clip(oi4 * 40, 0, 1)

    trigger_up = _clip((ret1 or 0) * 60, 0, 1)
    trigger_dn = _clip(-(ret1 or 0) * 60, 0, 1)

    ss = 100 * _clip((crowded_short / 3.0) * 0.7 + trigger_up * 0.3, 0, 1)
    ls = 100 * _clip((crowded_long / 3.0) * 0.7 + trigger_dn * 0.3, 0, 1)
    return {"short_squeeze_score": round(ss, 1), "long_squeeze_score": round(ls, 1)}


# ------------------------------------------------------------------ setups

@dataclass
class Setup:
    direction: str
    entry: float
    stop: float
    tp1: float
    tp2: float
    tp3: float
    rr_tp2: float
    risk_pct: float          # distance to stop as % of entry
    invalidation: str
    risk_rating: str
    position_size_pct: float  # % of account to risk-adjusted notional


def build_setup(r: pd.Series, direction: str, atr_mult: float = 1.5,
                account_risk_pct: float = 0.5, max_leverage: float = 5.0) -> Optional[Setup]:
    """Structure-aware stop, ATR floor, liquidity-aware targets."""
    px = float(r["close"])
    a = float(r.get("atr", np.nan))
    if not np.isfinite(px) or not np.isfinite(a) or a <= 0:
        return None

    if direction == "LONG":
        struct_stop = r.get("swing_low", np.nan)
        atr_stop = px - atr_mult * a
        stop = min(struct_stop, atr_stop) if np.isfinite(struct_stop) else atr_stop
        stop = min(stop, px - 0.6 * a)            # never absurdly tight
        risk = px - stop
        liq = r.get("liq_up", np.nan)
        tp1 = px + 1.0 * risk
        tp2 = px + 2.0 * risk
        tp3 = liq if (np.isfinite(liq) and liq > px + 2.2 * risk) else px + 3.0 * risk
        inval = f"close below {stop:.6g} (swing low / {atr_mult}xATR)"
    elif direction == "SHORT":
        struct_stop = r.get("swing_high", np.nan)
        atr_stop = px + atr_mult * a
        stop = max(struct_stop, atr_stop) if np.isfinite(struct_stop) else atr_stop
        stop = max(stop, px + 0.6 * a)
        risk = stop - px
        liq = r.get("liq_dn", np.nan)
        tp1 = px - 1.0 * risk
        tp2 = px - 2.0 * risk
        tp3 = liq if (np.isfinite(liq) and liq < px - 2.2 * risk) else px - 3.0 * risk
        inval = f"close above {stop:.6g} (swing high / {atr_mult}xATR)"
    else:
        return None

    risk_pct = risk / px
    if risk_pct <= 0:
        return None

    atr_pct = float(r.get("atr_pct", np.nan))
    fz = float(r.get("funding_z_7d", np.nan))
    rating = "Low"
    if atr_pct > 0.010 or risk_pct > 0.030:
        rating = "Medium"
    if atr_pct > 0.020 or risk_pct > 0.050:
        rating = "High"
    if atr_pct > 0.035 or (np.isfinite(fz) and abs(fz) > 3):
        rating = "Extreme"

    # Notional such that a stop-out costs `account_risk_pct` of the account,
    # capped by max_leverage.
    size_pct = min(account_risk_pct / risk_pct, max_leverage * 100 / 100) * 100
    size_pct = min(size_pct, max_leverage * 100)

    return Setup(direction, px, stop, tp1, tp2, tp3,
                 rr_tp2=2.0, risk_pct=round(risk_pct * 100, 3),
                 invalidation=inval, risk_rating=rating,
                 position_size_pct=round(size_pct, 1))


def setup_dict(s: Optional[Setup]) -> Optional[dict]:
    return asdict(s) if s else None
