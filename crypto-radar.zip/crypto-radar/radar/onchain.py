"""
On-chain whale flow via the Arkham Intelligence API.

    https://api.arkm.com  |  header: API-Key: <key>

WHY THIS IS AN OVERLAY AND NOT A SCORING BLOCK
----------------------------------------------
The weighted score in score.py is walk-forward validated. Every block in it can
be reconstructed for any historical bar, so the backtester can measure whether
it helps. On-chain flow cannot: /transfers is rate limited to 1 request/second,
pagination caps at the 10,000th result per filter, and there is no bulk
historical export. Building a labelled panel across 150 symbols x 1 year is
not practical.

Adding an unbacktestable block to a backtested score does not make the score
better-informed. It makes the score's out-of-sample numbers a lie, because the
number you validated is no longer the number you are trading.

So whale flow lives here, outside the score, doing two jobs:

  1. **Annotation.** Candidates get a `whale` field. It appears in the alert so
     you can overrule the setup. It never moves the score.
  2. **Its own alert class.** Genuinely notable events -- a dormant wallet
     waking, a very large exchange deposit -- fire independently of any setup.

If you later want it *in* the score, the honest path is: run it in annotation
mode for a few months, let store.py accumulate the events, then backtest the
recorded history and see whether it actually predicts anything. That is the
same discipline the OI blocks are under.

WHAT THE DATA CAN AND CANNOT TELL YOU
-------------------------------------
Large deposit to an exchange is *often* pre-sale positioning. It is also,
routinely: market-maker inventory rebalancing, OTC desk settlement, collateral
posting, a custodian reshuffle, or a labelled entity moving between its own
wallets in a way Arkham has not tagged as internal. Treat a big inflow as a
reason to lower conviction on a long, not as a short signal. The false positive
rate on "whale deposit means dump" is high enough that trading it directly is a
losing proposition.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import requests

log = logging.getLogger("radar.onchain")

BASE = "https://api.arkm.com"

# Heavy endpoints are capped at 1 request/second. /transfers is one of them,
# which is the single most important constraint on this whole module: it is why
# we do ONE broad sweep per cycle and join locally, rather than querying
# per-symbol. 150 per-symbol queries would take 150 seconds of a 300-second
# cycle and return mostly nothing.
HEAVY_PATHS = ("/transfers", "/swaps", "/counterparties", "/token/top_flow",
               "/token/volume")

# Entity types Arkham uses that we treat as "an exchange" for flow direction.
EXCHANGE_TYPES = {"cex", "exchange"}
KNOWN_EXCHANGES = {
    "binance", "coinbase", "okx", "bybit", "kraken", "kucoin", "bitfinex",
    "huobi", "htx", "gate-io", "gateio", "mexc", "bitget", "crypto-com",
    "upbit", "bithumb", "bitstamp", "gemini", "deribit", "arkham",
}


@dataclass
class Transfer:
    tx: str
    ts_ms: int
    token: str                    # symbol, e.g. "SOL"
    usd: float
    chain: str
    from_addr: str
    to_addr: str
    from_entity: Optional[str]    # human name if Arkham attributed it
    to_entity: Optional[str]
    from_entity_id: Optional[str]
    to_entity_id: Optional[str]
    from_type: Optional[str]
    to_type: Optional[str]

    def direction(self) -> str:
        """exchange_in = deposit to a CEX (potential sell pressure).
        exchange_out = withdrawal from a CEX (custody/accumulation).
        Both-sides-exchange is almost always internal plumbing, not a signal."""
        f_ex = _is_exchange(self.from_entity_id, self.from_type)
        t_ex = _is_exchange(self.to_entity_id, self.to_type)
        if f_ex and t_ex:
            return "exchange_internal"
        if t_ex:
            return "exchange_in"
        if f_ex:
            return "exchange_out"
        return "wallet_to_wallet"


def _is_exchange(entity_id: Optional[str], entity_type: Optional[str]) -> bool:
    if entity_type and entity_type.lower() in EXCHANGE_TYPES:
        return True
    return bool(entity_id and entity_id.lower() in KNOWN_EXCHANGES)


class _RateLimiter:
    def __init__(self, per_second: float):
        self.min_gap = 1.0 / per_second
        self._last = 0.0
        self._lock = threading.Lock()

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            gap = now - self._last
            if gap < self.min_gap:
                time.sleep(self.min_gap - gap)
            self._last = time.monotonic()


class ArkhamClient:
    def __init__(self, api_key: Optional[str] = None, timeout: float = 20.0):
        self.key = api_key or os.environ.get("ARKHAM_API_KEY", "")
        self.timeout = timeout
        self._heavy = _RateLimiter(0.9)     # slightly under the 1/s cap
        self._std = _RateLimiter(15.0)      # under the 20/s cap
        self._s = requests.Session()
        self._s.headers.update({"API-Key": self.key,
                                "User-Agent": "crypto-radar/1.0"})

    @property
    def enabled(self) -> bool:
        return bool(self.key)

    def _get(self, path: str, params: Optional[dict] = None) -> Optional[Any]:
        if not self.enabled:
            return None
        limiter = self._heavy if path.startswith(HEAVY_PATHS) else self._std
        for attempt in range(3):
            limiter.wait()
            try:
                r = self._s.get(BASE + path, params=params, timeout=self.timeout)
            except requests.RequestException as e:
                log.warning("arkham network error %s: %s", path, e)
                time.sleep(1.5 * (attempt + 1))
                continue
            if r.status_code == 200:
                return r.json()
            if r.status_code in (401, 403):
                log.error("arkham auth failed (%s) -- check ARKHAM_API_KEY and "
                          "that your plan covers %s", r.status_code, path)
                return None
            if r.status_code == 429:
                wait = float(r.headers.get("Retry-After", 5))
                log.warning("arkham rate limited, waiting %.0fs", wait)
                time.sleep(wait + 1)
                continue
            log.warning("arkham %s -> HTTP %s: %s", path, r.status_code, r.text[:200])
            time.sleep(1.0)
        return None

    # ---------------------------------------------------------------- calls

    def transfers(self, usd_gte: float = 1_000_000, time_last: str = "1h",
                  limit: int = 500, tokens: Optional[str] = None,
                  base: Optional[str] = None, flow: Optional[str] = None
                  ) -> List[Transfer]:
        """One broad sweep. Filter locally rather than querying per symbol."""
        params: Dict[str, Any] = {"usdGte": usd_gte, "timeLast": time_last,
                                  "limit": min(limit, 10_000),
                                  "sortKey": "usd", "sortDir": "desc"}
        if tokens:
            params["tokens"] = tokens
        if base:
            params["base"] = base
        if flow:
            params["flow"] = flow
        data = self._get("/transfers", params)
        if not data:
            return []
        raw = data.get("transfers", data) if isinstance(data, dict) else data
        return [t for t in (_parse_transfer(x) for x in raw) if t is not None]

    def address_intel(self, address: str, chain: str = "ethereum") -> Optional[dict]:
        return self._get(f"/intelligence/address/{address}", {"chain": chain})

    def address_last_activity_ms(self, address: str,
                                 chain: Optional[str] = None) -> Optional[int]:
        """Timestamp of this address's previous transfer, for dormancy checks.

        Costs one HEAVY request. Only call it for addresses that already look
        interesting, and cache the answer -- see WhaleTracker.
        """
        params: Dict[str, Any] = {"base": address, "limit": 2,
                                  "sortKey": "time", "sortDir": "desc"}
        if chain:
            params["chains"] = chain
        data = self._get("/transfers", params)
        if not data:
            return None
        raw = data.get("transfers", data) if isinstance(data, dict) else data
        parsed = [t for t in (_parse_transfer(x) for x in raw) if t is not None]
        # index 0 is the transfer that triggered this lookup; 1 is the previous
        return parsed[1].ts_ms if len(parsed) > 1 else None


def _parse_transfer(x: dict) -> Optional[Transfer]:
    try:
        fa = x.get("fromAddress") or {}
        ta = x.get("toAddress") or {}
        fe = fa.get("arkhamEntity") or {}
        te = ta.get("arkhamEntity") or {}
        ts = x.get("blockTimestamp")
        if isinstance(ts, str):
            import datetime as _dt
            ts_ms = int(_dt.datetime.fromisoformat(
                ts.replace("Z", "+00:00")).timestamp() * 1000)
        else:
            ts_ms = int(ts or 0)
        # historicalUSD is the value at transfer time -- unitValueUsd is not
        usd = float(x.get("historicalUSD") or x.get("usd") or 0.0)
        return Transfer(
            tx=str(x.get("transactionHash") or x.get("id") or ""),
            ts_ms=ts_ms,
            token=str(x.get("tokenSymbol") or "").upper(),
            usd=usd,
            chain=str(x.get("chain") or fa.get("chain") or ""),
            from_addr=str(fa.get("address") or ""),
            to_addr=str(ta.get("address") or ""),
            from_entity=fe.get("name"), to_entity=te.get("name"),
            from_entity_id=fe.get("id"), to_entity_id=te.get("id"),
            from_type=fe.get("type"), to_type=te.get("type"),
        )
    except Exception as e:                                # noqa: BLE001
        log.debug("could not parse transfer: %s", e)
        return None


# --------------------------------------------------------------- aggregation

@dataclass
class WhaleContext:
    """Per-symbol on-chain summary for one cycle. Annotation only."""
    symbol: str
    inflow_usd: float = 0.0        # to exchanges
    outflow_usd: float = 0.0       # from exchanges
    net_to_exchange: float = 0.0   # positive = net moving onto exchanges
    n_transfers: int = 0
    largest_usd: float = 0.0
    largest_desc: str = ""
    dormant_wakes: List[str] = field(default_factory=list)
    notable: List[str] = field(default_factory=list)

    def flag(self) -> Optional[str]:
        """A short human read, or None if nothing worth saying."""
        if self.dormant_wakes:
            return f"dormant wallet active ({len(self.dormant_wakes)})"
        if self.net_to_exchange > 0 and self.inflow_usd >= 2 * max(self.outflow_usd, 1):
            return f"net ${self.net_to_exchange/1e6:.1f}M onto exchanges"
        if self.net_to_exchange < 0 and self.outflow_usd >= 2 * max(self.inflow_usd, 1):
            return f"net ${abs(self.net_to_exchange)/1e6:.1f}M off exchanges"
        return None

    def caution_for(self, direction: str) -> bool:
        """True when the flow argues against the setup's direction."""
        if direction == "LONG":
            return self.net_to_exchange > 0 and self.inflow_usd >= 2 * max(self.outflow_usd, 1)
        return self.net_to_exchange < 0 and self.outflow_usd >= 2 * max(self.inflow_usd, 1)


class WhaleTracker:
    """Sweeps large transfers once per cycle and maps them onto the universe.

    Symbol matching is done on Arkham's `tokenSymbol` -- "SOL" matches
    "SOLUSDT". This sidesteps maintaining a Binance-symbol-to-CoinGecko-ID map,
    at the cost of missing tokens whose on-chain ticker differs from their
    Binance listing (wrapped assets, rebrands, ticker collisions between an
    ERC-20 and an unrelated Binance listing). `symbol_overrides` handles those.
    """

    def __init__(self, client: ArkhamClient, store=None,
                 usd_gte: float = 1_000_000,
                 dormancy_days: float = 180.0,
                 dormancy_min_usd: float = 5_000_000,
                 dormancy_lookups_per_cycle: int = 10,
                 symbol_overrides: Optional[Dict[str, str]] = None):
        self.cli = client
        self.store = store
        self.usd_gte = usd_gte
        self.dormancy_ms = int(dormancy_days * 86_400_000)
        self.dormancy_min_usd = dormancy_min_usd
        self.dormancy_budget = dormancy_lookups_per_cycle
        self.overrides = {k.upper(): v.upper() for k, v in (symbol_overrides or {}).items()}
        self._dormancy_cache: Dict[str, Optional[int]] = {}

    @property
    def enabled(self) -> bool:
        return self.cli.enabled

    def _token_to_symbol(self, token: str) -> str:
        return self.overrides.get(token.upper(), token.upper() + "USDT")

    def sweep(self, universe: List[str], time_last: str = "1h"
              ) -> Dict[str, WhaleContext]:
        if not self.enabled:
            return {}
        uni = set(universe)
        transfers = self.cli.transfers(usd_gte=self.usd_gte, time_last=time_last,
                                       limit=1000)
        log.info("arkham sweep: %d transfers >= $%.0fM in last %s",
                 len(transfers), self.usd_gte / 1e6, time_last)

        ctx: Dict[str, WhaleContext] = defaultdict(lambda: WhaleContext(""))
        budget = self.dormancy_budget

        for t in transfers:
            sym = self._token_to_symbol(t.token)
            if sym not in uni:
                continue
            c = ctx[sym]
            c.symbol = sym
            c.n_transfers += 1
            d = t.direction()
            if d == "exchange_in":
                c.inflow_usd += t.usd
            elif d == "exchange_out":
                c.outflow_usd += t.usd
            if t.usd > c.largest_usd:
                c.largest_usd = t.usd
                c.largest_desc = _describe(t)

            if self.store is not None:
                self.store.record_transfer(t.tx, t.ts_ms, sym, t.token, t.usd,
                                           d, t.from_entity, t.to_entity,
                                           t.from_addr, t.to_addr)

            # Dormancy is only asked about for large moves from unlabelled
            # wallets -- a labelled exchange or fund is never "dormant" in any
            # interesting sense, and each lookup costs a full second.
            if (budget > 0 and t.usd >= self.dormancy_min_usd
                    and not t.from_entity and d != "exchange_out"):
                budget -= 1
                if self._is_dormant_wake(t):
                    c.dormant_wakes.append(_describe(t))
                    c.notable.append(f"dormant wallet moved ${t.usd/1e6:.1f}M")

        for c in ctx.values():
            c.net_to_exchange = c.inflow_usd - c.outflow_usd
        return dict(ctx)

    def _is_dormant_wake(self, t: Transfer) -> bool:
        addr = t.from_addr
        if not addr:
            return False
        # Prefer locally recorded history -- free, and it improves the longer
        # the scanner has been running.
        if self.store is not None:
            local = self.store.address_last_seen(addr, before_ms=t.ts_ms)
            if local is not None:
                return (t.ts_ms - local) >= self.dormancy_ms
        if addr in self._dormancy_cache:
            prev = self._dormancy_cache[addr]
        else:
            prev = self.cli.address_last_activity_ms(addr, t.chain or None)
            self._dormancy_cache[addr] = prev
        if prev is None:
            return False
        return (t.ts_ms - prev) >= self.dormancy_ms


def _describe(t: Transfer) -> str:
    src = t.from_entity or (t.from_addr[:8] + "…" if t.from_addr else "unknown")
    dst = t.to_entity or (t.to_addr[:8] + "…" if t.to_addr else "unknown")
    return f"${t.usd/1e6:.1f}M {t.token} {src} → {dst}"
