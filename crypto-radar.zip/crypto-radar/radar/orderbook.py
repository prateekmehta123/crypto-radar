"""
Multi-venue order book snapshots.

WHY REST AND NOT WEBSOCKETS
---------------------------
The book here feeds one thing: a veto on scalp entries, evaluated once per scan
cycle. A REST snapshot answers that completely. Ten persistent WebSocket
connections would add reconnect logic, heartbeats, backpressure handling, a new
dependency and a much worse failure mode -- to deliver data that gets sampled
every five minutes.

Streaming earns its complexity when you are *executing* against sub-second book
changes. If that day comes, the adapters here are the right shape to swap: each
venue already normalises into the same BookSide structure, so a streaming
source would replace `fetch()` and nothing downstream would notice.

WHY THE VENUES ARE REPORTED SEPARATELY
--------------------------------------
Order books are not fungible. You cannot fill against MEXC size at Binance
prices, so summing depth across venues implies a single pooled book that does
not exist. Arbitrage keeps *prices* aligned; it does not make *depth*
transferable.

Worse, the tail of the "top 10" carries thin and sometimes inflated depth.
Blending that into Binance-quality data makes the aggregate less informative,
not more. So every venue is reported on its own, and the blended number is
liquidity-weighted with the weights visible. If you distrust a venue, set its
weight to zero rather than wondering what it did to the average.

WHAT AGGREGATION ACTUALLY BUYS YOU
----------------------------------
One thing, and it is worth having: a wall on a single venue is much weaker
evidence than the same wall present across several. Spoofing one book is cheap;
spoofing four simultaneously is not. So the useful output is not the summed
depth -- it is **agreement**. When venues disagree, that is the signal to
distrust the read, and `consensus` reports it.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import requests

log = logging.getLogger("radar.orderbook")


# Weights reflect how much a wall on that venue means. Binance dominates perp
# volume; the smaller venues are included for agreement, not for their depth.
DEFAULT_WEIGHTS = {
    "binance": 1.00,
    "bybit": 0.70,
    "okx": 0.60,
    "hyperliquid": 0.45,
    "bingx": 0.25,
    "gate": 0.25,
}


@dataclass
class VenueBook:
    venue: str
    symbol: str
    mid: float
    spread_bps: float
    bid_usd: float
    ask_usd: float
    imbalance: float
    levels_seen: int
    latency_ms: int
    error: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.error is None and self.mid > 0


def _imbalance(bids: List[Tuple[float, float]], asks: List[Tuple[float, float]],
               band_bps: float) -> Optional[Tuple[float, float, float, float, float]]:
    """(mid, spread_bps, bid_usd, ask_usd, imbalance) within band_bps of mid."""
    if not bids or not asks:
        return None
    bids = sorted(bids, key=lambda x: -x[0])
    asks = sorted(asks, key=lambda x: x[0])
    best_bid, best_ask = bids[0][0], asks[0][0]
    if best_bid <= 0 or best_ask <= 0 or best_ask < best_bid:
        return None
    mid = (best_bid + best_ask) / 2
    band = mid * band_bps / 10_000
    bid_usd = sum(p * q for p, q in bids if p >= mid - band)
    ask_usd = sum(p * q for p, q in asks if p <= mid + band)
    tot = bid_usd + ask_usd
    imb = (bid_usd - ask_usd) / tot if tot > 0 else 0.0
    return mid, (best_ask - best_bid) / mid * 10_000, bid_usd, ask_usd, imb


# ------------------------------------------------------------------ adapters
# Each returns (bids, asks) as [(price, size_in_base), ...] or raises.

def _binance(session: requests.Session, symbol: str, limit: int):
    r = session.get("https://fapi.binance.com/fapi/v1/depth",
                    params={"symbol": symbol, "limit": min(limit, 500)}, timeout=8)
    r.raise_for_status()
    d = r.json()
    return ([(float(p), float(q)) for p, q in d["bids"]],
            [(float(p), float(q)) for p, q in d["asks"]])


def _bybit(session: requests.Session, symbol: str, limit: int):
    r = session.get("https://api.bybit.com/v5/market/orderbook",
                    params={"category": "linear", "symbol": symbol,
                            "limit": min(limit, 500)}, timeout=8)
    r.raise_for_status()
    d = r.json()
    if d.get("retCode") not in (0, None):
        raise RuntimeError(d.get("retMsg", "bybit error"))
    res = d["result"]
    return ([(float(p), float(q)) for p, q in res["b"]],
            [(float(p), float(q)) for p, q in res["a"]])


def _okx(session: requests.Session, symbol: str, limit: int):
    inst = symbol.replace("USDT", "-USDT-SWAP").replace("USDC", "-USDC-SWAP")
    r = session.get("https://www.okx.com/api/v5/market/books",
                    params={"instId": inst, "sz": min(limit, 400)}, timeout=8)
    r.raise_for_status()
    d = r.json()
    rows = d.get("data") or []
    if not rows:
        raise RuntimeError(d.get("msg") or "okx returned no book")
    b = rows[0]
    # levels are [price, qty, deprecated, order_count]
    return ([(float(x[0]), float(x[1])) for x in b["bids"]],
            [(float(x[0]), float(x[1])) for x in b["asks"]])


def _bingx(session: requests.Session, symbol: str, limit: int):
    sym = symbol.replace("USDT", "-USDT").replace("USDC", "-USDC")
    r = session.get("https://open-api.bingx.com/openApi/swap/v2/quote/depth",
                    params={"symbol": sym, "limit": min(limit, 100)}, timeout=8)
    r.raise_for_status()
    d = r.json()
    data = d.get("data") or {}
    if not data.get("bids"):
        raise RuntimeError(d.get("msg") or "bingx returned no book")
    return ([(float(p), float(q)) for p, q in data["bids"]],
            [(float(p), float(q)) for p, q in data["asks"]])


def _gate(session: requests.Session, symbol: str, limit: int):
    contract = symbol.replace("USDT", "_USDT").replace("USDC", "_USDC")
    r = session.get("https://api.gateio.ws/api/v4/futures/usdt/order_book",
                    params={"contract": contract, "limit": min(limit, 100)}, timeout=8)
    r.raise_for_status()
    d = r.json()
    if not d.get("bids"):
        raise RuntimeError("gate returned no book")
    return ([(float(x["p"]), float(x["s"])) for x in d["bids"]],
            [(float(x["p"]), float(x["s"])) for x in d["asks"]])


ADAPTERS: Dict[str, Callable] = {
    "binance": _binance,
    "bybit": _bybit,
    "okx": _okx,
    "bingx": _bingx,
    "gate": _gate,
}


# --------------------------------------------------------------- aggregator

@dataclass
class Consensus:
    symbol: str
    venues: List[VenueBook]
    weighted_imbalance: float
    agreement: float              # 0..1, share of weight pointing the same way
    total_bid_usd: float
    total_ask_usd: float
    verdict: str
    trustworthy: bool

    def as_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "weighted_imbalance": round(self.weighted_imbalance, 3),
            "agreement": round(self.agreement, 3),
            "total_bid_usd": round(self.total_bid_usd, 0),
            "total_ask_usd": round(self.total_ask_usd, 0),
            "trustworthy": self.trustworthy,
            "verdict": self.verdict,
            "venues": [{"venue": v.venue, "ok": v.ok, "mid": v.mid,
                        "spread_bps": v.spread_bps, "bid_usd": round(v.bid_usd, 0),
                        "ask_usd": round(v.ask_usd, 0),
                        "imbalance": round(v.imbalance, 3),
                        "latency_ms": v.latency_ms, "error": v.error,
                        "weight": DEFAULT_WEIGHTS.get(v.venue, 0.0)}
                       for v in self.venues],
        }

    def vetoes(self, direction: str, threshold: float = 0.35) -> bool:
        """Only vetoes when the venues actually agree. Disagreement means the
        read is unreliable, and an unreliable read should not block a trade."""
        if not self.trustworthy:
            return False
        if direction == "LONG":
            return self.weighted_imbalance <= -threshold
        return self.weighted_imbalance >= threshold


class MultiBook:
    def __init__(self, venues: Optional[List[str]] = None,
                 weights: Optional[Dict[str, float]] = None,
                 band_bps: float = 25.0, ttl_s: float = 20.0,
                 min_side_usd: float = 25_000):
        env = os.environ.get("ORDERBOOK_VENUES", "")
        self.venues = [v.strip().lower() for v in
                       (venues or (env.split(",") if env else list(ADAPTERS)))
                       if v.strip().lower() in ADAPTERS]
        self.weights = dict(DEFAULT_WEIGHTS)
        if weights:
            self.weights.update(weights)
        for k, v in os.environ.items():                   # VENUE_WEIGHT_BYBIT=0
            if k.startswith("VENUE_WEIGHT_"):
                try:
                    self.weights[k[len("VENUE_WEIGHT_"):].lower()] = float(v)
                except ValueError:
                    pass
        self.band_bps = band_bps
        self.ttl = ttl_s
        self.min_side_usd = min_side_usd
        self._cache: Dict[str, Tuple[float, Consensus]] = {}
        self._lock = threading.Lock()
        self._s = requests.Session()
        self._s.headers.update({"User-Agent": "crypto-radar/1.0"})

    def _fetch_one(self, venue: str, symbol: str, limit: int) -> VenueBook:
        t0 = time.time()
        try:
            bids, asks = ADAPTERS[venue](self._s, symbol, limit)
            calc = _imbalance(bids, asks, self.band_bps)
            if calc is None:
                raise RuntimeError("empty or crossed book")
            mid, spread, bid_usd, ask_usd, imb = calc
            return VenueBook(venue, symbol, mid, round(spread, 3), bid_usd, ask_usd,
                             imb, len(bids) + len(asks),
                             int((time.time() - t0) * 1000))
        except Exception as e:                            # noqa: BLE001
            msg = f"{type(e).__name__}: {e}"[:120]
            log.debug("%s book failed for %s: %s", venue, symbol, msg)
            return VenueBook(venue, symbol, 0.0, 0.0, 0.0, 0.0, 0.0, 0,
                             int((time.time() - t0) * 1000), error=msg)

    def consensus(self, symbol: str, limit: int = 200,
                  extra: Optional[List[VenueBook]] = None) -> Consensus:
        """Snapshot every venue in parallel and combine.

        `extra` lets an already-fetched source (Hyperliquid) join without being
        requested twice.
        """
        key = f"{symbol}|{limit}"
        with self._lock:
            hit = self._cache.get(key)
            if hit and time.time() - hit[0] < self.ttl:
                return hit[1]

        books: List[VenueBook] = list(extra or [])
        if self.venues:
            with ThreadPoolExecutor(max_workers=min(6, len(self.venues))) as ex:
                futs = {ex.submit(self._fetch_one, v, symbol, limit): v
                        for v in self.venues}
                for f in as_completed(futs):
                    books.append(f.result())

        good = [b for b in books if b.ok and (b.bid_usd + b.ask_usd) > 0]
        wsum = sum(self.weights.get(b.venue, 0.0) for b in good)
        if wsum > 0:
            wimb = sum(b.imbalance * self.weights.get(b.venue, 0.0)
                       for b in good) / wsum
            # agreement: share of weight on the majority side
            same = sum(self.weights.get(b.venue, 0.0) for b in good
                       if np.sign(b.imbalance) == np.sign(wimb) and abs(b.imbalance) > 0.05)
            agree = same / wsum
        else:
            wimb, agree = 0.0, 0.0

        tot_bid = sum(b.bid_usd for b in good)
        tot_ask = sum(b.ask_usd for b in good)
        thin = min(tot_bid, tot_ask) < self.min_side_usd
        enough_venues = len(good) >= 2
        trust = bool(good and not thin and enough_venues and agree >= 0.6)

        cons = Consensus(symbol, sorted(books, key=lambda b: -self.weights.get(b.venue, 0)),
                         wimb, agree, tot_bid, tot_ask,
                         _verdict(good, wimb, agree, thin, tot_bid, tot_ask), trust)
        with self._lock:
            self._cache[key] = (time.time(), cons)
            if len(self._cache) > 200:
                for k, _ in sorted(self._cache.items(), key=lambda kv: kv[1][0])[:80]:
                    self._cache.pop(k, None)
        return cons


def _verdict(good: List[VenueBook], wimb: float, agree: float, thin: bool,
             bid: float, ask: float) -> str:
    if not good:
        return "No venue returned a usable book."
    names = ", ".join(b.venue for b in good)
    if len(good) < 2:
        return (f"Only {names} responded. A single venue's book is easy to spoof, "
                f"so this is not enough to act on either way.")
    if thin:
        return (f"Depth across {len(good)} venues is too thin to read "
                f"(${min(bid, ask) / 1e3:.0f}k on the lighter side).")
    side = "bid" if wimb > 0 else "ask"
    strength = ("heavily" if abs(wimb) > 0.5 else
                "moderately" if abs(wimb) > 0.25 else "slightly")
    s = (f"Across {len(good)} venues ({names}) the book is {strength} "
         f"{side}-weighted ({wimb:+.2f}): ${bid / 1e6:.1f}M bid against "
         f"${ask / 1e6:.1f}M ask.")
    if agree >= 0.85:
        s += (f" {agree:.0%} of weighted depth agrees, which is the case where "
              f"this means something — spoofing one book is cheap, spoofing "
              f"several at once is not.")
    elif agree >= 0.6:
        s += f" {agree:.0%} of weighted depth agrees."
    else:
        s += (f" Only {agree:.0%} agrees, so the venues are contradicting each "
              f"other and the read should be discarded rather than traded.")
    return s
