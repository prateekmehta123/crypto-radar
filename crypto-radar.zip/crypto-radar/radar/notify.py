"""
One-way Telegram alerts.  [NOT WIRED UP -- the web dashboard replaced this.]

Nothing imports this module any more. It is kept because it works and is
tested; if you ever want push notifications alongside the dashboard, wire
send_candidates() into ScannerService._loop in api.py. Delete the file freely
otherwise -- nothing depends on it.

Push only -- this module never reads updates, has no command handler, and
cannot receive anything from Telegram. If the bot token leaks, the worst
anyone can do is read your alerts by adding the bot to their own chat, which
does nothing since we only ever send to a fixed chat_id.

Three behaviours worth knowing about, because a noisy alert bot is worse than
no alert bot:

* **Cooldown per symbol+direction.** A setup that stays valid for six hours
  would otherwise fire every cycle. Default 4h.
* **Cap per cycle.** If 30 symbols cross the threshold at once -- which is what
  a market-wide move looks like -- you get the top N by conviction, plus a
  one-line note that others fired. Telegram also rate limits you at roughly 20
  messages/minute to one chat, so this protects the connection too.
* **Re-alert on material change.** If a symbol already alerted but conviction
  has risen substantially, it can fire again before the cooldown expires.
"""

from __future__ import annotations

import html
import logging
import os
import time
from typing import Any, Dict, List, Optional

import requests

log = logging.getLogger("radar.notify")

API = "https://api.telegram.org"


class TelegramNotifier:
    def __init__(self, token: Optional[str] = None, chat_id: Optional[str] = None,
                 store=None, cooldown_hours: float = 4.0,
                 max_per_cycle: int = 5, min_conviction: float = 0.30,
                 escalation_delta: float = 0.15, timeout: float = 15.0):
        self.token = token or os.environ.get("TELEGRAM_BOT_TOKEN", "")
        self.chat_id = chat_id or os.environ.get("TELEGRAM_CHAT_ID", "")
        self.store = store
        self.cooldown_ms = int(cooldown_hours * 3600 * 1000)
        self.max_per_cycle = max_per_cycle
        self.min_conviction = min_conviction
        self.escalation_delta = escalation_delta
        self.timeout = timeout
        self._s = requests.Session()

    @property
    def enabled(self) -> bool:
        return bool(self.token and self.chat_id)

    # ----------------------------------------------------------- transport

    def _post(self, method: str, payload: dict) -> bool:
        if not self.enabled:
            log.warning("telegram not configured; skipping %s", method)
            return False
        url = f"{API}/bot{self.token}/{method}"
        for attempt in range(4):
            try:
                r = self._s.post(url, json=payload, timeout=self.timeout)
            except requests.RequestException as e:
                log.warning("telegram network error: %s", e)
                time.sleep(2 ** attempt)
                continue
            if r.status_code == 200:
                return True
            if r.status_code == 429:
                wait = r.json().get("parameters", {}).get("retry_after", 5)
                log.warning("telegram rate limited, waiting %ss", wait)
                time.sleep(float(wait) + 1)
                continue
            # 400/401/403 are configuration errors -- retrying will not help
            log.error("telegram %s failed: %s %s", method, r.status_code, r.text[:300])
            return False
        return False

    def send(self, text: str, silent: bool = False) -> bool:
        return self._post("sendMessage", {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
            "disable_notification": silent,
        })

    # ---------------------------------------------------------- formatting

    @staticmethod
    def format_alert(c: Dict[str, Any]) -> str:
        s = c["setup"]
        e = html.escape
        arrow = "\U0001F7E2 LONG" if c["direction"] == "LONG" else "\U0001F534 SHORT"
        sym = e(c["symbol"].replace("USDT", "")) + "/USDT"
        fund = (c.get("funding") or 0.0) * 100
        sq = max(c.get("short_squeeze_score", 0), c.get("long_squeeze_score", 0))

        def px(v: float) -> str:
            return f"{v:,.6g}"

        blocks = c.get("blocks", {})
        lines = []
        for name in ("order_flow", "open_interest", "trend", "structure",
                     "funding", "relative_strength"):
            b = blocks.get(name, {})
            if not b.get("available"):
                continue
            v = b.get("value", 0.0)
            bar = "+" * min(5, int(abs(v) * 5) + 1) if v > 0 else "-" * min(5, int(abs(v) * 5) + 1)
            lines.append(f"  {name.replace('_', ' '):<18}{bar}")

        risk_line = (f"risk {s['risk_pct']:.2f}% to stop \u2022 "
                     f"{e(s['risk_rating'])} volatility")

        whale = c.get("whale") or {}
        whale_line = ""
        if whale.get("flag"):
            mark = "\u26A0\uFE0F " if whale.get("caution") else ""
            whale_line = f"\non-chain: {mark}{e(whale['flag'])}"
            if whale.get("largest"):
                whale_line += f"\n  largest: {e(whale['largest'])}"

        return (
            f"<b>{arrow}  {sym}</b>\n"
            f"<code>score {c['long_score']:.0f}  conviction {c['conviction']:.2f}  "
            f"coverage {c['coverage']:.0%}</code>\n"
            f"\n"
            f"<b>Entry</b>  <code>{px(s['entry'])}</code>\n"
            f"<b>Stop</b>   <code>{px(s['stop'])}</code>   ({risk_line})\n"
            f"<b>TP1</b>    <code>{px(s['tp1'])}</code>  (1R)\n"
            f"<b>TP2</b>    <code>{px(s['tp2'])}</code>  (2R)\n"
            f"<b>TP3</b>    <code>{px(s['tp3'])}</code>  (3R / liquidity)\n"
            f"\n"
            f"regime: {e(c.get('regime', 'unknown'))}\n"
            f"funding: {fund:+.4f}%  \u2022  squeeze pressure: {sq:.0f}"
            f"{whale_line}\n"
            f"\n"
            f"<b>blocks</b>\n<code>{chr(10).join(lines)}</code>\n"
            f"\n"
            f"<i>Invalidation: {e(s['invalidation'])}</i>"
        )

    # ------------------------------------------------------------- dedupe

    def _recently_alerted(self, symbol: str, direction: str,
                          conviction: float, now_ms: int) -> bool:
        if self.store is None:
            return False
        prev = self.store.last_alert(symbol, direction)
        if prev is None:
            return False
        prev_ts, prev_conv = prev
        if now_ms - prev_ts >= self.cooldown_ms:
            return False
        # allow a re-alert if the setup has strengthened materially
        if conviction - (prev_conv or 0) >= self.escalation_delta:
            return False
        return True

    # -------------------------------------------------------------- public

    def send_candidates(self, res: dict) -> int:
        if not self.enabled:
            return 0
        now_ms = int(res.get("generated_at") or time.time() * 1000)
        eligible = [c for c in res.get("candidates", [])
                    if c["conviction"] >= self.min_conviction]
        fresh = [c for c in eligible
                 if not self._recently_alerted(c["symbol"], c["direction"],
                                               c["conviction"], now_ms)]
        if not fresh:
            return 0

        fresh.sort(key=lambda c: -c["conviction"])
        to_send, held = fresh[:self.max_per_cycle], fresh[self.max_per_cycle:]

        sent = 0
        for c in to_send:
            if self.send(self.format_alert(c)):
                sent += 1
                if self.store is not None:
                    self.store.record_alert(now_ms, c["symbol"], c["direction"],
                                            c["conviction"])
                time.sleep(1.2)          # stay under Telegram's per-chat limit
        if held and sent:
            names = ", ".join(f"{c['symbol']} {c['direction'][0]}" for c in held[:12])
            self.send(f"<i>+{len(held)} more above threshold: {html.escape(names)}</i>",
                      silent=True)
        return sent

    def send_whale_events(self, res: dict) -> int:
        """Standalone on-chain alerts -- dormant wallets waking, outsized
        moves. These fire independently of any trade setup, because the event
        is the point; there may be no tradeable structure at all."""
        if not self.enabled:
            return 0
        events = res.get("whale_events") or []
        if not events:
            return 0
        now_ms = int(res.get("generated_at") or time.time() * 1000)
        sent = 0
        for ev in events[:3]:
            key = f"{ev['symbol']}::whale"
            if self._recently_alerted(key, "ONCHAIN", 1.0, now_ms):
                continue
            lines = [html.escape(x) for x in (ev.get("dormant_wakes") or [])[:3]]
            body = ("\n".join(f"  {x}" for x in lines)) or html.escape(ev.get("largest", ""))
            self.send(
                f"\U0001F433 <b>on-chain: {html.escape(ev['symbol'])}</b>\n"
                f"{html.escape(ev.get('flag') or 'large movement')}\n"
                f"<code>{body}</code>\n\n"
                f"<i>Context only. On-chain flow is not backtested and is not "
                f"part of the score.</i>")
            if self.store is not None:
                self.store.record_alert(now_ms, key, "ONCHAIN", 1.0)
            sent += 1
            time.sleep(1.2)
        return sent

    def send_heartbeat(self, res: dict, note: str = "") -> bool:
        return self.send(
            f"<i>radar alive \u2022 {res['universe_size']} symbols \u2022 "
            f"{len(res['candidates'])} candidates \u2022 {res['elapsed_s']}s"
            f"{' \u2022 ' + html.escape(note) if note else ''}</i>", silent=True)

    def send_error(self, msg: str) -> bool:
        return self.send(f"\u26A0\uFE0F <b>radar error</b>\n<code>{html.escape(msg[:600])}</code>")
