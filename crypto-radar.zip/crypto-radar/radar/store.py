"""
Local snapshot store.

This exists because of a hard constraint: Binance's /futures/data/* endpoints
(open interest, taker long/short, top-trader positioning) only retain the last
30 days. You cannot backtest OI-based signals over 1-3 years from the public
API -- that history does not exist to be fetched.

So the scanner writes every snapshot to SQLite from the first run. After a
month you own a dataset nobody can sell you back, and the OI blocks become
backtestable. Until then, backtests run on kline-derived features (which do go
back years) with the OI blocks disabled.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable, Optional

import pandas as pd

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    ts           INTEGER NOT NULL,
    symbol       TEXT    NOT NULL,
    close        REAL,
    quote_volume REAL,
    open_interest REAL,
    funding      REAL,
    next_funding_ts INTEGER,
    taker_ls     REAL,
    top_pos_ls   REAL,
    long_score   REAL,
    net          REAL,
    conviction   REAL,
    PRIMARY KEY (ts, symbol)
);
CREATE INDEX IF NOT EXISTS idx_snap_symbol_ts ON snapshots(symbol, ts);

CREATE TABLE IF NOT EXISTS challenge_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL, kind TEXT NOT NULL, symbol TEXT,
    name TEXT NOT NULL DEFAULT 'main',
    title TEXT, body TEXT, payload TEXT
);
CREATE INDEX IF NOT EXISTS idx_ev_id ON challenge_events(id DESC);

CREATE TABLE IF NOT EXISTS pump_calls (
    ts INTEGER NOT NULL, symbol TEXT NOT NULL,
    price_at_call REAL, pump_score REAL, energy REAL, lean REAL,
    target_pct REAL, horizon_ms INTEGER, reasons TEXT,
    resolved_ms INTEGER, max_gain_pct REAL, max_drawdown_pct REAL,
    hours_to_peak INTEGER, final_pct REAL, hit INTEGER, base_rate_pct REAL,
    PRIMARY KEY (ts, symbol)
);
CREATE INDEX IF NOT EXISTS idx_pump_sym ON pump_calls(symbol, ts DESC);
CREATE INDEX IF NOT EXISTS idx_pump_open ON pump_calls(resolved_ms);

CREATE TABLE IF NOT EXISTS challenge_state (
    name TEXT PRIMARY KEY,
    equity REAL, peak_equity REAL, blocked_until_ms INTEGER, updated_ms INTEGER
);

CREATE TABLE IF NOT EXISTS challenge_positions (
    name   TEXT NOT NULL,
    symbol TEXT NOT NULL,
    data   TEXT NOT NULL,
    PRIMARY KEY (name, symbol)
);

CREATE TABLE IF NOT EXISTS challenge_trades (
    name TEXT NOT NULL DEFAULT 'main',
    opened_ms INTEGER NOT NULL,
    closed_ms INTEGER NOT NULL,
    symbol TEXT, direction TEXT, entry REAL, exit REAL, initial_stop REAL,
    qty REAL, gross_pnl REAL, fees REAL, funding REAL, net_pnl REAL,
    r_multiple REAL, outcome TEXT, conviction REAL, equity_after REAL,
    PRIMARY KEY (name, opened_ms, symbol)
);
CREATE INDEX IF NOT EXISTS idx_ch_closed ON challenge_trades(name, closed_ms);

CREATE TABLE IF NOT EXISTS transfers (
    tx          TEXT NOT NULL,
    ts          INTEGER NOT NULL,
    symbol      TEXT,
    token       TEXT,
    usd         REAL,
    direction   TEXT,
    from_entity TEXT,
    to_entity   TEXT,
    from_addr   TEXT,
    to_addr     TEXT,
    PRIMARY KEY (tx, ts, from_addr, to_addr)
);
CREATE INDEX IF NOT EXISTS idx_tf_symbol_ts ON transfers(symbol, ts DESC);
CREATE INDEX IF NOT EXISTS idx_tf_from_ts   ON transfers(from_addr, ts DESC);

CREATE TABLE IF NOT EXISTS alerts (
    ts         INTEGER NOT NULL,
    symbol     TEXT    NOT NULL,
    direction  TEXT    NOT NULL,
    conviction REAL,
    PRIMARY KEY (ts, symbol, direction)
);
CREATE INDEX IF NOT EXISTS idx_alert_sym_dir_ts ON alerts(symbol, direction, ts DESC);

CREATE TABLE IF NOT EXISTS signals (
    ts          INTEGER NOT NULL,
    symbol      TEXT    NOT NULL,
    direction   TEXT,
    long_score  REAL,
    conviction  REAL,
    entry       REAL,
    stop        REAL,
    tp1 REAL, tp2 REAL, tp3 REAL,
    risk_pct    REAL,
    risk_rating TEXT,
    blocks_json TEXT,
    PRIMARY KEY (ts, symbol, direction)
);
"""


class Store:
    def __init__(self, path: str = "radar.db"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self._migrate()
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def _migrate(self) -> None:
        """Bring a single-challenge database up to the named-challenge schema.

        Runs before the schema script so CREATE TABLE IF NOT EXISTS does not
        mask an old table. Everything that already exists becomes the 'main'
        challenge, so live equity and trade history carry over untouched.
        """
        def cols(table: str):
            try:
                return {r[1] for r in self.conn.execute(
                    f"PRAGMA table_info({table})").fetchall()}
            except sqlite3.Error:
                return set()

        # challenge_state: primary key changes, so the table must be rebuilt
        c = cols("challenge_state")
        if c and "name" not in c:
            self.conn.executescript("""
                ALTER TABLE challenge_state RENAME TO challenge_state_old;
                CREATE TABLE challenge_state (
                    name TEXT PRIMARY KEY, equity REAL, peak_equity REAL,
                    blocked_until_ms INTEGER, updated_ms INTEGER);
                INSERT INTO challenge_state (name, equity, peak_equity,
                                             blocked_until_ms, updated_ms)
                    SELECT 'main', equity, peak_equity, blocked_until_ms, updated_ms
                    FROM challenge_state_old;
                DROP TABLE challenge_state_old;
            """)

        c = cols("challenge_positions")
        if c and "name" not in c:
            self.conn.executescript("""
                ALTER TABLE challenge_positions RENAME TO challenge_positions_old;
                CREATE TABLE challenge_positions (
                    name TEXT NOT NULL, symbol TEXT NOT NULL, data TEXT NOT NULL,
                    PRIMARY KEY (name, symbol));
                INSERT INTO challenge_positions (name, symbol, data)
                    SELECT 'main', symbol, data FROM challenge_positions_old;
                DROP TABLE challenge_positions_old;
            """)

        c = cols("challenge_trades")
        if c and "name" not in c:
            self.conn.executescript("""
                ALTER TABLE challenge_trades RENAME TO challenge_trades_old;
                CREATE TABLE challenge_trades (
                    name TEXT NOT NULL DEFAULT 'main',
                    opened_ms INTEGER NOT NULL, closed_ms INTEGER NOT NULL,
                    symbol TEXT, direction TEXT, entry REAL, exit REAL,
                    initial_stop REAL, qty REAL, gross_pnl REAL, fees REAL,
                    funding REAL, net_pnl REAL, r_multiple REAL, outcome TEXT,
                    conviction REAL, equity_after REAL,
                    PRIMARY KEY (name, opened_ms, symbol));
                INSERT INTO challenge_trades SELECT 'main', opened_ms, closed_ms,
                    symbol, direction, entry, exit, initial_stop, qty, gross_pnl,
                    fees, funding, net_pnl, r_multiple, outcome, conviction,
                    equity_after FROM challenge_trades_old;
                DROP TABLE challenge_trades_old;
            """)

        c = cols("challenge_events")
        if c and "name" not in c:
            self.conn.execute(
                "ALTER TABLE challenge_events ADD COLUMN name TEXT "
                "NOT NULL DEFAULT 'main'")
        self.conn.commit()

    def write_snapshots(self, rows: Iterable[dict]) -> int:
        rows = list(rows)
        if not rows:
            return 0
        cols = ["ts", "symbol", "close", "quote_volume", "open_interest", "funding",
                "next_funding_ts", "taker_ls", "top_pos_ls", "long_score", "net",
                "conviction"]
        self.conn.executemany(
            f"INSERT OR REPLACE INTO snapshots ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})",
            [tuple(r.get(c) for c in cols) for r in rows],
        )
        self.conn.commit()
        return len(rows)

    def write_signals(self, rows: Iterable[dict]) -> int:
        rows = list(rows)
        if not rows:
            return 0
        cols = ["ts", "symbol", "direction", "long_score", "conviction", "entry",
                "stop", "tp1", "tp2", "tp3", "risk_pct", "risk_rating", "blocks_json"]
        self.conn.executemany(
            f"INSERT OR REPLACE INTO signals ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})",
            [tuple(r.get(c) for c in cols) for r in rows],
        )
        self.conn.commit()
        return len(rows)

    def oi_series(self, symbol: str, since_ms: Optional[int] = None) -> pd.Series:
        q = "SELECT ts, open_interest FROM snapshots WHERE symbol=?"
        args: list = [symbol]
        if since_ms:
            q += " AND ts>=?"
            args.append(since_ms)
        df = pd.read_sql_query(q + " ORDER BY ts", self.conn, params=args)
        if df.empty:
            return pd.Series(dtype=float)
        idx = pd.to_datetime(df["ts"], unit="ms", utc=True)
        return pd.Series(df["open_interest"].values, index=idx).dropna()

    # ---------------------------------------------------------------- events

    def record_event(self, ts: int, kind: str, symbol: str, title: str,
                     body: str, payload: dict, name: str = "main") -> int:
        import json as _j
        cur = self.conn.execute(
            "INSERT INTO challenge_events (ts, kind, symbol, name, title, body, "
            "payload) VALUES (?,?,?,?,?,?,?)",
            (ts, kind, symbol, name, title, body, _j.dumps(payload, default=str)))
        self.conn.commit()
        return int(cur.lastrowid)

    def events_since(self, since_id: int = 0, limit: int = 50) -> list:
        import json as _j
        cur = self.conn.execute(
            "SELECT id, ts, kind, symbol, title, body, payload, name "
            "FROM challenge_events WHERE id > ? ORDER BY id LIMIT ?",
            (since_id, limit))
        out = []
        for r in cur.fetchall():
            try:
                payload = _j.loads(r[6]) if r[6] else {}
            except Exception:                             # noqa: BLE001
                payload = {}
            out.append({"id": r[0], "ts": r[1], "kind": r[2], "symbol": r[3],
                        "title": r[4], "body": r[5], "payload": payload,
                        "challenge": r[7] if len(r) > 7 else "main"})
        return out

    def latest_event_id(self) -> int:
        cur = self.conn.execute("SELECT COALESCE(MAX(id), 0) FROM challenge_events")
        return int(cur.fetchone()[0])

    # ------------------------------------------------------------------ pump

    def record_pump_call(self, c: dict) -> None:
        cols = ["ts", "symbol", "price_at_call", "pump_score", "energy", "lean",
                "target_pct", "horizon_ms", "reasons"]
        self.conn.execute(
            f"INSERT OR IGNORE INTO pump_calls ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})", tuple(c.get(k) for k in cols))
        self.conn.commit()

    def pump_call_recent(self, symbol: str, since_ms: int) -> bool:
        cur = self.conn.execute(
            "SELECT 1 FROM pump_calls WHERE symbol=? AND ts>=? LIMIT 1",
            (symbol, since_ms))
        return cur.fetchone() is not None

    def pump_calls_to_resolve(self, now_ms: int) -> list:
        cur = self.conn.execute(
            "SELECT * FROM pump_calls WHERE resolved_ms IS NULL "
            "AND (ts + horizon_ms) <= ? ORDER BY ts LIMIT 20", (now_ms,))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def resolve_pump_call(self, ts: int, symbol: str, out: dict) -> None:
        self.conn.execute(
            "UPDATE pump_calls SET resolved_ms=?, max_gain_pct=?, max_drawdown_pct=?, "
            "hours_to_peak=?, final_pct=?, hit=?, base_rate_pct=? "
            "WHERE ts=? AND symbol=?",
            (out["resolved_ms"], out["max_gain_pct"], out["max_drawdown_pct"],
             out["hours_to_peak"], out["final_pct"], out["hit"],
             out.get("base_rate_pct"), ts, symbol))
        self.conn.commit()

    def pump_calls(self, limit: int = 500) -> list:
        cur = self.conn.execute(
            "SELECT * FROM pump_calls ORDER BY ts LIMIT ?", (limit,))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def symbols_seen_near(self, ts_ms: int, window_ms: int = 3_600_000) -> list:
        """Universe members around a moment -- the control group for base rate."""
        cur = self.conn.execute(
            "SELECT DISTINCT symbol FROM snapshots WHERE ts BETWEEN ? AND ? "
            "ORDER BY symbol", (ts_ms - window_ms, ts_ms + window_ms))
        return [r[0] for r in cur.fetchall()]

    # ------------------------------------------------------------- challenge

    def challenge_state(self, name: str = "main"):
        cur = self.conn.execute(
            "SELECT equity, peak_equity, blocked_until_ms FROM challenge_state "
            "WHERE name=?", (name,))
        row = cur.fetchone()
        return ({"equity": row[0], "peak_equity": row[1],
                 "blocked_until_ms": row[2] or 0} if row else None)

    def save_challenge_state(self, equity: float, peak: float, blocked_ms: int,
                             name: str = "main") -> None:
        self.conn.execute(
            "INSERT INTO challenge_state (name, equity, peak_equity, "
            "blocked_until_ms, updated_ms) VALUES (?,?,?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET equity=excluded.equity, "
            "peak_equity=excluded.peak_equity, "
            "blocked_until_ms=excluded.blocked_until_ms, updated_ms=excluded.updated_ms",
            (name, equity, peak, blocked_ms,
             int(pd.Timestamp.utcnow().timestamp() * 1000)))
        self.conn.commit()

    def challenge_open_positions(self, name: str = "main") -> list:
        import json as _j
        cur = self.conn.execute(
            "SELECT data FROM challenge_positions WHERE name=?", (name,))
        return [_j.loads(r[0]) for r in cur.fetchall()]

    def save_challenge_positions(self, positions: list, name: str = "main") -> None:
        import json as _j
        self.conn.execute("DELETE FROM challenge_positions WHERE name=?", (name,))
        self.conn.executemany(
            "INSERT INTO challenge_positions (name, symbol, data) VALUES (?,?,?)",
            [(name, p["symbol"], _j.dumps(p)) for p in positions])
        self.conn.commit()

    def record_challenge_trade(self, t: dict, name: str = "main") -> None:
        t = dict(t); t["name"] = name
        cols = ["name", "opened_ms", "closed_ms", "symbol", "direction", "entry", "exit",
                "initial_stop", "qty", "gross_pnl", "fees", "funding", "net_pnl",
                "r_multiple", "outcome", "conviction", "equity_after"]
        self.conn.execute(
            f"INSERT OR REPLACE INTO challenge_trades ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})", tuple(t.get(c) for c in cols))
        self.conn.commit()

    def challenge_trades(self, limit: int = 1000, name: str = "main") -> list:
        cur = self.conn.execute(
            "SELECT * FROM challenge_trades WHERE name=? ORDER BY closed_ms LIMIT ?",
            (name, limit))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def challenge_trades_since(self, since_ms: int, name: str = "main") -> list:
        cur = self.conn.execute(
            "SELECT * FROM challenge_trades WHERE name=? AND closed_ms>=? "
            "ORDER BY closed_ms", (name, since_ms))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def reset_challenge(self, name: str = "main") -> None:
        self.conn.execute("DELETE FROM challenge_trades WHERE name=?", (name,))
        self.conn.execute("DELETE FROM challenge_positions WHERE name=?", (name,))
        self.conn.execute("DELETE FROM challenge_state WHERE name=?", (name,))
        self.conn.commit()

    def record_transfer(self, tx: str, ts: int, symbol: str, token: str,
                        usd: float, direction: str, from_entity, to_entity,
                        from_addr: str, to_addr: str) -> None:
        """Persist whale transfers. This is what makes the flow data
        backtestable later -- Arkham has no bulk historical export, so the only
        way to get a usable panel is to start recording now."""
        self.conn.execute(
            "INSERT OR IGNORE INTO transfers (tx, ts, symbol, token, usd, "
            "direction, from_entity, to_entity, from_addr, to_addr) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (tx, ts, symbol, token, usd, direction, from_entity, to_entity,
             from_addr, to_addr))
        self.conn.commit()

    def address_last_seen(self, address: str, before_ms: int):
        """Most recent locally recorded activity for an address, before a given
        time. Free dormancy checks for anything we have already observed."""
        cur = self.conn.execute(
            "SELECT MAX(ts) FROM transfers WHERE (from_addr=? OR to_addr=?) "
            "AND ts < ?", (address, address, before_ms))
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else None

    def transfers_df(self, symbol=None, since_ms=None) -> pd.DataFrame:
        q = "SELECT * FROM transfers WHERE 1=1"
        args: list = []
        if symbol:
            q += " AND symbol=?"
            args.append(symbol)
        if since_ms:
            q += " AND ts>=?"
            args.append(since_ms)
        return pd.read_sql_query(q + " ORDER BY ts", self.conn, params=args)

    def record_alert(self, ts: int, symbol: str, direction: str,
                     conviction: float) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO alerts (ts, symbol, direction, conviction) "
            "VALUES (?,?,?,?)", (ts, symbol, direction, conviction))
        self.conn.commit()

    def last_alert(self, symbol: str, direction: str):
        """Most recent alert for this symbol+direction, or None."""
        cur = self.conn.execute(
            "SELECT ts, conviction FROM alerts WHERE symbol=? AND direction=? "
            "ORDER BY ts DESC LIMIT 1", (symbol, direction))
        row = cur.fetchone()
        return (int(row[0]), row[1]) if row else None

    def signals_df(self) -> pd.DataFrame:
        return pd.read_sql_query("SELECT * FROM signals ORDER BY ts", self.conn)

    def close(self) -> None:
        self.conn.close()
