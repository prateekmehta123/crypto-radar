"""
Local snapshot store.

This exists because of a hard constraint: Binance's /futures/data/* endpoints
(open interest, taker long/short, top-trader positioning) only retain the last
30 days. You cannot backtest OI-based signals over 1-3 years from the public
API -- that history does not exist to be fetched.

So the scanner writes every snapshot to SQLite from the first run. After a
month you own a dataset nobody can sell you back, and the OI blocks become
backtestable. Until then, backtests run on kline-derived features (which do go
back years) with the OI blocks disabled.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable, Optional

import pandas as pd

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    ts           INTEGER NOT NULL,
    symbol       TEXT    NOT NULL,
    close        REAL,
    quote_volume REAL,
    open_interest REAL,
    funding      REAL,
    next_funding_ts INTEGER,
    taker_ls     REAL,
    top_pos_ls   REAL,
    long_score   REAL,
    net          REAL,
    conviction   REAL,
    PRIMARY KEY (ts, symbol)
);
CREATE INDEX IF NOT EXISTS idx_snap_symbol_ts ON snapshots(symbol, ts);

CREATE TABLE IF NOT EXISTS challenge_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    equity REAL, peak_equity REAL, blocked_until_ms INTEGER, updated_ms INTEGER
);

CREATE TABLE IF NOT EXISTS challenge_positions (
    symbol TEXT PRIMARY KEY,
    data   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS challenge_trades (
    opened_ms INTEGER NOT NULL,
    closed_ms INTEGER NOT NULL,
    symbol TEXT, direction TEXT, entry REAL, exit REAL, initial_stop REAL,
    qty REAL, gross_pnl REAL, fees REAL, funding REAL, net_pnl REAL,
    r_multiple REAL, outcome TEXT, conviction REAL, equity_after REAL,
    PRIMARY KEY (opened_ms, symbol)
);
CREATE INDEX IF NOT EXISTS idx_ch_closed ON challenge_trades(closed_ms);

CREATE TABLE IF NOT EXISTS transfers (
    tx          TEXT NOT NULL,
    ts          INTEGER NOT NULL,
    symbol      TEXT,
    token       TEXT,
    usd         REAL,
    direction   TEXT,
    from_entity TEXT,
    to_entity   TEXT,
    from_addr   TEXT,
    to_addr     TEXT,
    PRIMARY KEY (tx, ts, from_addr, to_addr)
);
CREATE INDEX IF NOT EXISTS idx_tf_symbol_ts ON transfers(symbol, ts DESC);
CREATE INDEX IF NOT EXISTS idx_tf_from_ts   ON transfers(from_addr, ts DESC);

CREATE TABLE IF NOT EXISTS alerts (
    ts         INTEGER NOT NULL,
    symbol     TEXT    NOT NULL,
    direction  TEXT    NOT NULL,
    conviction REAL,
    PRIMARY KEY (ts, symbol, direction)
);
CREATE INDEX IF NOT EXISTS idx_alert_sym_dir_ts ON alerts(symbol, direction, ts DESC);

CREATE TABLE IF NOT EXISTS signals (
    ts          INTEGER NOT NULL,
    symbol      TEXT    NOT NULL,
    direction   TEXT,
    long_score  REAL,
    conviction  REAL,
    entry       REAL,
    stop        REAL,
    tp1 REAL, tp2 REAL, tp3 REAL,
    risk_pct    REAL,
    risk_rating TEXT,
    blocks_json TEXT,
    PRIMARY KEY (ts, symbol, direction)
);
"""


class Store:
    def __init__(self, path: str = "radar.db"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def write_snapshots(self, rows: Iterable[dict]) -> int:
        rows = list(rows)
        if not rows:
            return 0
        cols = ["ts", "symbol", "close", "quote_volume", "open_interest", "funding",
                "next_funding_ts", "taker_ls", "top_pos_ls", "long_score", "net",
                "conviction"]
        self.conn.executemany(
            f"INSERT OR REPLACE INTO snapshots ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})",
            [tuple(r.get(c) for c in cols) for r in rows],
        )
        self.conn.commit()
        return len(rows)

    def write_signals(self, rows: Iterable[dict]) -> int:
        rows = list(rows)
        if not rows:
            return 0
        cols = ["ts", "symbol", "direction", "long_score", "conviction", "entry",
                "stop", "tp1", "tp2", "tp3", "risk_pct", "risk_rating", "blocks_json"]
        self.conn.executemany(
            f"INSERT OR REPLACE INTO signals ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})",
            [tuple(r.get(c) for c in cols) for r in rows],
        )
        self.conn.commit()
        return len(rows)

    def oi_series(self, symbol: str, since_ms: Optional[int] = None) -> pd.Series:
        q = "SELECT ts, open_interest FROM snapshots WHERE symbol=?"
        args: list = [symbol]
        if since_ms:
            q += " AND ts>=?"
            args.append(since_ms)
        df = pd.read_sql_query(q + " ORDER BY ts", self.conn, params=args)
        if df.empty:
            return pd.Series(dtype=float)
        idx = pd.to_datetime(df["ts"], unit="ms", utc=True)
        return pd.Series(df["open_interest"].values, index=idx).dropna()

    # ------------------------------------------------------------- challenge

    def challenge_state(self):
        cur = self.conn.execute(
            "SELECT equity, peak_equity, blocked_until_ms FROM challenge_state WHERE id=1")
        row = cur.fetchone()
        return ({"equity": row[0], "peak_equity": row[1],
                 "blocked_until_ms": row[2] or 0} if row else None)

    def save_challenge_state(self, equity: float, peak: float, blocked_ms: int) -> None:
        self.conn.execute(
            "INSERT INTO challenge_state (id, equity, peak_equity, blocked_until_ms, "
            "updated_ms) VALUES (1,?,?,?,?) ON CONFLICT(id) DO UPDATE SET "
            "equity=excluded.equity, peak_equity=excluded.peak_equity, "
            "blocked_until_ms=excluded.blocked_until_ms, updated_ms=excluded.updated_ms",
            (equity, peak, blocked_ms, int(pd.Timestamp.utcnow().timestamp() * 1000)))
        self.conn.commit()

    def challenge_open_positions(self) -> list:
        import json as _j
        cur = self.conn.execute("SELECT data FROM challenge_positions")
        return [_j.loads(r[0]) for r in cur.fetchall()]

    def save_challenge_positions(self, positions: list) -> None:
        import json as _j
        self.conn.execute("DELETE FROM challenge_positions")
        self.conn.executemany(
            "INSERT INTO challenge_positions (symbol, data) VALUES (?,?)",
            [(p["symbol"], _j.dumps(p)) for p in positions])
        self.conn.commit()

    def record_challenge_trade(self, t: dict) -> None:
        cols = ["opened_ms", "closed_ms", "symbol", "direction", "entry", "exit",
                "initial_stop", "qty", "gross_pnl", "fees", "funding", "net_pnl",
                "r_multiple", "outcome", "conviction", "equity_after"]
        self.conn.execute(
            f"INSERT OR REPLACE INTO challenge_trades ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})", tuple(t.get(c) for c in cols))
        self.conn.commit()

    def challenge_trades(self, limit: int = 1000) -> list:
        cur = self.conn.execute(
            "SELECT * FROM challenge_trades ORDER BY closed_ms LIMIT ?", (limit,))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def challenge_trades_since(self, since_ms: int) -> list:
        cur = self.conn.execute(
            "SELECT * FROM challenge_trades WHERE closed_ms>=? ORDER BY closed_ms",
            (since_ms,))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def reset_challenge(self) -> None:
        self.conn.execute("DELETE FROM challenge_trades")
        self.conn.execute("DELETE FROM challenge_positions")
        self.conn.execute("DELETE FROM challenge_state")
        self.conn.commit()

    def record_transfer(self, tx: str, ts: int, symbol: str, token: str,
                        usd: float, direction: str, from_entity, to_entity,
                        from_addr: str, to_addr: str) -> None:
        """Persist whale transfers. This is what makes the flow data
        backtestable later -- Arkham has no bulk historical export, so the only
        way to get a usable panel is to start recording now."""
        self.conn.execute(
            "INSERT OR IGNORE INTO transfers (tx, ts, symbol, token, usd, "
            "direction, from_entity, to_entity, from_addr, to_addr) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (tx, ts, symbol, token, usd, direction, from_entity, to_entity,
             from_addr, to_addr))
        self.conn.commit()

    def address_last_seen(self, address: str, before_ms: int):
        """Most recent locally recorded activity for an address, before a given
        time. Free dormancy checks for anything we have already observed."""
        cur = self.conn.execute(
            "SELECT MAX(ts) FROM transfers WHERE (from_addr=? OR to_addr=?) "
            "AND ts < ?", (address, address, before_ms))
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else None

    def transfers_df(self, symbol=None, since_ms=None) -> pd.DataFrame:
        q = "SELECT * FROM transfers WHERE 1=1"
        args: list = []
        if symbol:
            q += " AND symbol=?"
            args.append(symbol)
        if since_ms:
            q += " AND ts>=?"
            args.append(since_ms)
        return pd.read_sql_query(q + " ORDER BY ts", self.conn, params=args)

    def record_alert(self, ts: int, symbol: str, direction: str,
                     conviction: float) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO alerts (ts, symbol, direction, conviction) "
            "VALUES (?,?,?,?)", (ts, symbol, direction, conviction))
        self.conn.commit()

    def last_alert(self, symbol: str, direction: str):
        """Most recent alert for this symbol+direction, or None."""
        cur = self.conn.execute(
            "SELECT ts, conviction FROM alerts WHERE symbol=? AND direction=? "
            "ORDER BY ts DESC LIMIT 1", (symbol, direction))
        row = cur.fetchone()
        return (int(row[0]), row[1]) if row else None

    def signals_df(self) -> pd.DataFrame:
        return pd.read_sql_query("SELECT * FROM signals ORDER BY ts", self.conn)

    def close(self) -> None:
        self.conn.close()
