"""
Local snapshot store.

This exists because of a hard constraint: Binance's /futures/data/* endpoints
(open interest, taker long/short, top-trader positioning) only retain the last
30 days. You cannot backtest OI-based signals over 1-3 years from the public
API -- that history does not exist to be fetched.

So the scanner writes every snapshot to SQLite from the first run. After a
month you own a dataset nobody can sell you back, and the OI blocks become
backtestable. Until then, backtests run on kline-derived features (which do go
back years) with the OI blocks disabled.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable, Optional

import pandas as pd

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    ts           INTEGER NOT NULL,
    symbol       TEXT    NOT NULL,
    close        REAL,
    quote_volume REAL,
    open_interest REAL,
    funding      REAL,
    next_funding_ts INTEGER,
    taker_ls     REAL,
    top_pos_ls   REAL,
    long_score   REAL,
    net          REAL,
    conviction   REAL,
    PRIMARY KEY (ts, symbol)
);
CREATE INDEX IF NOT EXISTS idx_snap_symbol_ts ON snapshots(symbol, ts);

CREATE TABLE IF NOT EXISTS transfers (
    tx          TEXT NOT NULL,
    ts          INTEGER NOT NULL,
    symbol      TEXT,
    token       TEXT,
    usd         REAL,
    direction   TEXT,
    from_entity TEXT,
    to_entity   TEXT,
    from_addr   TEXT,
    to_addr     TEXT,
    PRIMARY KEY (tx, ts, from_addr, to_addr)
);
CREATE INDEX IF NOT EXISTS idx_tf_symbol_ts ON transfers(symbol, ts DESC);
CREATE INDEX IF NOT EXISTS idx_tf_from_ts   ON transfers(from_addr, ts DESC);

CREATE TABLE IF NOT EXISTS alerts (
    ts         INTEGER NOT NULL,
    symbol     TEXT    NOT NULL,
    direction  TEXT    NOT NULL,
    conviction REAL,
    PRIMARY KEY (ts, symbol, direction)
);
CREATE INDEX IF NOT EXISTS idx_alert_sym_dir_ts ON alerts(symbol, direction, ts DESC);

CREATE TABLE IF NOT EXISTS signals (
    ts          INTEGER NOT NULL,
    symbol      TEXT    NOT NULL,
    direction   TEXT,
    long_score  REAL,
    conviction  REAL,
    entry       REAL,
    stop        REAL,
    tp1 REAL, tp2 REAL, tp3 REAL,
    risk_pct    REAL,
    risk_rating TEXT,
    blocks_json TEXT,
    PRIMARY KEY (ts, symbol, direction)
);
"""


class Store:
    def __init__(self, path: str = "radar.db"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def write_snapshots(self, rows: Iterable[dict]) -> int:
        rows = list(rows)
        if not rows:
            return 0
        cols = ["ts", "symbol", "close", "quote_volume", "open_interest", "funding",
                "next_funding_ts", "taker_ls", "top_pos_ls", "long_score", "net",
                "conviction"]
        self.conn.executemany(
            f"INSERT OR REPLACE INTO snapshots ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})",
            [tuple(r.get(c) for c in cols) for r in rows],
        )
        self.conn.commit()
        return len(rows)

    def write_signals(self, rows: Iterable[dict]) -> int:
        rows = list(rows)
        if not rows:
            return 0
        cols = ["ts", "symbol", "direction", "long_score", "conviction", "entry",
                "stop", "tp1", "tp2", "tp3", "risk_pct", "risk_rating", "blocks_json"]
        self.conn.executemany(
            f"INSERT OR REPLACE INTO signals ({','.join(cols)}) "
            f"VALUES ({','.join('?' * len(cols))})",
            [tuple(r.get(c) for c in cols) for r in rows],
        )
        self.conn.commit()
        return len(rows)

    def oi_series(self, symbol: str, since_ms: Optional[int] = None) -> pd.Series:
        q = "SELECT ts, open_interest FROM snapshots WHERE symbol=?"
        args: list = [symbol]
        if since_ms:
            q += " AND ts>=?"
            args.append(since_ms)
        df = pd.read_sql_query(q + " ORDER BY ts", self.conn, params=args)
        if df.empty:
            return pd.Series(dtype=float)
        idx = pd.to_datetime(df["ts"], unit="ms", utc=True)
        return pd.Series(df["open_interest"].values, index=idx).dropna()

    def record_transfer(self, tx: str, ts: int, symbol: str, token: str,
                        usd: float, direction: str, from_entity, to_entity,
                        from_addr: str, to_addr: str) -> None:
        """Persist whale transfers. This is what makes the flow data
        backtestable later -- Arkham has no bulk historical export, so the only
        way to get a usable panel is to start recording now."""
        self.conn.execute(
            "INSERT OR IGNORE INTO transfers (tx, ts, symbol, token, usd, "
            "direction, from_entity, to_entity, from_addr, to_addr) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (tx, ts, symbol, token, usd, direction, from_entity, to_entity,
             from_addr, to_addr))
        self.conn.commit()

    def address_last_seen(self, address: str, before_ms: int):
        """Most recent locally recorded activity for an address, before a given
        time. Free dormancy checks for anything we have already observed."""
        cur = self.conn.execute(
            "SELECT MAX(ts) FROM transfers WHERE (from_addr=? OR to_addr=?) "
            "AND ts < ?", (address, address, before_ms))
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else None

    def transfers_df(self, symbol=None, since_ms=None) -> pd.DataFrame:
        q = "SELECT * FROM transfers WHERE 1=1"
        args: list = []
        if symbol:
            q += " AND symbol=?"
            args.append(symbol)
        if since_ms:
            q += " AND ts>=?"
            args.append(since_ms)
        return pd.read_sql_query(q + " ORDER BY ts", self.conn, params=args)

    def record_alert(self, ts: int, symbol: str, direction: str,
                     conviction: float) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO alerts (ts, symbol, direction, conviction) "
            "VALUES (?,?,?,?)", (ts, symbol, direction, conviction))
        self.conn.commit()

    def last_alert(self, symbol: str, direction: str):
        """Most recent alert for this symbol+direction, or None."""
        cur = self.conn.execute(
            "SELECT ts, conviction FROM alerts WHERE symbol=? AND direction=? "
            "ORDER BY ts DESC LIMIT 1", (symbol, direction))
        row = cur.fetchone()
        return (int(row[0]), row[1]) if row else None

    def signals_df(self) -> pd.DataFrame:
        return pd.read_sql_query("SELECT * FROM signals ORDER BY ts", self.conn)

    def close(self) -> None:
        self.conn.close()
