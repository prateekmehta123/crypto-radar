"""
Feature engineering.

Design rule that matters more than any single indicator:
`compute_features` returns a DataFrame indexed by bar, and the live scanner
uses `.iloc[-1]` of exactly the same output the backtester trains on. There
is no separate "live" code path, so live and backtest cannot drift apart.

Every window here looks backwards only. Anything that would peek at the
current bar's close before it is closed is shifted. The backtester drops the
final (still forming) bar.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

KLINE_COLS = [
    "open_time", "open", "high", "low", "close", "volume", "close_time",
    "quote_volume", "trades", "taker_buy_base", "taker_buy_quote", "ignore",
]


def klines_to_df(raw: list) -> pd.DataFrame:
    df = pd.DataFrame(raw, columns=KLINE_COLS)
    num = ["open", "high", "low", "close", "volume", "quote_volume",
           "trades", "taker_buy_base", "taker_buy_quote"]
    df[num] = df[num].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df["close_time"] = pd.to_datetime(df["close_time"], unit="ms", utc=True)
    return df.set_index("open_time")[num + ["close_time"]]


# --------------------------------------------------------------- primitives

def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False, min_periods=n).mean()


def true_range(df: pd.DataFrame) -> pd.Series:
    pc = df["close"].shift(1)
    return pd.concat([
        df["high"] - df["low"],
        (df["high"] - pc).abs(),
        (df["low"] - pc).abs(),
    ], axis=1).max(axis=1)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    return true_range(df).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def rsi(s: pd.Series, n: int = 14) -> pd.Series:
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    rs = up / dn.replace(0, np.nan)
    return 100 - 100 / (1 + rs)


def rolling_vwap(df: pd.DataFrame, n: int) -> pd.Series:
    tp = (df["high"] + df["low"] + df["close"]) / 3
    pv = (tp * df["volume"]).rolling(n, min_periods=max(2, n // 4)).sum()
    v = df["volume"].rolling(n, min_periods=max(2, n // 4)).sum()
    return pv / v.replace(0, np.nan)


def zscore(s: pd.Series, n: int) -> pd.Series:
    m = s.rolling(n, min_periods=max(5, n // 4)).mean()
    sd = s.rolling(n, min_periods=max(5, n // 4)).std(ddof=0)
    return (s - m) / sd.replace(0, np.nan)


def pct_rank(s: pd.Series, n: int) -> pd.Series:
    """Rank of the current value within the trailing n values, 0..1."""
    return s.rolling(n, min_periods=max(10, n // 4)).rank(pct=True)


# ------------------------------------------------------- structure helpers

def swing_levels(df: pd.DataFrame, left: int = 3, right: int = 3):
    """Confirmed fractal swings. A swing at bar i is only known at i+right,
    so both series are shifted by `right` to stay causal."""
    h, l = df["high"], df["low"]
    is_hi = h == h.rolling(left + right + 1, center=True).max()
    is_lo = l == l.rolling(left + right + 1, center=True).min()
    sh = h.where(is_hi).shift(right).ffill()
    sl = l.where(is_lo).shift(right).ffill()
    return sh, sl


def volume_profile(df: pd.DataFrame, lookback: int = 240, bins: int = 48):
    """POC / value-area high / value-area low over the trailing window.

    Approximates each bar's volume as uniformly spread across its range,
    which is the honest version -- true volume-at-price needs tick data.
    Returns three arrays aligned to df.index (NaN until the window fills).
    """
    n = len(df)
    poc = np.full(n, np.nan)
    vah = np.full(n, np.nan)
    val = np.full(n, np.nan)
    hi, lo, vol = df["high"].values, df["low"].values, df["volume"].values

    for i in range(lookback, n):
        s = slice(i - lookback + 1, i + 1)
        h, l, v = hi[s], lo[s], vol[s]
        top, bot = h.max(), l.min()
        if not np.isfinite(top) or top <= bot:
            continue
        edges = np.linspace(bot, top, bins + 1)
        centers = (edges[:-1] + edges[1:]) / 2
        hist = np.zeros(bins)
        # spread each bar's volume across the bins its range touches
        lo_idx = np.clip(np.searchsorted(edges, l, "right") - 1, 0, bins - 1)
        hi_idx = np.clip(np.searchsorted(edges, h, "right") - 1, 0, bins - 1)
        for a, b, vv in zip(lo_idx, hi_idx, v):
            span = b - a + 1
            hist[a:b + 1] += vv / span
        total = hist.sum()
        if total <= 0:
            continue
        k = int(hist.argmax())
        poc[i] = centers[k]
        # grow outward from POC until 70% of volume is enclosed
        acc, a, b = hist[k], k, k
        while acc < 0.70 * total and (a > 0 or b < bins - 1):
            left = hist[a - 1] if a > 0 else -1.0
            right = hist[b + 1] if b < bins - 1 else -1.0
            if right >= left:
                b += 1
                acc += hist[b]
            else:
                a -= 1
                acc += hist[a]
        val[i] = centers[a]
        vah[i] = centers[b]
    return (pd.Series(poc, index=df.index),
            pd.Series(vah, index=df.index),
            pd.Series(val, index=df.index))


def liquidity_targets(df: pd.DataFrame, lookback: int = 96, tol: float = 0.0015):
    """Clusters of near-equal highs/lows in the trailing window -- the places
    resting stops most plausibly sit. Returns nearest cluster above and below.

    This is an inference from price structure, not a liquidation heatmap.
    Binance does not publish resting stop orders and nobody can see them.
    """
    n = len(df)
    up = np.full(n, np.nan)
    dn = np.full(n, np.nan)
    hi, lo, cl = df["high"].values, df["low"].values, df["close"].values
    for i in range(lookback, n):
        s = slice(i - lookback + 1, i + 1)
        c = cl[i]
        h = np.sort(hi[s])
        candidates = h[h > c * (1 + tol)]
        if candidates.size:
            # nearest level with at least one near-equal twin
            for lvl in candidates:
                twins = np.abs(candidates - lvl) <= lvl * tol
                if twins.sum() >= 2:
                    up[i] = lvl
                    break
            else:
                up[i] = candidates[0]
        l = np.sort(lo[s])[::-1]
        candidates = l[l < c * (1 - tol)]
        if candidates.size:
            for lvl in candidates:
                twins = np.abs(candidates - lvl) <= lvl * tol
                if twins.sum() >= 2:
                    dn[i] = lvl
                    break
            else:
                dn[i] = candidates[0]
    return pd.Series(up, index=df.index), pd.Series(dn, index=df.index)


# ------------------------------------------------------------ main builder

def compute_features(df: pd.DataFrame, bars_per_hour: float = 4.0) -> pd.DataFrame:
    """Price/volume/orderflow features derivable from klines alone.

    Klines carry `taker_buy_base`, so CVD and taker imbalance are available
    for the full multi-year kline history -- unlike the /futures/data
    endpoints, which only retain 30 days.
    """
    f = pd.DataFrame(index=df.index)
    c, h, l, v = df["close"], df["high"], df["low"], df["volume"]
    bph = bars_per_hour

    f["close"] = c
    f["quote_volume"] = df["quote_volume"]

    # --- trend
    e20, e50, e200 = ema(c, 20), ema(c, 50), ema(c, 200)
    f["ema20_dist"] = c / e20 - 1
    f["ema50_dist"] = c / e50 - 1
    f["ema200_dist"] = c / e200 - 1
    f["ema_stack"] = (
        (c > e20).astype(float) + (e20 > e50).astype(float) + (e50 > e200).astype(float)
        - (c < e20).astype(float) - (e20 < e50).astype(float) - (e50 < e200).astype(float)
    ) / 3.0                                        # -1 fully bearish .. +1 fully bullish

    vwap_d = rolling_vwap(df, int(24 * bph))
    f["vwap_dist"] = c / vwap_d - 1

    # --- momentum
    for hrs in (1, 4, 24):
        f[f"ret_{hrs}h"] = c.pct_change(int(hrs * bph))
    f["rsi14"] = rsi(c, 14)

    # --- volatility
    a = atr(df, 14)
    f["atr_pct"] = a / c
    f["atr_expansion"] = a / a.rolling(int(24 * bph), min_periods=10).mean()
    bb_mid = c.rolling(20, min_periods=20).mean()
    bb_sd = c.rolling(20, min_periods=20).std(ddof=0)
    f["bb_width"] = (4 * bb_sd) / bb_mid
    f["bb_squeeze_pctile"] = pct_rank(f["bb_width"], int(24 * 7 * bph))
    f["realized_vol"] = c.pct_change().rolling(int(24 * bph), min_periods=10).std(ddof=0)

    # --- volume / order flow (from kline taker fields)
    f["vol_z"] = zscore(v, int(24 * bph))
    taker_buy = df["taker_buy_base"]
    taker_sell = v - taker_buy
    f["taker_buy_ratio"] = taker_buy / v.replace(0, np.nan)
    delta = taker_buy - taker_sell
    f["delta_norm"] = delta / v.replace(0, np.nan)
    cvd = delta.cumsum()
    f["cvd"] = cvd
    f["cvd_slope_1h"] = (cvd - cvd.shift(int(bph))) / v.rolling(int(bph)).sum().replace(0, np.nan)
    f["cvd_slope_4h"] = (cvd - cvd.shift(int(4 * bph))) / v.rolling(int(4 * bph)).sum().replace(0, np.nan)

    # CVD/price divergence: price making highs while CVD is not (or vice versa)
    win = int(4 * bph)
    price_rank = pct_rank(c, win)
    cvd_rank = pct_rank(cvd, win)
    f["cvd_price_divergence"] = cvd_rank - price_rank

    # --- structure
    sh, sl = swing_levels(df, 3, 3)
    f["swing_high"] = sh
    f["swing_low"] = sl
    f["dist_swing_high"] = c / sh - 1
    f["dist_swing_low"] = c / sl - 1
    f["broke_swing_high"] = (c > sh).astype(float)
    f["broke_swing_low"] = (c < sl).astype(float)

    poc, vah, val = volume_profile(df, lookback=int(48 * bph), bins=48)
    f["poc"], f["vah"], f["val"] = poc, vah, val
    f["poc_dist"] = c / poc - 1
    f["in_value_area"] = ((c <= vah) & (c >= val)).astype(float)

    liq_up, liq_dn = liquidity_targets(df, lookback=int(24 * bph))
    f["liq_up"], f["liq_dn"] = liq_up, liq_dn
    f["liq_up_dist"] = liq_up / c - 1
    f["liq_dn_dist"] = 1 - liq_dn / c

    # --- convenience columns used by the setup builder
    f["atr"] = a
    f["high"], f["low"] = h, l
    return f


def add_relative_strength(f: pd.DataFrame, btc: pd.DataFrame) -> pd.DataFrame:
    """Return vs BTC over matching windows, and beta to BTC."""
    f = f.copy()
    for hrs in (1, 4, 24):
        col = f"ret_{hrs}h"
        b = btc[col].reindex(f.index)
        f[f"rs_{hrs}h"] = f[col] - b
    r = f["close"].pct_change()
    rb = btc["close"].pct_change().reindex(f.index)
    cov = r.rolling(96, min_periods=30).cov(rb)
    var = rb.rolling(96, min_periods=30).var(ddof=0)
    f["btc_beta"] = cov / var.replace(0, np.nan)
    f["btc_corr"] = r.rolling(96, min_periods=30).corr(rb)
    return f


def add_derivatives(f: pd.DataFrame, oi: pd.Series | None,
                    funding: float | None, taker_ls: float | None,
                    top_pos_ls: float | None,
                    bars_per_hour: float = 4.0) -> pd.DataFrame:
    """Attach open-interest / funding / positioning features.

    `oi` is a Series of open interest indexed like `f` (from openInterestHist,
    30-day retention). When it is None -- e.g. during a multi-year backtest --
    every OI column is NaN and the scorer's OI block contributes nothing. That
    is deliberate: the model must be able to run without OI, because OI history
    beyond 30 days does not exist unless you have been recording it.
    """
    f = f.copy()
    bph = bars_per_hour
    if oi is not None and len(oi.dropna()) > 5:
        oi = oi.reindex(f.index).ffill()
        f["oi"] = oi
        for lbl, bars in (("5m", 1), ("15m", 3), ("1h", int(bph)), ("4h", int(4 * bph))):
            f[f"oi_chg_{lbl}"] = oi.pct_change(max(1, bars))
        f["oi_z_24h"] = zscore(oi.pct_change(), int(24 * bph))
        # price/OI regime -- the four-quadrant read
        dp = f["close"].pct_change(int(bph))
        do = f["oi_chg_1h"]
        f["regime_new_longs"] = ((dp > 0) & (do > 0)).astype(float)
        f["regime_new_shorts"] = ((dp < 0) & (do > 0)).astype(float)
        f["regime_short_cover"] = ((dp > 0) & (do < 0)).astype(float)
        f["regime_long_liq"] = ((dp < 0) & (do < 0)).astype(float)
    else:
        for col in ["oi", "oi_chg_5m", "oi_chg_15m", "oi_chg_1h", "oi_chg_4h",
                    "oi_z_24h", "regime_new_longs", "regime_new_shorts",
                    "regime_short_cover", "regime_long_liq"]:
            f[col] = np.nan

    f["funding"] = funding if funding is not None else np.nan
    f["taker_ls_ratio"] = taker_ls if taker_ls is not None else np.nan
    f["top_pos_ls_ratio"] = top_pos_ls if top_pos_ls is not None else np.nan
    return f


def add_funding_series(f: pd.DataFrame, funding_hist: pd.Series | None) -> pd.DataFrame:
    """Historical funding (available for years) as a time series feature."""
    f = f.copy()
    if funding_hist is None or funding_hist.empty:
        f["funding"] = np.nan
        f["funding_z_7d"] = np.nan
        f["funding_cum_24h"] = np.nan
        return f
    fr = funding_hist.reindex(f.index.union(funding_hist.index)).sort_index().ffill()
    fr = fr.reindex(f.index)
    f["funding"] = fr
    f["funding_z_7d"] = zscore(fr, 21 * 8)      # 21 funding periods/wk at 8h
    f["funding_cum_24h"] = fr.rolling(3 * 8, min_periods=1).sum()
    return f
