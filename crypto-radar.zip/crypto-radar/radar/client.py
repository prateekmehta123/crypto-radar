"""
Binance USDⓈ-M Futures public market-data client.

No API keys. Every endpoint here is public market data.

Two independent rate limits are enforced:
  1. /fapi/*          -> IP REQUEST_WEIGHT, default 2400 per minute
  2. /futures/data/*  -> separate IP limit, ~1000 requests per 5 minutes
Both are configurable because Binance changes them. The client also reads
the X-MBX-USED-WEIGHT-1M response header and self-throttles if it is
running hot, and backs off on 418/429.
"""

from __future__ import annotations

import logging
import os
import random
import threading
import time
from collections import deque
from typing import Any, Dict, List, Optional

import requests

log = logging.getLogger("radar.client")

FAPI = "https://fapi.binance.com"

# Alternate hosts, useful if the primary is geo-blocked or flaky.
MIRRORS = [
    "https://fapi.binance.com",
    "https://fapi1.binance.com",
    "https://fapi2.binance.com",
]


class GeoBlockedError(RuntimeError):
    """Raised on HTTP 451 -- the host IP is in a Binance-restricted location."""


class _Bucket:
    """Sliding-window counter. Blocks until the request fits in the window."""

    def __init__(self, capacity: float, window_s: float, name: str):
        self.capacity = float(capacity)
        self.window = float(window_s)
        self.name = name
        self._events: deque[tuple[float, float]] = deque()  # (ts, cost)
        self._used = 0.0
        self._lock = threading.Lock()

    def _evict(self, now: float) -> None:
        while self._events and self._events[0][0] <= now - self.window:
            _, cost = self._events.popleft()
            self._used -= cost

    def acquire(self, cost: float = 1.0) -> None:
        while True:
            with self._lock:
                now = time.time()
                self._evict(now)
                if self._used + cost <= self.capacity:
                    self._events.append((now, cost))
                    self._used += cost
                    return
                oldest = self._events[0][0]
                sleep_for = max(0.02, oldest + self.window - now)
            log.debug("rate limit %s full, sleeping %.2fs", self.name, sleep_for)
            time.sleep(min(sleep_for, 5.0))

    def penalise(self, seconds: float) -> None:
        """Burn the whole bucket for `seconds` after a 429."""
        with self._lock:
            now = time.time()
            self._events.append((now + seconds - self.window, self.capacity))
            self._used += self.capacity


class BinanceFutures:
    def __init__(
        self,
        weight_per_min: int = 2000,          # headroom under the 2400 default
        futures_data_per_5min: int = 800,    # headroom under ~1000/5min
        timeout: float = 12.0,
        max_retries: int = 4,
        base_url: str = FAPI,
    ):
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries
        self._w = _Bucket(weight_per_min, 60, "fapi-weight")
        self._fd = _Bucket(futures_data_per_5min, 300, "futures-data")
        self._s = requests.Session()
        self._s.headers.update({"User-Agent": "crypto-radar/1.0"})
        # Binance blocks the Futures API from some regions (HTTP 451). Set
        # BINANCE_PROXY to route egress through a permitted region, e.g.
        # http://user:pass@host:port or socks5h://host:1080
        proxy = os.environ.get("BINANCE_PROXY", "").strip()
        if proxy:
            self._s.proxies.update({"http": proxy, "https": proxy})
            log.info("routing Binance requests through proxy")
        self.last_used_weight = 0

    # ------------------------------------------------------------------ core

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None,
             weight: float = 1.0) -> Any:
        is_fdata = path.startswith("/futures/data")
        for attempt in range(self.max_retries):
            if is_fdata:
                self._fd.acquire(1.0)
            else:
                self._w.acquire(weight)
            try:
                r = self._s.get(self.base_url + path, params=params,
                                timeout=self.timeout)
            except requests.RequestException as e:
                log.warning("network error %s %s: %s", path, params, e)
                time.sleep(0.6 * (2 ** attempt) + random.random() * 0.3)
                continue

            uw = r.headers.get("X-MBX-USED-WEIGHT-1M")
            if uw:
                try:
                    self.last_used_weight = int(uw)
                except ValueError:
                    pass

            if r.status_code == 200:
                return r.json()

            if r.status_code in (418, 429):
                retry_after = float(r.headers.get("Retry-After", 10))
                log.warning("HTTP %s on %s, backing off %.0fs",
                            r.status_code, path, retry_after)
                (self._fd if is_fdata else self._w).penalise(retry_after)
                time.sleep(retry_after)
                continue

            if r.status_code == 451:
                raise GeoBlockedError(
                    "Binance returned HTTP 451: this server's IP is in a "
                    "restricted location. The Futures API has no public mirror "
                    "for blocked regions -- set BINANCE_PROXY to egress from a "
                    "permitted region, or host elsewhere. See DEPLOY.md.")

            if 400 <= r.status_code < 500:
                # Bad symbol / unsupported params: do not retry.
                log.debug("HTTP %s on %s %s -> %s",
                          r.status_code, path, params, r.text[:200])
                return None

            time.sleep(0.6 * (2 ** attempt))
        return None

    # ------------------------------------------------------- bulk endpoints
    # These return every symbol in one request and are how we keep the
    # request count sane.

    def exchange_info(self) -> Optional[dict]:
        return self._get("/fapi/v1/exchangeInfo", weight=1)

    def ticker_24hr_all(self) -> Optional[List[dict]]:
        """24h stats for every symbol. Weight 40."""
        return self._get("/fapi/v1/ticker/24hr", weight=40)

    def premium_index_all(self) -> Optional[List[dict]]:
        """Mark price, index price, last & next funding for every symbol. Weight 10."""
        return self._get("/fapi/v1/premiumIndex", weight=10)

    # ------------------------------------------------------ per-symbol data

    def klines(self, symbol: str, interval: str = "15m", limit: int = 500,
               start_ms: Optional[int] = None,
               end_ms: Optional[int] = None) -> Optional[List[list]]:
        weight = 1 if limit <= 100 else 2 if limit <= 500 else 5 if limit <= 1000 else 10
        p: Dict[str, Any] = {"symbol": symbol, "interval": interval, "limit": limit}
        if start_ms:
            p["startTime"] = start_ms
        if end_ms:
            p["endTime"] = end_ms
        return self._get("/fapi/v1/klines", p, weight=weight)

    def funding_rate_history(self, symbol: str, limit: int = 100,
                             start_ms: Optional[int] = None,
                             end_ms: Optional[int] = None) -> Optional[List[dict]]:
        """Realised funding. Goes back years -- usable for long backtests."""
        p: Dict[str, Any] = {"symbol": symbol, "limit": limit}
        if start_ms:
            p["startTime"] = start_ms
        if end_ms:
            p["endTime"] = end_ms
        return self._get("/fapi/v1/fundingRate", p, weight=1)

    def depth(self, symbol: str, limit: int = 500) -> Optional[dict]:
        weight = 2 if limit <= 50 else 5 if limit <= 100 else 10 if limit <= 500 else 20
        return self._get("/fapi/v1/depth",
                         {"symbol": symbol, "limit": limit}, weight=weight)

    # ------------------------- /futures/data/* : ONLY LAST 30 DAYS AVAILABLE

    def open_interest_hist(self, symbol: str, period: str = "5m",
                           limit: int = 60) -> Optional[List[dict]]:
        return self._get("/futures/data/openInterestHist",
                         {"symbol": symbol, "period": period, "limit": limit})

    def taker_long_short_ratio(self, symbol: str, period: str = "5m",
                               limit: int = 30) -> Optional[List[dict]]:
        return self._get("/futures/data/takerlongshortRatio",
                         {"symbol": symbol, "period": period, "limit": limit})

    def top_trader_position_ratio(self, symbol: str, period: str = "5m",
                                  limit: int = 30) -> Optional[List[dict]]:
        return self._get("/futures/data/topLongShortPositionRatio",
                         {"symbol": symbol, "period": period, "limit": limit})

    def global_long_short_account_ratio(self, symbol: str, period: str = "5m",
                                        limit: int = 30) -> Optional[List[dict]]:
        return self._get("/futures/data/globalLongShortAccountRatio",
                         {"symbol": symbol, "period": period, "limit": limit})
