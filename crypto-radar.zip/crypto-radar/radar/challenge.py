"""
The Challenge: forward paper-trading on live signals, BTCUSDT and ETHUSDT only.

Why this matters more than the backtester
-----------------------------------------
A backtest can be wrong in ways you cannot see. Lookahead creeps in through a
shifted window; survivorship creeps in through the symbol list; and every
parameter you tried and discarded quietly fits the model to the data. This
cannot happen here. The signal is recorded before the outcome exists, so the
result is the real thing rather than a reconstruction of it.

The cost is time. A backtest gives you 500 trades this afternoon; this gives
you maybe 20 in a month. Both are worth having, and they answer different
questions: the backtest asks "was there ever an edge", this asks "is there one
now, at the fills I would actually get".

Risk rules, and why each exists
-------------------------------
* **Fixed fractional risk.** Every trade risks the same % of *current* equity,
  so size shrinks after losses and grows after wins. This is the single most
  important rule here -- it makes ruin arithmetically very hard.
* **Stop first, size second.** The stop is set by structure and ATR. Position
  size is then derived from it. Never the other way round; sizing first and
  then placing a stop where it "feels right" is how accounts die.
* **Partial at 1R, stop to breakeven.** Half off at 1R, stop moves to entry.
  Converts a winner into a free option and is why the win rate here will read
  lower than the profit factor suggests.
* **Daily loss limit.** Trading stops for the day after -2R. Loss limits exist
  because the impulse to make it back is strongest exactly when judgement is
  worst.
* **One position per symbol, no adding.** No pyramiding, no averaging down.
  Averaging down turns a small planned loss into an unplanned large one.
* **Costs charged on everything.** Taker fees both sides, slippage, and funding
  actually paid while the position was open. Ignore these and a coin-flip
  strategy looks profitable.

Exits are evaluated against 1-minute klines, walked bar by bar, with the same
pessimistic same-bar rule the backtester uses: if a bar's range covers both the
stop and the target, it counts as the stop. Without tick data you cannot know
which came first, and assuming the good one is how paper trading flatters
itself.
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .client import BinanceFutures
from .features import klines_to_df

log = logging.getLogger("radar.challenge")

SYMBOLS = ("BTCUSDT", "ETHUSDT")


SCALP_SYMBOLS = ("BTCUSDT", "ETHUSDT")


@dataclass
class RiskConfig:
    starting_equity: float = 10_000.0
    risk_per_trade_pct: float = 1.0      # % of current equity at risk to the stop
    max_leverage: float = 5.0            # cap on notional / equity
    atr_mult_stop: float = 1.5
    tp1_r: float = 1.0                   # take half here
    tp2_r: float = 2.5                   # rest here
    partial_fraction: float = 0.5
    breakeven_after_tp1: bool = True
    max_concurrent: int = 2              # one per symbol
    max_trades_per_day: int = 4
    daily_loss_limit_r: float = 2.0      # stop for the day at -2R realised
    max_hold_hours: float = 24.0
    min_conviction: float = 0.25
    cooldown_minutes_after_loss: float = 60.0
    taker_fee: float = 0.00045
    slippage: float = 0.00015            # BTC/ETH are deep; alts would be worse
    label: str = "Swing"
    timeframe: str = "15m"               # signals are read off this chart
    blurb: str = ""
    # Correlation control. BTC and ETH typically run 0.85-0.95 correlated, so
    # two same-direction positions are close to one double-sized bet rather
    # than two independent ones.
    correlation_threshold: float = 0.6   # below this, treat as independent
    max_correlated_risk_pct: float = 1.2  # total % of equity at risk in one cluster
    correlation_lookback: int = 168      # 1h bars ~ one week
    min_viable_risk_frac: float = 0.20   # below this fraction of normal size,
                                         # skip rather than open a token position
    use_book_veto: bool = False          # scalps only by default
    book_veto_threshold: float = 0.35


@dataclass
class Position:
    symbol: str
    direction: str
    opened_ms: int
    entry: float
    stop: float
    initial_stop: float
    tp1: float
    tp2: float
    qty: float
    initial_qty: float
    risk_amount: float                   # currency at risk when opened
    r_per_unit: float                    # price distance of 1R
    conviction: float
    partial_done: bool = False
    realised_pnl: float = 0.0            # from the partial
    fees_paid: float = 0.0
    funding_paid: float = 0.0
    last_check_ms: int = 0
    note: str = ""


@dataclass
class ClosedTrade:
    symbol: str
    direction: str
    opened_ms: int
    closed_ms: int
    entry: float
    exit: float
    initial_stop: float
    qty: float
    gross_pnl: float
    fees: float
    funding: float
    net_pnl: float
    r_multiple: float
    outcome: str                         # tp2 | stop | breakeven | timeout | partial+stop
    conviction: float
    equity_after: float


def _max_addable_risk(existing: float, rho: float, budget: float) -> float:
    """Largest new position risk keeping combined cluster risk within budget.

    Solves  budget^2 = existing^2 + x^2 + 2*rho*existing*x  for x.
    """
    if existing <= 0:
        return budget
    disc = rho * rho * existing * existing - existing * existing + budget * budget
    if disc <= 0:
        return 0.0
    return max(0.0, -rho * existing + math.sqrt(disc))


class Challenge:
    """Runs inside the scan loop. Stateless between restarts except via Store."""

    def __init__(self, client: BinanceFutures, store, cfg: Optional[RiskConfig] = None,
                 name: str = "main", hyperliquid=None):
        self.cli = client
        self.store = store
        self.name = name
        self.cfg = cfg or RiskConfig()
        self.equity = self.cfg.starting_equity
        self.peak_equity = self.equity
        self.open: Dict[str, Position] = {}
        self.hl = hyperliquid
        self.symbols = SYMBOLS
        self._corr_cache: Dict[tuple, tuple] = {}
        self.blocked_until_ms = 0
        self._load()

    # ------------------------------------------------------------------ events

    def _emit(self, kind: str, symbol: str, title: str, body: str,
              payload: dict) -> None:
        """Record a notifiable event. Never let a notification failure affect
        the trade itself -- the position is the source of truth."""
        if self.store is None:
            return
        try:
            self.store.record_event(int(time.time() * 1000), kind, symbol,
                                    title, body, payload, self.name)
        except Exception as e:                            # noqa: BLE001
            log.warning("could not record event: %s", e)

    # ------------------------------------------------------------- persistence

    def _load(self) -> None:
        if self.store is None:
            return
        try:
            st = self.store.challenge_state(self.name)
            if st:
                self.equity = st.get("equity", self.equity)
                self.peak_equity = st.get("peak_equity", self.equity)
                self.blocked_until_ms = st.get("blocked_until_ms", 0)
            for p in self.store.challenge_open_positions(self.name):
                self.open[p["symbol"]] = Position(**p)
            if self.open:
                log.info("challenge resumed with %d open position(s), equity %.2f",
                         len(self.open), self.equity)
        except Exception as e:                            # noqa: BLE001
            log.warning("could not restore challenge state: %s", e)

    def _save(self) -> None:
        if self.store is None:
            return
        try:
            self.store.save_challenge_state(self.equity, self.peak_equity,
                                            self.blocked_until_ms, self.name)
            self.store.save_challenge_positions(
                [asdict(p) for p in self.open.values()], self.name)
        except Exception as e:                            # noqa: BLE001
            log.warning("could not save challenge state: %s", e)

    # ------------------------------------------------------------------ gates

    # -------------------------------------------------------- correlation

    def correlation(self, a: str, b: str) -> Optional[float]:
        """Return correlation between two symbols, cached for an hour.

        Measured rather than assumed. BTC/ETH correlation is usually high but
        genuinely breaks down sometimes -- and those are exactly the moments
        when holding both IS two separate bets, so hardcoding a number would
        block the trades most worth taking.
        """
        if a == b:
            return 1.0
        key = tuple(sorted((a, b)))
        now = time.time()
        hit = self._corr_cache.get(key)
        if hit and now - hit[0] < 3600:
            return hit[1]
        try:
            fa = self.cli.klines(a, "1h", self.cfg.correlation_lookback)
            fb = self.cli.klines(b, "1h", self.cfg.correlation_lookback)
            if not fa or not fb or len(fa) < 30 or len(fb) < 30:
                return None
            ca = pd.Series([float(x[4]) for x in fa],
                           index=[int(x[0]) for x in fa]).pct_change().dropna()
            cb = pd.Series([float(x[4]) for x in fb],
                           index=[int(x[0]) for x in fb]).pct_change().dropna()
            joined = pd.concat([ca, cb], axis=1, join="inner").dropna()
            if len(joined) < 30:
                return None
            corr = float(joined.iloc[:, 0].corr(joined.iloc[:, 1]))
            if not np.isfinite(corr):
                return None
            self._corr_cache[key] = (now, corr)
            return corr
        except Exception as e:                            # noqa: BLE001
            log.warning("[%s] correlation %s/%s failed: %s", self.name, a, b, e)
            return None

    def correlated_risk(self, symbol: str, direction: str
                        ) -> Tuple[float, float, List[str]]:
        """Live risk in same-direction correlated positions.

        Returns (combined_risk, effective_correlation, description). Combined
        risk uses the portfolio formula rather than a plain sum -- two $100
        positions at 0.9 correlation carry about $195 of joint risk, not $200,
        and summing correlation-weighted amounts linearly gets it wrong in the
        other direction.
        """
        risks: List[float] = []
        corrs: List[float] = []
        who: List[str] = []
        for sym, pos in self.open.items():
            if pos.direction != direction:
                continue                                   # opposite side hedges
            c = self.correlation(symbol, sym)
            if c is None or c < self.cfg.correlation_threshold:
                continue
            # remaining risk only -- a position past its partial with a
            # breakeven stop is no longer risking anything
            live = pos.qty * abs(pos.entry - pos.stop)
            if live <= 0:
                continue
            risks.append(live)
            corrs.append(c)
            who.append(f"{sym.replace('USDT', '')} (r={c:.2f})")

        if not risks:
            return 0.0, 0.0, []
        # combined risk of the existing cluster, pairwise-correlated
        var = sum(r * r for r in risks)
        for i in range(len(risks)):
            for j in range(i + 1, len(risks)):
                pair = self.correlation(
                    [k for k in self.open][i], [k for k in self.open][j]) or 1.0
                var += 2 * pair * risks[i] * risks[j]
        combined = math.sqrt(max(var, 0.0))
        # risk-weighted correlation of the cluster to the candidate symbol
        eff = sum(r * c for r, c in zip(risks, corrs)) / (sum(risks) or 1.0)
        return combined, eff, who


    def _today_stats(self) -> Dict[str, float]:
        if self.store is None:
            return {"trades": 0, "realised_r": 0.0}
        day_start = int(pd.Timestamp.utcnow().normalize().timestamp() * 1000)
        rows = self.store.challenge_trades_since(day_start, self.name)
        return {"trades": len(rows),
                "realised_r": float(sum(r.get("r_multiple", 0) or 0 for r in rows))}

    def can_open(self, symbol: str, now_ms: int) -> tuple[bool, str]:
        c = self.cfg
        if symbol not in self.symbols:
            return False, "not in the challenge universe"
        if symbol in self.open:
            return False, "already holding this symbol"
        if len(self.open) >= c.max_concurrent:
            return False, f"at max concurrent positions ({c.max_concurrent})"
        if now_ms < self.blocked_until_ms:
            mins = (self.blocked_until_ms - now_ms) / 60000
            return False, f"cooling off for another {mins:.0f} min after a loss"
        d = self._today_stats()
        if d["trades"] >= c.max_trades_per_day:
            return False, f"daily trade cap reached ({c.max_trades_per_day})"
        if d["realised_r"] <= -c.daily_loss_limit_r:
            return False, f"daily loss limit hit ({d['realised_r']:.2f}R)"
        if self.equity <= self.cfg.starting_equity * 0.5:
            return False, "equity halved -- the challenge is over, review before resuming"
        return True, "ok"

    # ------------------------------------------------------------------- open

    def maybe_open(self, candidate: dict, now_ms: int) -> Optional[Position]:
        sym = candidate["symbol"]
        allowed, why = self.can_open(sym, now_ms)
        if not allowed:
            return None
        if candidate.get("conviction", 0) < self.cfg.min_conviction:
            return None
        setup = candidate.get("setup") or {}
        entry_ref = setup.get("entry")
        stop = setup.get("stop")
        if not entry_ref or not stop or entry_ref <= 0:
            return None

        direction = candidate["direction"]
        long = direction == "LONG"
        # market fill: pay the spread and some slippage, in the wrong direction
        slip = self.cfg.slippage
        entry = entry_ref * (1 + slip) if long else entry_ref * (1 - slip)
        r_unit = abs(entry - stop)
        if r_unit <= 0:
            return None

        risk_amount = self.equity * self.cfg.risk_per_trade_pct / 100.0

        # Correlation cap. Without this, BTC long + ETH long at 1% each is not
        # 2% across two bets -- it is roughly 2% on one, and the daily loss
        # limit gets hit twice as fast as the rules imply.
        # Order book veto. Only ever stops a trade, never starts one -- see
        # hyperliquid.py for why resting depth is treated as weak evidence.
        if self.hl is not None and self.cfg.use_book_veto:
            try:
                b = self.hl.book(sym)
                if b is not None and b.vetoes(direction, self.cfg.book_veto_threshold):
                    log.info("[%s] skipping %s %s: book %.2f against it "
                             "($%.0fk bid vs $%.0fk ask)", self.name, sym, direction,
                             b.imbalance, b.bid_depth_usd / 1e3, b.ask_depth_usd / 1e3)
                    return None
            except Exception as e:                        # noqa: BLE001
                log.debug("[%s] book check failed, continuing: %s", self.name, e)

        corr_used, corr_rho, corr_with = self.correlated_risk(sym, direction)
        corr_note = ""
        if corr_used > 0:
            budget = self.equity * self.cfg.max_correlated_risk_pct / 100.0
            available = _max_addable_risk(corr_used, corr_rho, budget)
            if available <= self.cfg.min_viable_risk_frac * risk_amount:
                log.info("[%s] skipping %s: correlated cluster already carries "
                         "$%.2f of a $%.2f budget at r=%.2f (%s)",
                         self.name, sym, corr_used, budget, corr_rho,
                         ", ".join(corr_with))
                return None
            if available < risk_amount:
                corr_note = (f"size cut to fit the correlated-risk budget — "
                             f"already exposed via {', '.join(corr_with)}")
                risk_amount = available

        qty = risk_amount / r_unit
        notional = qty * entry
        max_notional = self.equity * self.cfg.max_leverage
        if notional > max_notional:                       # leverage cap binds first
            qty = max_notional / entry
            risk_amount = qty * r_unit
        if qty <= 0:
            return None

        tp1 = entry + self.cfg.tp1_r * r_unit if long else entry - self.cfg.tp1_r * r_unit
        tp2 = entry + self.cfg.tp2_r * r_unit if long else entry - self.cfg.tp2_r * r_unit
        fee = notional * self.cfg.taker_fee

        pos = Position(
            symbol=sym, direction=direction, opened_ms=now_ms, entry=entry,
            stop=stop, initial_stop=stop, tp1=tp1, tp2=tp2, qty=qty,
            initial_qty=qty, risk_amount=risk_amount, r_per_unit=r_unit,
            conviction=float(candidate.get("conviction", 0)),
            fees_paid=fee, last_check_ms=now_ms,
            note=(f"opened on conviction {candidate.get('conviction', 0):.2f}"
                  + (f" — {corr_note}" if corr_note else "")),
        )
        self.open[sym] = pos
        self._save()
        log.info("[%s] OPEN %s %s @ %.2f stop %.2f qty %.6f (risk %.2f)",
                 self.name, sym, direction, entry, stop, qty, risk_amount)
        self._emit("open", sym,
                   f"[{self.cfg.label}] {direction} {sym.replace('USDT', '')} opened",
                   f"Entry {entry:,.2f} · stop {stop:,.2f} ({100 * r_unit / entry:.2f}% away) "
                   f"· targets {tp1:,.2f} / {tp2:,.2f} · risking ${risk_amount:.2f} "
                   f"of ${self.equity:,.0f}"
                   + (f"\n{corr_note}" if corr_note else ""),
                   {"direction": direction, "entry": entry, "stop": stop,
                    "tp1": tp1, "tp2": tp2, "risk": round(risk_amount, 2),
                    "conviction": pos.conviction, "equity": round(self.equity, 2)})
        return pos

    # ------------------------------------------------------------------ manage

    def manage(self, now_ms: int) -> List[ClosedTrade]:
        """Walk 1m bars since the last check and apply exits in order."""
        closed: List[ClosedTrade] = []
        for sym in list(self.open):
            pos = self.open[sym]
            raw = self.cli.klines(sym, "1m", 500)
            if not raw:
                continue
            df = klines_to_df(raw)
            # Compare Timestamps directly -- int64 casts of a tz-aware index
            # are not stable across pandas versions.
            cutoff = pd.Timestamp(pos.last_check_ms, unit="ms", tz="UTC")
            df = df[df.index > cutoff]
            if df.empty:
                continue
            done = self._walk(pos, df, now_ms)
            pos.last_check_ms = int(df.index[-1].timestamp() * 1000)
            if done:
                closed.append(done)
                self.open.pop(sym, None)
        if closed:
            self._save()
        return closed

    def _walk(self, pos: Position, df: pd.DataFrame, now_ms: int) -> Optional[ClosedTrade]:
        long = pos.direction == "LONG"
        c = self.cfg
        for ts, bar in df.iterrows():
            hi, lo = float(bar["high"]), float(bar["low"])
            bar_ms = int(ts.timestamp() * 1000)

            hit_stop = lo <= pos.stop if long else hi >= pos.stop
            hit_tp1 = (hi >= pos.tp1 if long else lo <= pos.tp1) and not pos.partial_done
            hit_tp2 = hi >= pos.tp2 if long else lo <= pos.tp2

            # Pessimistic: a bar covering both is treated as the stop, because
            # without tick data the order is unknowable and the optimistic
            # reading is how paper accounts flatter themselves.
            if hit_stop:
                return self._close(pos, pos.stop, bar_ms,
                                   "breakeven" if pos.partial_done and
                                   abs(pos.stop - pos.entry) < 1e-9
                                   else ("partial+stop" if pos.partial_done else "stop"))
            if hit_tp1:
                qty_out = pos.qty * c.partial_fraction
                gross = ((pos.tp1 - pos.entry) if long else (pos.entry - pos.tp1)) * qty_out
                fee = qty_out * pos.tp1 * c.taker_fee
                pos.realised_pnl += gross - fee
                pos.fees_paid += fee
                pos.qty -= qty_out
                pos.partial_done = True
                if c.breakeven_after_tp1:
                    pos.stop = pos.entry
                log.info("challenge PARTIAL %s at 1R, stop to breakeven", pos.symbol)
                self._emit("partial", pos.symbol,
                           f"[{c.label}] {pos.symbol.replace('USDT', '')} "
                           f"hit {c.tp1_r}R",
                           f"Took {c.partial_fraction * 100:.0f}% off at {pos.tp1:,.2f} "
                           f"for +${gross - fee:,.2f}. Stop moved to breakeven — the "
                           f"rest is a free ride to {pos.tp2:,.2f}.",
                           {"tp1": pos.tp1, "realised": round(gross - fee, 2)})
                continue
            if hit_tp2:
                return self._close(pos, pos.tp2, bar_ms, "tp2")

            if bar_ms - pos.opened_ms > c.max_hold_hours * 3600_000:
                return self._close(pos, float(bar["close"]), bar_ms, "timeout")
        return None

    def _close(self, pos: Position, exit_px: float, ts_ms: int,
               outcome: str) -> ClosedTrade:
        long = pos.direction == "LONG"
        gross = ((exit_px - pos.entry) if long else (pos.entry - exit_px)) * pos.qty
        fee = pos.qty * exit_px * self.cfg.taker_fee
        funding = self._funding_cost(pos, ts_ms)
        net = pos.realised_pnl + gross - fee - funding
        total_fees = pos.fees_paid + fee
        r = net / pos.risk_amount if pos.risk_amount else 0.0

        self.equity += net
        self.peak_equity = max(self.peak_equity, self.equity)
        if net < 0:
            self.blocked_until_ms = ts_ms + int(
                self.cfg.cooldown_minutes_after_loss * 60000)

        t = ClosedTrade(
            symbol=pos.symbol, direction=pos.direction, opened_ms=pos.opened_ms,
            closed_ms=ts_ms, entry=pos.entry, exit=exit_px,
            initial_stop=pos.initial_stop, qty=pos.initial_qty,
            gross_pnl=round(gross + pos.realised_pnl, 2), fees=round(total_fees, 2),
            funding=round(funding, 2), net_pnl=round(net, 2),
            r_multiple=round(r, 3), outcome=outcome,
            conviction=pos.conviction, equity_after=round(self.equity, 2))
        if self.store is not None:
            try:
                self.store.record_challenge_trade(asdict(t), self.name)
            except Exception as e:                        # noqa: BLE001
                log.warning("could not record trade: %s", e)
        log.info("[%s] CLOSE %s %s @ %.2f -> %+.2f (%.2fR), equity %.2f",
                 self.name, pos.symbol, outcome, exit_px, net, r, self.equity)
        verdict = {"tp2": "target reached", "stop": "stopped out",
                   "breakeven": "closed at breakeven after the partial",
                   "partial+stop": "stopped out after taking half off",
                   "timeout": "closed on time limit"}.get(outcome, outcome)
        self._emit("close", pos.symbol,
                   f"[{self.cfg.label}] {pos.symbol.replace('USDT', '')} "
                   f"closed {net:+,.2f} ({r:+.2f}R)",
                   f"{verdict.capitalize()} at {exit_px:,.2f}. "
                   f"Costs {total_fees + funding:,.2f}. Equity now ${self.equity:,.2f}.",
                   {"outcome": outcome, "net": round(net, 2), "r": round(r, 3),
                    "equity": round(self.equity, 2), "exit": exit_px})
        return t

    def _funding_cost(self, pos: Position, ts_ms: int) -> float:
        """Funding actually paid over the hold. Longs pay positive funding."""
        try:
            hist = self.cli.funding_rate_history(pos.symbol, 20,
                                                 start_ms=pos.opened_ms, end_ms=ts_ms)
            if not hist:
                return 0.0
            total = sum(float(h["fundingRate"]) for h in hist)
            notional = pos.qty * pos.entry
            return total * notional * (1 if pos.direction == "LONG" else -1)
        except Exception:                                 # noqa: BLE001
            return 0.0

    # ------------------------------------------------------------------- tick

    def own_signals(self, btc_ref=None) -> List[dict]:
        """Score this challenge's own timeframe for its symbols.

        The swing challenge reuses the scanner's 15m candidates. The scalp one
        reads 5m instead -- otherwise the two would be the same strategy with
        different labels, which tests nothing.
        """
        from .features import (add_relative_strength, compute_features,
                               klines_to_df)
        from .score import build_setup, score_row, setup_dict

        bph = {"1m": 60, "3m": 20, "5m": 12, "15m": 4, "1h": 1}.get(
            self.cfg.timeframe, 12)
        out = []
        ref = btc_ref
        for sym in self.symbols:
            raw = self.cli.klines(sym, self.cfg.timeframe, 300)
            if not raw or len(raw) < 120:
                continue
            df = klines_to_df(raw).iloc[:-1]          # never the forming bar
            f = compute_features(df, bph)
            if ref is None:
                ref = f
            f = add_relative_strength(f, ref)
            r = f.iloc[-1]
            sc = score_row(r)
            if sc["direction"] == "FLAT" or sc["conviction"] < self.cfg.min_conviction:
                continue
            setup = build_setup(r, sc["direction"], self.cfg.atr_mult_stop)
            if setup is None:
                continue
            out.append({"symbol": sym, "price": float(r["close"]),
                        "direction": sc["direction"],
                        "conviction": sc["conviction"],
                        "setup": setup_dict(setup)})
        return out

    def on_cycle(self, scan_result: dict) -> Dict[str, Any]:
        now_ms = int(scan_result.get("generated_at") or time.time() * 1000)
        closed = self.manage(now_ms)
        opened = []

        if self.cfg.timeframe == "15m":
            cands = [c for c in scan_result.get("candidates", [])
                     if c["symbol"] in self.symbols]
        else:
            try:
                cands = self.own_signals()
            except Exception as e:                        # noqa: BLE001
                log.warning("[%s] signal generation failed: %s", self.name, e)
                cands = []

        for cand in cands:
            p = self.maybe_open(cand, now_ms)
            if p:
                opened.append(p)
        if closed or opened:
            self._save()
        return {"opened": [asdict(p) for p in opened],
                "closed": [asdict(t) for t in closed]}

    # ------------------------------------------------------------------ stats

    def snapshot(self, mark: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        trades = self.store.challenge_trades(name=self.name) if self.store else []
        cfg = self.cfg
        r = [t["r_multiple"] for t in trades]
        wins = [x for x in r if x > 0]
        losses = [x for x in r if x <= 0]
        gross_win = sum(wins)
        gross_loss = -sum(losses)

        eq_curve, eq = [], cfg.starting_equity
        for t in trades:
            eq = t["equity_after"]
            eq_curve.append({"ts": t["closed_ms"], "equity": eq})
        peak, max_dd = cfg.starting_equity, 0.0
        for p in eq_curve:
            peak = max(peak, p["equity"])
            max_dd = max(max_dd, (peak - p["equity"]) / peak * 100)

        unreal = 0.0
        open_rows = []
        for p in self.open.values():
            px = (mark or {}).get(p.symbol)
            u = None
            if px:
                long = p.direction == "LONG"
                u = ((px - p.entry) if long else (p.entry - px)) * p.qty + p.realised_pnl
                unreal += u
            open_rows.append(asdict(p) | {"mark": px, "unrealised_pnl":
                                          round(u, 2) if u is not None else None,
                                          "unrealised_r": round(u / p.risk_amount, 2)
                                          if u is not None and p.risk_amount else None})

        today = self._today_stats()
        allowed_btc = self.can_open("BTCUSDT", int(time.time() * 1000))
        clusters = []
        for d in ("LONG", "SHORT"):
            used, rho, who = self.correlated_risk(self.symbols[0], d)
            if used > 0:
                clusters.append({
                    "direction": d, "at_risk": round(used, 2),
                    "correlation": round(rho, 2),
                    "budget": round(self.equity * cfg.max_correlated_risk_pct / 100, 2),
                    "with": who})
        return {
            "config": asdict(cfg),
            "name": self.name,
            "label": cfg.label,
            "blurb": cfg.blurb,
            "timeframe": cfg.timeframe,
            "symbols": list(self.symbols),
            "equity": round(self.equity, 2),
            "starting_equity": cfg.starting_equity,
            "return_pct": round((self.equity / cfg.starting_equity - 1) * 100, 2),
            "unrealised_pnl": round(unreal, 2),
            "peak_equity": round(self.peak_equity, 2),
            "open_positions": open_rows,
            "trades_total": len(trades),
            "win_rate": round(len(wins) / len(r) * 100, 1) if r else None,
            "avg_r": round(float(np.mean(r)), 3) if r else None,
            "expectancy_r": round(float(np.mean(r)), 3) if r else None,
            "profit_factor": round(gross_win / gross_loss, 2) if gross_loss > 0 else None,
            "total_r": round(sum(r), 2) if r else 0.0,
            "max_drawdown_pct": round(max_dd, 2),
            "sharpe_per_trade": (round(float(np.mean(r) / np.std(r, ddof=1)), 2)
                                 if len(r) > 2 and np.std(r, ddof=1) > 0 else None),
            "best_r": round(max(r), 2) if r else None,
            "worst_r": round(min(r), 2) if r else None,
            "today": today,
            "gate": {"can_open": allowed_btc[0], "reason": allowed_btc[1]},
            "correlation": {
                "threshold": cfg.correlation_threshold,
                "max_cluster_risk_pct": cfg.max_correlated_risk_pct,
                "clusters": clusters,
                "pair": (round(self.correlation(*self.symbols[:2]), 2)
                         if len(self.symbols) > 1
                         and self.correlation(*self.symbols[:2]) is not None else None),
            },
            "equity_curve": eq_curve[-200:],
            "recent_trades": trades[-40:][::-1],
            "confidence_note": _confidence(len(r)),
        }


SWING = RiskConfig(
    label="Swing", timeframe="15m",
    risk_per_trade_pct=1.0, atr_mult_stop=1.5, tp1_r=1.0, tp2_r=2.5,
    max_trades_per_day=4, daily_loss_limit_r=2.0, max_hold_hours=24.0,
    min_conviction=0.25, cooldown_minutes_after_loss=60,
    blurb=("15-minute signals held up to a day. Wider stop, bigger target, "
           "fewer trades."))

# Scalps: more trades, each risking less, held for hours rather than a day.
# Halving the per-trade risk matters -- five trades a day at 1% is a 5% daily
# swing, which is how a bad session becomes an unrecoverable one.
SCALP = RiskConfig(
    label="Scalp", timeframe="5m",
    risk_per_trade_pct=0.5, atr_mult_stop=1.0, tp1_r=0.8, tp2_r=1.5,
    max_trades_per_day=5, daily_loss_limit_r=2.5, max_hold_hours=4.0,
    min_conviction=0.18, cooldown_minutes_after_loss=20,
    slippage=0.00025,          # crossing the spread more often costs more
    use_book_veto=True,        # 5m entries live or die on the book
    blurb=("5-minute signals held up to four hours. Tighter stop, smaller "
           "target, half the risk per trade because there are more of them."))


def _confidence(n: int) -> str:
    """How much the numbers above are actually worth."""
    if n == 0:
        return ("No closed trades yet. Every number here is a placeholder until "
                "the first one settles.")
    if n < 10:
        return (f"{n} trades. Far too few to mean anything — a run of three wins "
                f"is entirely normal in a strategy with no edge at all.")
    if n < 30:
        return (f"{n} trades. Still noise-dominated. Treat the direction of travel "
                f"as a hint, not evidence.")
    if n < 100:
        return (f"{n} trades. Beginning to be informative, though the confidence "
                f"interval on win rate is still roughly ±10 points.")
    return (f"{n} trades. Enough that the profit factor and expectancy carry real "
            f"information — though regimes change, so old trades describe an old market.")
