"""
The Challenge: forward paper-trading on live signals, BTCUSDT and ETHUSDT only.

Why this matters more than the backtester
-----------------------------------------
A backtest can be wrong in ways you cannot see. Lookahead creeps in through a
shifted window; survivorship creeps in through the symbol list; and every
parameter you tried and discarded quietly fits the model to the data. This
cannot happen here. The signal is recorded before the outcome exists, so the
result is the real thing rather than a reconstruction of it.

The cost is time. A backtest gives you 500 trades this afternoon; this gives
you maybe 20 in a month. Both are worth having, and they answer different
questions: the backtest asks "was there ever an edge", this asks "is there one
now, at the fills I would actually get".

Risk rules, and why each exists
-------------------------------
* **Fixed fractional risk.** Every trade risks the same % of *current* equity,
  so size shrinks after losses and grows after wins. This is the single most
  important rule here -- it makes ruin arithmetically very hard.
* **Stop first, size second.** The stop is set by structure and ATR. Position
  size is then derived from it. Never the other way round; sizing first and
  then placing a stop where it "feels right" is how accounts die.
* **Partial at 1R, stop to breakeven.** Half off at 1R, stop moves to entry.
  Converts a winner into a free option and is why the win rate here will read
  lower than the profit factor suggests.
* **Daily loss limit.** Trading stops for the day after -2R. Loss limits exist
  because the impulse to make it back is strongest exactly when judgement is
  worst.
* **One position per symbol, no adding.** No pyramiding, no averaging down.
  Averaging down turns a small planned loss into an unplanned large one.
* **Costs charged on everything.** Taker fees both sides, slippage, and funding
  actually paid while the position was open. Ignore these and a coin-flip
  strategy looks profitable.

Exits are evaluated against 1-minute klines, walked bar by bar, with the same
pessimistic same-bar rule the backtester uses: if a bar's range covers both the
stop and the target, it counts as the stop. Without tick data you cannot know
which came first, and assuming the good one is how paper trading flatters
itself.
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .client import BinanceFutures
from .features import klines_to_df

log = logging.getLogger("radar.challenge")

SYMBOLS = ("BTCUSDT", "ETHUSDT")


@dataclass
class RiskConfig:
    starting_equity: float = 10_000.0
    risk_per_trade_pct: float = 1.0      # % of current equity at risk to the stop
    max_leverage: float = 5.0            # cap on notional / equity
    atr_mult_stop: float = 1.5
    tp1_r: float = 1.0                   # take half here
    tp2_r: float = 2.5                   # rest here
    partial_fraction: float = 0.5
    breakeven_after_tp1: bool = True
    max_concurrent: int = 2              # one per symbol
    max_trades_per_day: int = 4
    daily_loss_limit_r: float = 2.0      # stop for the day at -2R realised
    max_hold_hours: float = 24.0
    min_conviction: float = 0.25
    cooldown_minutes_after_loss: float = 60.0
    taker_fee: float = 0.00045
    slippage: float = 0.00015            # BTC/ETH are deep; alts would be worse


@dataclass
class Position:
    symbol: str
    direction: str
    opened_ms: int
    entry: float
    stop: float
    initial_stop: float
    tp1: float
    tp2: float
    qty: float
    initial_qty: float
    risk_amount: float                   # currency at risk when opened
    r_per_unit: float                    # price distance of 1R
    conviction: float
    partial_done: bool = False
    realised_pnl: float = 0.0            # from the partial
    fees_paid: float = 0.0
    funding_paid: float = 0.0
    last_check_ms: int = 0
    note: str = ""


@dataclass
class ClosedTrade:
    symbol: str
    direction: str
    opened_ms: int
    closed_ms: int
    entry: float
    exit: float
    initial_stop: float
    qty: float
    gross_pnl: float
    fees: float
    funding: float
    net_pnl: float
    r_multiple: float
    outcome: str                         # tp2 | stop | breakeven | timeout | partial+stop
    conviction: float
    equity_after: float


class Challenge:
    """Runs inside the scan loop. Stateless between restarts except via Store."""

    def __init__(self, client: BinanceFutures, store, cfg: Optional[RiskConfig] = None):
        self.cli = client
        self.store = store
        self.cfg = cfg or RiskConfig()
        self.equity = self.cfg.starting_equity
        self.peak_equity = self.equity
        self.open: Dict[str, Position] = {}
        self.blocked_until_ms = 0
        self._load()

    # ------------------------------------------------------------------ events

    def _emit(self, kind: str, symbol: str, title: str, body: str,
              payload: dict) -> None:
        """Record a notifiable event. Never let a notification failure affect
        the trade itself -- the position is the source of truth."""
        if self.store is None:
            return
        try:
            self.store.record_event(int(time.time() * 1000), kind, symbol,
                                    title, body, payload)
        except Exception as e:                            # noqa: BLE001
            log.warning("could not record event: %s", e)

    # ------------------------------------------------------------- persistence

    def _load(self) -> None:
        if self.store is None:
            return
        try:
            st = self.store.challenge_state()
            if st:
                self.equity = st.get("equity", self.equity)
                self.peak_equity = st.get("peak_equity", self.equity)
                self.blocked_until_ms = st.get("blocked_until_ms", 0)
            for p in self.store.challenge_open_positions():
                self.open[p["symbol"]] = Position(**p)
            if self.open:
                log.info("challenge resumed with %d open position(s), equity %.2f",
                         len(self.open), self.equity)
        except Exception as e:                            # noqa: BLE001
            log.warning("could not restore challenge state: %s", e)

    def _save(self) -> None:
        if self.store is None:
            return
        try:
            self.store.save_challenge_state(self.equity, self.peak_equity,
                                            self.blocked_until_ms)
            self.store.save_challenge_positions([asdict(p) for p in self.open.values()])
        except Exception as e:                            # noqa: BLE001
            log.warning("could not save challenge state: %s", e)

    # ------------------------------------------------------------------ gates

    def _today_stats(self) -> Dict[str, float]:
        if self.store is None:
            return {"trades": 0, "realised_r": 0.0}
        day_start = int(pd.Timestamp.utcnow().normalize().timestamp() * 1000)
        rows = self.store.challenge_trades_since(day_start)
        return {"trades": len(rows),
                "realised_r": float(sum(r.get("r_multiple", 0) or 0 for r in rows))}

    def can_open(self, symbol: str, now_ms: int) -> tuple[bool, str]:
        c = self.cfg
        if symbol not in SYMBOLS:
            return False, "not in the challenge universe"
        if symbol in self.open:
            return False, "already holding this symbol"
        if len(self.open) >= c.max_concurrent:
            return False, f"at max concurrent positions ({c.max_concurrent})"
        if now_ms < self.blocked_until_ms:
            mins = (self.blocked_until_ms - now_ms) / 60000
            return False, f"cooling off for another {mins:.0f} min after a loss"
        d = self._today_stats()
        if d["trades"] >= c.max_trades_per_day:
            return False, f"daily trade cap reached ({c.max_trades_per_day})"
        if d["realised_r"] <= -c.daily_loss_limit_r:
            return False, f"daily loss limit hit ({d['realised_r']:.2f}R)"
        if self.equity <= self.cfg.starting_equity * 0.5:
            return False, "equity halved -- the challenge is over, review before resuming"
        return True, "ok"

    # ------------------------------------------------------------------- open

    def maybe_open(self, candidate: dict, now_ms: int) -> Optional[Position]:
        sym = candidate["symbol"]
        allowed, why = self.can_open(sym, now_ms)
        if not allowed:
            return None
        if candidate.get("conviction", 0) < self.cfg.min_conviction:
            return None
        setup = candidate.get("setup") or {}
        entry_ref = setup.get("entry")
        stop = setup.get("stop")
        if not entry_ref or not stop or entry_ref <= 0:
            return None

        direction = candidate["direction"]
        long = direction == "LONG"
        # market fill: pay the spread and some slippage, in the wrong direction
        slip = self.cfg.slippage
        entry = entry_ref * (1 + slip) if long else entry_ref * (1 - slip)
        r_unit = abs(entry - stop)
        if r_unit <= 0:
            return None

        risk_amount = self.equity * self.cfg.risk_per_trade_pct / 100.0
        qty = risk_amount / r_unit
        notional = qty * entry
        max_notional = self.equity * self.cfg.max_leverage
        if notional > max_notional:                       # leverage cap binds first
            qty = max_notional / entry
            risk_amount = qty * r_unit
        if qty <= 0:
            return None

        tp1 = entry + self.cfg.tp1_r * r_unit if long else entry - self.cfg.tp1_r * r_unit
        tp2 = entry + self.cfg.tp2_r * r_unit if long else entry - self.cfg.tp2_r * r_unit
        fee = notional * self.cfg.taker_fee

        pos = Position(
            symbol=sym, direction=direction, opened_ms=now_ms, entry=entry,
            stop=stop, initial_stop=stop, tp1=tp1, tp2=tp2, qty=qty,
            initial_qty=qty, risk_amount=risk_amount, r_per_unit=r_unit,
            conviction=float(candidate.get("conviction", 0)),
            fees_paid=fee, last_check_ms=now_ms,
            note=f"opened on conviction {candidate.get('conviction', 0):.2f}",
        )
        self.open[sym] = pos
        self._save()
        log.info("challenge OPEN %s %s @ %.2f stop %.2f qty %.6f (risk %.2f)",
                 sym, direction, entry, stop, qty, risk_amount)
        self._emit("open", sym,
                   f"{direction} {sym.replace('USDT', '')} opened",
                   f"Entry {entry:,.2f} · stop {stop:,.2f} ({100 * r_unit / entry:.2f}% away) "
                   f"· targets {tp1:,.2f} / {tp2:,.2f} · risking ${risk_amount:.2f} "
                   f"of ${self.equity:,.0f}",
                   {"direction": direction, "entry": entry, "stop": stop,
                    "tp1": tp1, "tp2": tp2, "risk": round(risk_amount, 2),
                    "conviction": pos.conviction, "equity": round(self.equity, 2)})
        return pos

    # ------------------------------------------------------------------ manage

    def manage(self, now_ms: int) -> List[ClosedTrade]:
        """Walk 1m bars since the last check and apply exits in order."""
        closed: List[ClosedTrade] = []
        for sym in list(self.open):
            pos = self.open[sym]
            raw = self.cli.klines(sym, "1m", 500)
            if not raw:
                continue
            df = klines_to_df(raw)
            # Compare Timestamps directly -- int64 casts of a tz-aware index
            # are not stable across pandas versions.
            cutoff = pd.Timestamp(pos.last_check_ms, unit="ms", tz="UTC")
            df = df[df.index > cutoff]
            if df.empty:
                continue
            done = self._walk(pos, df, now_ms)
            pos.last_check_ms = int(df.index[-1].timestamp() * 1000)
            if done:
                closed.append(done)
                self.open.pop(sym, None)
        if closed:
            self._save()
        return closed

    def _walk(self, pos: Position, df: pd.DataFrame, now_ms: int) -> Optional[ClosedTrade]:
        long = pos.direction == "LONG"
        c = self.cfg
        for ts, bar in df.iterrows():
            hi, lo = float(bar["high"]), float(bar["low"])
            bar_ms = int(ts.timestamp() * 1000)

            hit_stop = lo <= pos.stop if long else hi >= pos.stop
            hit_tp1 = (hi >= pos.tp1 if long else lo <= pos.tp1) and not pos.partial_done
            hit_tp2 = hi >= pos.tp2 if long else lo <= pos.tp2

            # Pessimistic: a bar covering both is treated as the stop, because
            # without tick data the order is unknowable and the optimistic
            # reading is how paper accounts flatter themselves.
            if hit_stop:
                return self._close(pos, pos.stop, bar_ms,
                                   "breakeven" if pos.partial_done and
                                   abs(pos.stop - pos.entry) < 1e-9
                                   else ("partial+stop" if pos.partial_done else "stop"))
            if hit_tp1:
                qty_out = pos.qty * c.partial_fraction
                gross = ((pos.tp1 - pos.entry) if long else (pos.entry - pos.tp1)) * qty_out
                fee = qty_out * pos.tp1 * c.taker_fee
                pos.realised_pnl += gross - fee
                pos.fees_paid += fee
                pos.qty -= qty_out
                pos.partial_done = True
                if c.breakeven_after_tp1:
                    pos.stop = pos.entry
                log.info("challenge PARTIAL %s at 1R, stop to breakeven", pos.symbol)
                self._emit("partial", pos.symbol,
                           f"{pos.symbol.replace('USDT', '')} hit 1R",
                           f"Took {c.partial_fraction * 100:.0f}% off at {pos.tp1:,.2f} "
                           f"for +${gross - fee:,.2f}. Stop moved to breakeven — the "
                           f"rest is a free ride to {pos.tp2:,.2f}.",
                           {"tp1": pos.tp1, "realised": round(gross - fee, 2)})
                continue
            if hit_tp2:
                return self._close(pos, pos.tp2, bar_ms, "tp2")

            if bar_ms - pos.opened_ms > c.max_hold_hours * 3600_000:
                return self._close(pos, float(bar["close"]), bar_ms, "timeout")
        return None

    def _close(self, pos: Position, exit_px: float, ts_ms: int,
               outcome: str) -> ClosedTrade:
        long = pos.direction == "LONG"
        gross = ((exit_px - pos.entry) if long else (pos.entry - exit_px)) * pos.qty
        fee = pos.qty * exit_px * self.cfg.taker_fee
        funding = self._funding_cost(pos, ts_ms)
        net = pos.realised_pnl + gross - fee - funding
        total_fees = pos.fees_paid + fee
        r = net / pos.risk_amount if pos.risk_amount else 0.0

        self.equity += net
        self.peak_equity = max(self.peak_equity, self.equity)
        if net < 0:
            self.blocked_until_ms = ts_ms + int(
                self.cfg.cooldown_minutes_after_loss * 60000)

        t = ClosedTrade(
            symbol=pos.symbol, direction=pos.direction, opened_ms=pos.opened_ms,
            closed_ms=ts_ms, entry=pos.entry, exit=exit_px,
            initial_stop=pos.initial_stop, qty=pos.initial_qty,
            gross_pnl=round(gross + pos.realised_pnl, 2), fees=round(total_fees, 2),
            funding=round(funding, 2), net_pnl=round(net, 2),
            r_multiple=round(r, 3), outcome=outcome,
            conviction=pos.conviction, equity_after=round(self.equity, 2))
        if self.store is not None:
            try:
                self.store.record_challenge_trade(asdict(t))
            except Exception as e:                        # noqa: BLE001
                log.warning("could not record trade: %s", e)
        log.info("challenge CLOSE %s %s @ %.2f -> %+.2f (%.2fR), equity %.2f",
                 pos.symbol, outcome, exit_px, net, r, self.equity)
        verdict = {"tp2": "target reached", "stop": "stopped out",
                   "breakeven": "closed at breakeven after the partial",
                   "partial+stop": "stopped out after taking half off",
                   "timeout": "closed on time limit"}.get(outcome, outcome)
        self._emit("close", pos.symbol,
                   f"{pos.symbol.replace('USDT', '')} closed {net:+,.2f} ({r:+.2f}R)",
                   f"{verdict.capitalize()} at {exit_px:,.2f}. "
                   f"Costs {total_fees + funding:,.2f}. Equity now ${self.equity:,.2f}.",
                   {"outcome": outcome, "net": round(net, 2), "r": round(r, 3),
                    "equity": round(self.equity, 2), "exit": exit_px})
        return t

    def _funding_cost(self, pos: Position, ts_ms: int) -> float:
        """Funding actually paid over the hold. Longs pay positive funding."""
        try:
            hist = self.cli.funding_rate_history(pos.symbol, 20,
                                                 start_ms=pos.opened_ms, end_ms=ts_ms)
            if not hist:
                return 0.0
            total = sum(float(h["fundingRate"]) for h in hist)
            notional = pos.qty * pos.entry
            return total * notional * (1 if pos.direction == "LONG" else -1)
        except Exception:                                 # noqa: BLE001
            return 0.0

    # ------------------------------------------------------------------- tick

    def on_cycle(self, scan_result: dict) -> Dict[str, Any]:
        now_ms = int(scan_result.get("generated_at") or time.time() * 1000)
        closed = self.manage(now_ms)
        opened = []
        for cand in scan_result.get("candidates", []):
            if cand["symbol"] in SYMBOLS:
                p = self.maybe_open(cand, now_ms)
                if p:
                    opened.append(p)
        if closed or opened:
            self._save()
        return {"opened": [asdict(p) for p in opened],
                "closed": [asdict(t) for t in closed]}

    # ------------------------------------------------------------------ stats

    def snapshot(self, mark: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        trades = self.store.challenge_trades() if self.store else []
        cfg = self.cfg
        r = [t["r_multiple"] for t in trades]
        wins = [x for x in r if x > 0]
        losses = [x for x in r if x <= 0]
        gross_win = sum(wins)
        gross_loss = -sum(losses)

        eq_curve, eq = [], cfg.starting_equity
        for t in trades:
            eq = t["equity_after"]
            eq_curve.append({"ts": t["closed_ms"], "equity": eq})
        peak, max_dd = cfg.starting_equity, 0.0
        for p in eq_curve:
            peak = max(peak, p["equity"])
            max_dd = max(max_dd, (peak - p["equity"]) / peak * 100)

        unreal = 0.0
        open_rows = []
        for p in self.open.values():
            px = (mark or {}).get(p.symbol)
            u = None
            if px:
                long = p.direction == "LONG"
                u = ((px - p.entry) if long else (p.entry - px)) * p.qty + p.realised_pnl
                unreal += u
            open_rows.append(asdict(p) | {"mark": px, "unrealised_pnl":
                                          round(u, 2) if u is not None else None,
                                          "unrealised_r": round(u / p.risk_amount, 2)
                                          if u is not None and p.risk_amount else None})

        today = self._today_stats()
        allowed_btc = self.can_open("BTCUSDT", int(time.time() * 1000))
        return {
            "config": asdict(cfg),
            "symbols": list(SYMBOLS),
            "equity": round(self.equity, 2),
            "starting_equity": cfg.starting_equity,
            "return_pct": round((self.equity / cfg.starting_equity - 1) * 100, 2),
            "unrealised_pnl": round(unreal, 2),
            "peak_equity": round(self.peak_equity, 2),
            "open_positions": open_rows,
            "trades_total": len(trades),
            "win_rate": round(len(wins) / len(r) * 100, 1) if r else None,
            "avg_r": round(float(np.mean(r)), 3) if r else None,
            "expectancy_r": round(float(np.mean(r)), 3) if r else None,
            "profit_factor": round(gross_win / gross_loss, 2) if gross_loss > 0 else None,
            "total_r": round(sum(r), 2) if r else 0.0,
            "max_drawdown_pct": round(max_dd, 2),
            "sharpe_per_trade": (round(float(np.mean(r) / np.std(r, ddof=1)), 2)
                                 if len(r) > 2 and np.std(r, ddof=1) > 0 else None),
            "best_r": round(max(r), 2) if r else None,
            "worst_r": round(min(r), 2) if r else None,
            "today": today,
            "gate": {"can_open": allowed_btc[0], "reason": allowed_btc[1]},
            "equity_curve": eq_curve[-200:],
            "recent_trades": trades[-40:][::-1],
            "confidence_note": _confidence(len(r)),
        }


def _confidence(n: int) -> str:
    """How much the numbers above are actually worth."""
    if n == 0:
        return ("No closed trades yet. Every number here is a placeholder until "
                "the first one settles.")
    if n < 10:
        return (f"{n} trades. Far too few to mean anything — a run of three wins "
                f"is entirely normal in a strategy with no edge at all.")
    if n < 30:
        return (f"{n} trades. Still noise-dominated. Treat the direction of travel "
                f"as a hint, not evidence.")
    if n < 100:
        return (f"{n} trades. Beginning to be informative, though the confidence "
                f"interval on win rate is still roughly ±10 points.")
    return (f"{n} trades. Enough that the profit factor and expectancy carry real "
            f"information — though regimes change, so old trades describe an old market.")
