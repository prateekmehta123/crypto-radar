"""
Backtesting.

Three things here that most crypto backtests get wrong, and which are the
whole reason the numbers this produces are worth anything:

1. **No lookahead.** A signal is computed from bars up to and including the
   close of bar t. Entry fills at the OPEN of bar t+1. Exits are checked
   against the high/low of subsequent bars only.

2. **Both barriers in one bar counts as a loss.** Without tick data you cannot
   know which was touched first. Assuming the win is how a 45% strategy
   backtests at 70%.

3. **Costs are charged.** Taker fees both sides, a slippage allowance, and
   funding actually paid over the holding period. On 1R stops with 15m bars,
   costs are frequently larger than the edge.

Scope note: OI-derived features are unavailable before the last 30 days
(Binance retention), so long backtests run kline + funding features only.
Point `--oi-db` at the scanner's SQLite file once you have accumulated
history to include them.
"""

from __future__ import annotations

import argparse
import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .client import BinanceFutures
from .features import (add_funding_series, add_relative_strength,
                       compute_features, klines_to_df)
from .score import (DEFAULT_WEIGHTS, aggregate, block_frame, build_setup,
                    score_row)

log = logging.getLogger("radar.backtest")

MS = {"1m": 60_000, "3m": 180_000, "5m": 300_000, "15m": 900_000,
      "30m": 1_800_000, "1h": 3_600_000, "4h": 14_400_000}
BARS_PER_HOUR = {"1m": 60, "3m": 20, "5m": 12, "15m": 4, "30m": 2, "1h": 1, "4h": 0.25}


# ------------------------------------------------------------- data loading

def download_klines(cli: BinanceFutures, symbol: str, interval: str,
                    start_ms: int, end_ms: int, cache_dir: str = "data") -> pd.DataFrame:
    Path(cache_dir).mkdir(parents=True, exist_ok=True)
    cache = Path(cache_dir) / f"{symbol}_{interval}_{start_ms}_{end_ms}.parquet"
    if cache.exists():
        return pd.read_parquet(cache)

    step = MS[interval] * 1000
    out: List[list] = []
    cur = start_ms
    while cur < end_ms:
        raw = cli.klines(symbol, interval, 1000, start_ms=cur, end_ms=end_ms)
        if not raw:
            break
        out.extend(raw)
        last = raw[-1][0]
        if last <= cur or len(raw) < 2:
            break
        cur = last + MS[interval]
        if len(raw) < 1000:
            break
    if not out:
        return pd.DataFrame()
    df = klines_to_df(out)
    df = df[~df.index.duplicated(keep="first")].sort_index()
    try:
        df.to_parquet(cache)
    except Exception:                                     # noqa: BLE001
        pass
    return df


def download_funding(cli: BinanceFutures, symbol: str,
                     start_ms: int, end_ms: int) -> pd.Series:
    out: List[dict] = []
    cur = start_ms
    while cur < end_ms:
        raw = cli.funding_rate_history(symbol, 1000, start_ms=cur, end_ms=end_ms)
        if not raw:
            break
        out.extend(raw)
        last = int(raw[-1]["fundingTime"])
        if last <= cur:
            break
        cur = last + 1
        if len(raw) < 1000:
            break
    if not out:
        return pd.Series(dtype=float)
    idx = pd.to_datetime([int(x["fundingTime"]) for x in out], unit="ms", utc=True)
    s = pd.Series([float(x["fundingRate"]) for x in out], index=idx)
    return s[~s.index.duplicated(keep="first")].sort_index()


# ------------------------------------------------------------------- costs

@dataclass
class Costs:
    taker_fee: float = 0.00045     # 0.045% per side, USDⓈ-M taker
    slippage: float = 0.00030      # per side; raise this for illiquid alts
    funding_applies: bool = True

    @property
    def round_trip(self) -> float:
        return 2 * (self.taker_fee + self.slippage)


# ------------------------------------------------------- triple-barrier sim

def simulate_trades(df: pd.DataFrame, feats: pd.DataFrame, signals: pd.DataFrame,
                    funding: Optional[pd.Series], costs: Costs,
                    max_bars: int, atr_mult: float,
                    cooldown_bars: int = 8) -> pd.DataFrame:
    """signals: DataFrame indexed like feats with columns direction, conviction."""
    idx = feats.index
    pos = {t: i for i, t in enumerate(idx)}
    o = df["open"].reindex(idx).values
    hi = df["high"].reindex(idx).values
    lo = df["low"].reindex(idx).values
    n = len(idx)

    trades = []
    last_exit_i = -10**9
    for t, sig in signals.iterrows():
        i = pos.get(t)
        if i is None or i + 1 >= n:
            continue
        if i <= last_exit_i + cooldown_bars:       # one position at a time
            continue

        row = feats.iloc[i]
        setup = build_setup(row, sig["direction"], atr_mult)
        if setup is None:
            continue

        entry = float(o[i + 1])                    # fill at next bar's open
        if not np.isfinite(entry) or entry <= 0:
            continue
        long = sig["direction"] == "LONG"
        # rescale stop/targets around the actual fill, preserving R distance
        risk = abs(setup.entry - setup.stop) / setup.entry * entry
        if risk <= 0:
            continue
        stop = entry - risk if long else entry + risk
        tp2 = entry + 2 * risk if long else entry - 2 * risk

        outcome, exit_px, exit_i = "timeout", None, min(i + max_bars, n - 1)
        for j in range(i + 1, min(i + 1 + max_bars, n)):
            h, l = hi[j], lo[j]
            hit_stop = (l <= stop) if long else (h >= stop)
            hit_tp = (h >= tp2) if long else (l <= tp2)
            if hit_stop and hit_tp:
                outcome, exit_px, exit_i = "stop", stop, j     # pessimistic
                break
            if hit_stop:
                outcome, exit_px, exit_i = "stop", stop, j
                break
            if hit_tp:
                outcome, exit_px, exit_i = "tp2", tp2, j
                break
        if exit_px is None:
            exit_px = float(df["close"].reindex(idx).values[exit_i])

        gross = (exit_px - entry) / entry if long else (entry - exit_px) / entry
        fund_cost = 0.0
        if costs.funding_applies and funding is not None and not funding.empty:
            window = funding.loc[(funding.index > idx[i]) & (funding.index <= idx[exit_i])]
            # longs pay positive funding, shorts receive it
            fund_cost = float(window.sum()) * (1 if long else -1)
        net = gross - costs.round_trip - fund_cost
        r_multiple = net / (risk / entry)

        trades.append({
            "entry_time": idx[i + 1], "exit_time": idx[exit_i],
            "direction": sig["direction"], "conviction": sig["conviction"],
            "entry": entry, "stop": stop, "tp2": tp2, "exit": exit_px,
            "outcome": outcome, "bars_held": exit_i - i,
            "gross_pct": gross * 100, "cost_pct": (costs.round_trip + fund_cost) * 100,
            "net_pct": net * 100, "r_multiple": r_multiple,
            "risk_pct": risk / entry * 100,
        })
        last_exit_i = exit_i

    return pd.DataFrame(trades)


# ----------------------------------------------------------------- metrics

def metrics(trades: pd.DataFrame) -> dict:
    if trades.empty:
        return {"trades": 0}
    r = trades["r_multiple"]
    wins, losses = r[r > 0], r[r <= 0]
    gross_win = wins.sum()
    gross_loss = -losses.sum()
    eq = r.cumsum()
    dd = (eq.cummax() - eq).max()
    return {
        "trades": int(len(r)),
        "win_rate": round(float((r > 0).mean()) * 100, 2),
        "avg_r": round(float(r.mean()), 3),
        "median_r": round(float(r.median()), 3),
        "expectancy_r": round(float(r.mean()), 3),
        "profit_factor": round(float(gross_win / gross_loss), 3) if gross_loss > 0 else None,
        "total_r": round(float(r.sum()), 2),
        "max_dd_r": round(float(dd), 2),
        "sharpe_per_trade": round(float(r.mean() / r.std(ddof=1)), 3) if r.std(ddof=1) > 0 else None,
        "avg_bars_held": round(float(trades["bars_held"].mean()), 1),
        "timeout_rate": round(float((trades["outcome"] == "timeout").mean()) * 100, 2),
        "avg_cost_pct": round(float(trades["cost_pct"].mean()), 4),
        "avg_gross_pct": round(float(trades["gross_pct"].mean()), 4),
    }


# ---------------------------------------------------- feature panel builder

def build_panel(cli: BinanceFutures, symbols: List[str], interval: str,
                start_ms: int, end_ms: int, cache_dir: str) -> Dict[str, dict]:
    bph = BARS_PER_HOUR[interval]
    btc_raw = download_klines(cli, "BTCUSDT", interval, start_ms, end_ms, cache_dir)
    if btc_raw.empty:
        raise RuntimeError("no BTC history")
    btc_f = compute_features(btc_raw, bph)

    panel = {}
    for sym in symbols:
        df = download_klines(cli, sym, interval, start_ms, end_ms, cache_dir)
        if df.empty or len(df) < 500:
            log.warning("skip %s (%d bars)", sym, len(df))
            continue
        f = compute_features(df, bph)
        f = add_relative_strength(f, btc_f)
        fr = download_funding(cli, sym, start_ms, end_ms)
        f = add_funding_series(f, fr)
        for col in ["oi", "oi_chg_5m", "oi_chg_15m", "oi_chg_1h", "oi_chg_4h",
                    "oi_z_24h", "taker_ls_ratio", "top_pos_ls_ratio"]:
            if col not in f:
                f[col] = np.nan
        panel[sym] = {"df": df, "feats": f.dropna(subset=["atr", "close"]), "funding": fr}
        log.info("panel %s: %d bars", sym, len(panel[sym]["feats"]))
    return panel


def signals_from_weights(feats: pd.DataFrame, weights: Dict[str, float],
                         min_conviction: float,
                         blocks: Optional[Tuple[pd.DataFrame, pd.DataFrame]] = None
                         ) -> pd.DataFrame:
    vals, avail = blocks if blocks is not None else block_frame(feats)
    agg = aggregate(vals, avail, weights)
    sel = agg[(agg["conviction"] >= min_conviction) & (agg["direction"] != "FLAT")]
    return sel[["direction", "conviction", "net"]]


def ensure_blocks(panel: Dict[str, dict]) -> None:
    """Cache per-symbol block values. They are weight-independent, so a weight
    search re-aggregates instead of recomputing -- ~100x faster."""
    for d in panel.values():
        if "blocks" not in d:
            d["blocks"] = block_frame(d["feats"])


def run(panel: Dict[str, dict], weights: Dict[str, float], min_conviction: float,
        costs: Costs, max_bars: int, atr_mult: float) -> pd.DataFrame:
    ensure_blocks(panel)
    all_trades = []
    for sym, d in panel.items():
        sig = signals_from_weights(d["feats"], weights, min_conviction, d["blocks"])
        if sig.empty:
            continue
        tr = simulate_trades(d["df"], d["feats"], sig, d["funding"], costs,
                             max_bars, atr_mult)
        if not tr.empty:
            tr["symbol"] = sym
            all_trades.append(tr)
    if not all_trades:
        return pd.DataFrame()
    return pd.concat(all_trades).sort_values("entry_time").reset_index(drop=True)


# ------------------------------------------------------------ walk-forward

def walk_forward(panel: Dict[str, dict], folds: int, n_random: int,
                 min_conviction: float, costs: Costs, max_bars: int,
                 atr_mult: float, seed: int = 7) -> Tuple[pd.DataFrame, list]:
    """Tune block weights in-sample per fold, evaluate strictly out-of-sample.

    Reporting only the tuned in-sample numbers is the classic way these tools
    end up looking profitable and trading badly. The OOS row is the one to read.
    """
    rng = np.random.default_rng(seed)
    ensure_blocks(panel)
    times = sorted({t for d in panel.values() for t in d["feats"].index})
    if len(times) < folds * 200:
        raise RuntimeError("not enough history for that many folds")
    edges = np.array_split(np.array(times), folds + 1)

    oos_trades, report = [], []
    for k in range(folds):
        train_end = edges[k][-1]
        test_start, test_end = edges[k + 1][0], edges[k + 1][-1]
        def _slice(d, lo, hi):
            f = d["feats"].loc[lo:hi]
            v, a = d["blocks"]
            return {"df": d["df"], "funding": d["funding"], "feats": f,
                    "blocks": (v.loc[lo:hi], a.loc[lo:hi])}
        train = {s: _slice(d, None, train_end) for s, d in panel.items()}
        test = {s: _slice(d, test_start, test_end) for s, d in panel.items()}

        best, best_score = dict(DEFAULT_WEIGHTS), -1e9
        candidates = [dict(DEFAULT_WEIGHTS)]
        keys = list(DEFAULT_WEIGHTS)
        for _ in range(n_random):
            w = rng.dirichlet(np.ones(len(keys)) * 2.5)
            candidates.append({k2: float(v) for k2, v in zip(keys, w)})
        for w in candidates:
            tr = run(train, w, min_conviction, costs, max_bars, atr_mult)
            m = metrics(tr)
            if m.get("trades", 0) < 40:
                continue
            # Objective: total R penalised by drawdown. Not raw win rate --
            # win rate is trivially gamed by widening stops.
            sc = m["total_r"] - 1.5 * m["max_dd_r"]
            if sc > best_score:
                best_score, best = sc, w

        tr_oos = run(test, best, min_conviction, costs, max_bars, atr_mult)
        m_is = metrics(run(train, best, min_conviction, costs, max_bars, atr_mult))
        m_oos = metrics(tr_oos)
        report.append({"fold": k + 1, "train_end": str(train_end),
                       "test_start": str(test_start), "test_end": str(test_end),
                       "weights": {k2: round(v, 3) for k2, v in best.items()},
                       "in_sample": m_is, "out_of_sample": m_oos})
        log.info("fold %d OOS: %s", k + 1, m_oos)
        if not tr_oos.empty:
            tr_oos["fold"] = k + 1
            oos_trades.append(tr_oos)

    oos = pd.concat(oos_trades).reset_index(drop=True) if oos_trades else pd.DataFrame()
    return oos, report


def main() -> None:
    p = argparse.ArgumentParser(description="Walk-forward backtest")
    p.add_argument("--symbols", default="BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,XRPUSDT,"
                                        "DOGEUSDT,AVAXUSDT,LINKUSDT,ADAUSDT,SUIUSDT")
    p.add_argument("--interval", default="15m", choices=list(MS))
    p.add_argument("--days", type=int, default=365)
    p.add_argument("--max-bars", type=int, default=48, help="max holding period in bars")
    p.add_argument("--atr-mult", type=float, default=1.5)
    p.add_argument("--min-conviction", type=float, default=0.15)
    p.add_argument("--folds", type=int, default=4)
    p.add_argument("--random-search", type=int, default=25)
    p.add_argument("--taker-fee", type=float, default=0.00045)
    p.add_argument("--slippage", type=float, default=0.00030)
    p.add_argument("--cache-dir", default="data")
    p.add_argument("--out", default="backtest_report.json")
    p.add_argument("-v", "--verbose", action="store_true")
    a = p.parse_args()

    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    end = int(time.time() * 1000)
    start = end - a.days * 86_400_000
    cli = BinanceFutures()
    syms = [s.strip().upper() for s in a.symbols.split(",") if s.strip()]

    panel = build_panel(cli, syms, a.interval, start, end, a.cache_dir)
    costs = Costs(a.taker_fee, a.slippage)
    oos, report = walk_forward(panel, a.folds, a.random_search, a.min_conviction,
                               costs, a.max_bars, a.atr_mult)

    summary = {"config": vars(a), "folds": report,
               "pooled_out_of_sample": metrics(oos)}
    print(json.dumps(summary["pooled_out_of_sample"], indent=2))
    with open(a.out, "w") as fh:
        json.dump(summary, fh, indent=2, default=str)
    if not oos.empty:
        oos.to_csv(a.out.replace(".json", "_trades.csv"), index=False)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
