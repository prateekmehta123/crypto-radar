"""AI Crypto Radar -- Binance USDⓈ-M perpetual futures scanner and backtester."""
__version__ = "1.0.0"
