"""
On-demand multi-timeframe analysis for a single symbol.

Different job from scan.py. The scanner sweeps ~50 symbols on one timeframe
looking for setups; this takes one symbol you name and reads it across every
timeframe, on request.

Rate-limit shape: one analysis is ~10 klines calls (about 30 weight) plus one
open-interest call. Cheap in isolation, expensive if a search box fires on
every keystroke -- hence the TTL cache here and debouncing in the UI. It shares
the same BinanceFutures client as the scanner, so its rate limiter covers both
and an analysis can never starve the scan loop.

On the narrative: the prose is generated from the computed numbers, not written
by a language model. That is a deliberate choice, not a shortcut -- see
narrate() for the reasoning. An LLM can optionally rephrase the finished fact
sheet if ANALYSIS_LLM is configured, but it is never given the chance to invent
a price level.
"""

from __future__ import annotations

import logging
import math
import threading
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .client import BinanceFutures
from .features import atr, compute_features, ema, klines_to_df, rsi

log = logging.getLogger("radar.analyze")

# What the user picks -> what Binance actually supports.
# Binance has no 7d interval; 1w is the same thing. No 2d or 5d either.
TIMEFRAMES: Dict[str, Dict[str, Any]] = {
    "1m":  {"binance": "1m",  "bars_per_hour": 60,      "label": "1 minute"},
    "3m":  {"binance": "3m",  "bars_per_hour": 20,      "label": "3 minutes"},
    "5m":  {"binance": "5m",  "bars_per_hour": 12,      "label": "5 minutes"},
    "15m": {"binance": "15m", "bars_per_hour": 4,       "label": "15 minutes"},
    "1h":  {"binance": "1h",  "bars_per_hour": 1,       "label": "1 hour"},
    "4h":  {"binance": "4h",  "bars_per_hour": 0.25,    "label": "4 hours"},
    "1d":  {"binance": "1d",  "bars_per_hour": 1 / 24,  "label": "1 day"},
    "3d":  {"binance": "3d",  "bars_per_hour": 1 / 72,  "label": "3 days"},
    "1w":  {"binance": "1w",  "bars_per_hour": 1 / 168, "label": "1 week"},
    "1M":  {"binance": "1M",  "bars_per_hour": 1 / 730, "label": "1 month"},
}
DEFAULT_TFS = list(TIMEFRAMES)
ALIASES = {"7d": "1w", "1w": "1w", "1D": "1d", "1mo": "1M", "1month": "1M"}


# ---------------------------------------------------------------- structure

@dataclass
class Level:
    price: float
    kind: str                 # "support" | "resistance"
    touches: int
    strength: float           # 0..1, blends touches, recency, volume
    last_touch_bars_ago: int
    flipped: bool             # previously the other kind -- usually stronger

    def distance_pct(self, px: float) -> float:
        return (self.price - px) / px * 100


def support_resistance(df: pd.DataFrame, atr_series: pd.Series,
                       left: int = 2, right: int = 2,
                       max_levels: int = 6) -> List[Level]:
    """Cluster confirmed swing points into levels and score them.

    A level matters in proportion to how many times price respected it, how
    recently, and how much volume traded there. A single touch is a line on a
    chart; four touches over three months is a level other people are watching.
    """
    if len(df) < 30:
        return []
    h, l, v, c = df["high"], df["low"], df["volume"], df["close"]
    n = len(df)
    win = left + right + 1

    is_hi = (h == h.rolling(win, center=True).max()) & h.notna()
    is_lo = (l == l.rolling(win, center=True).min()) & l.notna()
    # only confirmed swings -- the last `right` bars can still change
    pivots: List[Tuple[float, str, int, float]] = []
    for i in range(left, n - right):
        if is_hi.iloc[i]:
            pivots.append((float(h.iloc[i]), "resistance", i, float(v.iloc[i])))
        if is_lo.iloc[i]:
            pivots.append((float(l.iloc[i]), "support", i, float(v.iloc[i])))
    if not pivots:
        return []

    a = float(atr_series.iloc[-1]) if np.isfinite(atr_series.iloc[-1]) else float(c.iloc[-1]) * 0.01
    tol = max(a * 0.6, float(c.iloc[-1]) * 0.0015)

    pivots.sort(key=lambda p: p[0])
    clusters: List[List[Tuple[float, str, int, float]]] = [[pivots[0]]]
    for p in pivots[1:]:
        if abs(p[0] - clusters[-1][-1][0]) <= tol:
            clusters[-1].append(p)
        else:
            clusters.append([p])

    px = float(c.iloc[-1])
    out: List[Level] = []
    for cl in clusters:
        prices = [p[0] for p in cl]
        vols = [p[3] for p in cl]
        idxs = [p[2] for p in cl]
        kinds = {p[1] for p in cl}
        # volume-weighted centre: where trade actually happened, not the extreme
        wsum = sum(vols) or 1.0
        level_px = float(sum(p * w for p, w in zip(prices, vols)) / wsum)
        last_ago = n - 1 - max(idxs)
        touches = len(cl)

        recency = math.exp(-last_ago / max(n * 0.35, 1))         # 0..1
        vol_share = min(sum(vols) / (float(v.sum()) or 1.0) * 6, 1.0)
        strength = min(1.0, 0.45 * min(touches / 4, 1.0) + 0.35 * recency + 0.20 * vol_share)

        out.append(Level(
            price=level_px,
            kind="support" if level_px < px else "resistance",
            touches=touches,
            strength=round(strength, 3),
            last_touch_bars_ago=int(last_ago),
            flipped=len(kinds) > 1,
        ))

    below = sorted([x for x in out if x.price < px], key=lambda x: -x.price)
    above = sorted([x for x in out if x.price >= px], key=lambda x: x.price)
    keep = below[:max_levels // 2] + above[:max_levels // 2]
    return sorted(keep, key=lambda x: x.price)


@dataclass
class Zone:
    low: float
    high: float
    kind: str            # "entry" | "stop" | "target"
    rationale: str


def entry_zones(df: pd.DataFrame, feats: pd.Series, levels: List[Level],
                bias: str) -> List[Zone]:
    """Zones rather than single prices.

    A single entry number implies a precision that 15-minute bars do not have.
    A zone says where the idea is valid, which is what you actually trade.
    """
    px = float(feats["close"])
    a = float(feats.get("atr", np.nan))
    if not np.isfinite(a) or a <= 0:
        return []
    zones: List[Zone] = []
    poc = feats.get("poc", np.nan)
    vwap_ref = px / (1 + feats.get("vwap_dist", 0.0)) if np.isfinite(
        feats.get("vwap_dist", np.nan)) else np.nan

    if bias == "bullish":
        sup = [x for x in levels if x.price < px]
        anchor = max([x.price for x in sup], default=px - 1.5 * a)
        candidates = [anchor, poc if np.isfinite(poc) and poc < px else np.nan,
                      vwap_ref if np.isfinite(vwap_ref) and vwap_ref < px else np.nan]
        top = max([x for x in candidates if np.isfinite(x)], default=px - 1.2 * a)
        zones.append(Zone(round(top - 0.45 * a, 10), round(top + 0.25 * a, 10), "entry",
                          "pullback into the nearest support / value area"))
        stop_ref = min([x.price for x in sup], default=px - 2.5 * a)
        zones.append(Zone(round(min(stop_ref, top - 1.5 * a) - 0.2 * a, 10),
                          round(min(stop_ref, top - 1.5 * a), 10), "stop",
                          "below the support that defines the idea"))
        res = sorted([x.price for x in levels if x.price > px])
        for i, r in enumerate(res[:3]):
            zones.append(Zone(round(r - 0.3 * a, 10), round(r, 10), "target",
                              f"resistance {i + 1} above"))
    elif bias == "bearish":
        res = [x for x in levels if x.price > px]
        anchor = min([x.price for x in res], default=px + 1.5 * a)
        candidates = [anchor, poc if np.isfinite(poc) and poc > px else np.nan,
                      vwap_ref if np.isfinite(vwap_ref) and vwap_ref > px else np.nan]
        bot = min([x for x in candidates if np.isfinite(x)], default=px + 1.2 * a)
        zones.append(Zone(round(bot - 0.25 * a, 10), round(bot + 0.45 * a, 10), "entry",
                          "rally into the nearest resistance / value area"))
        stop_ref = max([x.price for x in res], default=px + 2.5 * a)
        zones.append(Zone(round(max(stop_ref, bot + 1.5 * a), 10),
                          round(max(stop_ref, bot + 1.5 * a) + 0.2 * a, 10), "stop",
                          "above the resistance that defines the idea"))
        sup = sorted([x.price for x in levels if x.price < px], reverse=True)
        for i, r in enumerate(sup[:3]):
            zones.append(Zone(round(r, 10), round(r + 0.3 * a, 10), "target",
                              f"support {i + 1} below"))
    return zones


# ------------------------------------------------------------------ per-TF

def analyse_timeframe(df: pd.DataFrame, tf: str, btc_df: Optional[pd.DataFrame],
                      funding: Optional[float],
                      oi: Optional[pd.Series]) -> Dict[str, Any]:
    meta = TIMEFRAMES[tf]
    bph = meta["bars_per_hour"]
    f = compute_features(df, bph)
    r = f.iloc[-1]
    px = float(r["close"])
    a_series = atr(df, 14)

    # --- EMA200 filter. Needs 200 closed bars; on 1M no perp has that history.
    e200 = ema(df["close"], 200)
    has_200 = bool(np.isfinite(e200.iloc[-1]))
    ema200_val = float(e200.iloc[-1]) if has_200 else None
    ema200_slope = None
    if has_200 and len(e200.dropna()) > 20:
        prev = float(e200.iloc[-20])
        ema200_slope = "rising" if ema200_val > prev else "falling" if ema200_val < prev else "flat"
    ema200 = {
        "available": has_200,
        "value": ema200_val,
        "price_above": (px > ema200_val) if has_200 else None,
        "distance_pct": round((px / ema200_val - 1) * 100, 2) if has_200 else None,
        "slope": ema200_slope,
        "bars_available": int(df["close"].notna().sum()),
        "note": None if has_200 else
                f"needs 200 closed bars, only {int(df['close'].notna().sum())} exist "
                f"on this timeframe",
    }

    # --- volume
    vol = df["volume"]
    avg20 = float(vol.tail(20).mean()) if len(vol) >= 20 else float(vol.mean())
    rel_vol = float(vol.iloc[-1] / avg20) if avg20 > 0 else None
    up = df["close"] > df["open"]
    up_vol = float(vol[up].tail(50).sum())
    dn_vol = float(vol[~up].tail(50).sum())
    taker_ratio = float(r.get("taker_buy_ratio", np.nan))
    volume = {
        "relative_to_20bar_avg": round(rel_vol, 2) if rel_vol else None,
        "trend": "expanding" if (rel_vol or 0) > 1.3 else
                 "contracting" if (rel_vol or 1) < 0.7 else "steady",
        "up_vs_down_50bar": round(up_vol / dn_vol, 2) if dn_vol > 0 else None,
        "taker_buy_share": round(taker_ratio, 3) if np.isfinite(taker_ratio) else None,
        "poc": float(r["poc"]) if np.isfinite(r.get("poc", np.nan)) else None,
        "value_area_high": float(r["vah"]) if np.isfinite(r.get("vah", np.nan)) else None,
        "value_area_low": float(r["val"]) if np.isfinite(r.get("val", np.nan)) else None,
        "in_value_area": bool(r.get("in_value_area", 0)) if np.isfinite(
            r.get("in_value_area", np.nan)) else None,
    }

    # --- bias, and what drove it
    votes: List[Tuple[str, int, str]] = []
    stack = float(r.get("ema_stack", 0) or 0)
    if np.isfinite(stack) and abs(stack) > 0.1:
        votes.append(("EMA alignment", 1 if stack > 0 else -1,
                      "20/50/200 stacked bullish" if stack > 0 else "20/50/200 stacked bearish"))
    if has_200:
        votes.append(("EMA200", 1 if px > ema200_val else -1,
                      f"price {'above' if px > ema200_val else 'below'} the 200 EMA"))
    rs = float(r.get("rsi14", np.nan))
    if np.isfinite(rs):
        if rs > 60:
            votes.append(("RSI", 1, f"RSI {rs:.0f}, momentum with buyers"))
        elif rs < 40:
            votes.append(("RSI", -1, f"RSI {rs:.0f}, momentum with sellers"))
    d = float(r.get("delta_norm", np.nan))
    if np.isfinite(d) and abs(d) > 0.03:
        votes.append(("order flow", 1 if d > 0 else -1,
                      f"{'buyers' if d > 0 else 'sellers'} lifting the last bar"))
    cvd = float(r.get("cvd_slope_4h", np.nan))
    if np.isfinite(cvd) and abs(cvd) > 0.02:
        votes.append(("cumulative delta", 1 if cvd > 0 else -1,
                      f"cumulative delta {'rising' if cvd > 0 else 'falling'}"))
    vw = float(r.get("vwap_dist", np.nan))
    if np.isfinite(vw) and abs(vw) > 0.002:
        votes.append(("VWAP", 1 if vw > 0 else -1,
                      f"trading {'above' if vw > 0 else 'below'} VWAP"))

    score = sum(v for _, v, _ in votes)
    total = len(votes) or 1
    bias = "bullish" if score >= 2 else "bearish" if score <= -2 else "neutral"
    conviction = round(abs(score) / total, 2)

    levels = support_resistance(df, a_series)
    zones = entry_zones(df, r, levels, bias)

    return {
        "timeframe": tf,
        "label": meta["label"],
        "bars": int(len(df)),
        "price": px,
        "atr": float(a_series.iloc[-1]) if np.isfinite(a_series.iloc[-1]) else None,
        "atr_pct": round(float(r.get("atr_pct", np.nan)) * 100, 3)
                   if np.isfinite(r.get("atr_pct", np.nan)) else None,
        "bias": bias,
        "conviction": conviction,
        "votes": [{"factor": k, "direction": v, "why": w} for k, v, w in votes],
        "rsi": round(rs, 1) if np.isfinite(rs) else None,
        "ema200": ema200,
        "volume": volume,
        "levels": [asdict(x) | {"distance_pct": round(x.distance_pct(px), 2)}
                   for x in levels],
        "zones": [asdict(z) for z in zones],
        "returns": {
            "1_bar_pct": round(float(df["close"].pct_change().iloc[-1]) * 100, 2),
            "10_bar_pct": round(float(df["close"].pct_change(10).iloc[-1]) * 100, 2)
                          if len(df) > 10 else None,
        },
    }


# ------------------------------------------------------------------ summary

def narrate(symbol: str, per_tf: Dict[str, dict], futures: dict) -> Dict[str, Any]:
    """Plain-English summary, composed from the computed numbers.

    Deliberately not written by a language model. Every number in this text is
    read directly out of the analysis above, so it cannot drift from what the
    charts actually say -- which is the one failure mode that matters when the
    output is a price you might act on. An LLM buys phrasing variety and risks
    inventing a level; that is a bad trade here.
    """
    tfs = [t for t in DEFAULT_TFS if t in per_tf]
    bulls = [t for t in tfs if per_tf[t]["bias"] == "bullish"]
    bears = [t for t in tfs if per_tf[t]["bias"] == "bearish"]
    neutral = [t for t in tfs if per_tf[t]["bias"] == "neutral"]

    higher = [t for t in ("4h", "1d", "3d", "1w", "1M") if t in per_tf]
    lower = [t for t in ("1m", "3m", "5m", "15m", "1h") if t in per_tf]
    hi_bull = sum(1 for t in higher if per_tf[t]["bias"] == "bullish")
    hi_bear = sum(1 for t in higher if per_tf[t]["bias"] == "bearish")
    lo_bull = sum(1 for t in lower if per_tf[t]["bias"] == "bullish")
    lo_bear = sum(1 for t in lower if per_tf[t]["bias"] == "bearish")

    if hi_bull > hi_bear and lo_bull >= lo_bear:
        verdict, headline = "aligned_bullish", "Higher and lower timeframes both lean up."
    elif hi_bear > hi_bull and lo_bear >= lo_bull:
        verdict, headline = "aligned_bearish", "Higher and lower timeframes both lean down."
    elif hi_bull > hi_bear and lo_bear > lo_bull:
        verdict, headline = "pullback_in_uptrend", \
            "Higher timeframes lean up while shorter ones are pulling back."
    elif hi_bear > hi_bull and lo_bull > lo_bear:
        verdict, headline = "bounce_in_downtrend", \
            "Higher timeframes lean down while shorter ones are bouncing."
    else:
        verdict, headline = "mixed", "No agreement across timeframes."

    paras: List[str] = []
    base = symbol.replace("USDT", "")
    ref = per_tf.get("1h") or per_tf.get("4h") or per_tf[tfs[0]]
    paras.append(
        f"{base} is trading at {ref['price']:,.6g}. {headline} "
        f"Of the {len(tfs)} timeframes checked, {len(bulls)} lean bullish, "
        f"{len(bears)} bearish and {len(neutral)} are undecided.")

    # structure, from the reference timeframe
    lv = ref.get("levels") or []
    sup = [x for x in lv if x["kind"] == "support"]
    res = [x for x in lv if x["kind"] == "resistance"]
    if sup or res:
        bits = []
        if res:
            n = min(res, key=lambda x: x["distance_pct"])
            bits.append(f"the nearest resistance is {n['price']:,.6g} "
                        f"({n['distance_pct']:+.1f}%, touched {n['touches']}x"
                        f"{', previously support' if n['flipped'] else ''})")
        if sup:
            n = max(sup, key=lambda x: x["distance_pct"])
            bits.append(f"support sits at {n['price']:,.6g} "
                        f"({n['distance_pct']:+.1f}%, touched {n['touches']}x)")
        paras.append(f"On the {ref['label']} chart, " + " and ".join(bits) + ".")

    # EMA200 across timeframes
    have = [t for t in tfs if per_tf[t]["ema200"]["available"]]
    above = [t for t in have if per_tf[t]["ema200"]["price_above"]]
    missing = [t for t in tfs if not per_tf[t]["ema200"]["available"]]
    if have:
        s = (f"Price is above the 200 EMA on {len(above)} of {len(have)} timeframes"
             f" ({', '.join(above) if above else 'none'}).")
        if missing:
            s += (f" It can't be calculated on {', '.join(missing)} — that needs 200 closed"
                  f" bars and this contract hasn't existed that long.")
        paras.append(s)

    # volume
    v = ref["volume"]
    if v.get("relative_to_20bar_avg"):
        rv = v["relative_to_20bar_avg"]
        desc = ("well above average" if rv > 1.5 else "above average" if rv > 1.15
                else "below average" if rv < 0.85 else "about average")
        s = f"Volume on the {ref['label']} chart is {desc} ({rv:.1f}x the 20-bar mean)"
        if v.get("taker_buy_share") is not None:
            share = v["taker_buy_share"]
            s += (f", and {share * 100:.0f}% of it is hitting the offer, so "
                  f"{'buyers' if share > 0.5 else 'sellers'} are the aggressive side")
        paras.append(s + ".")

    # futures
    fnd = futures.get("funding_rate")
    if fnd is not None:
        annual = fnd * 3 * 365 * 100
        who = "longs are paying shorts" if fnd > 0 else "shorts are paying longs"
        crowd = ("unusually crowded" if abs(annual) > 50 else
                 "somewhat one-sided" if abs(annual) > 20 else "close to neutral")
        s = (f"Funding is {fnd * 100:+.4f}% per 8 hours ({annual:+.0f}% annualised), "
             f"so {who} — positioning looks {crowd}.")
        oi_chg = futures.get("oi_change_24h_pct")
        if oi_chg is not None:
            direction = ref["returns"].get("10_bar_pct") or 0
            if oi_chg > 1 and direction > 0:
                s += (" Open interest is rising alongside price, which means new longs "
                      "rather than shorts covering.")
            elif oi_chg > 1 and direction < 0:
                s += (" Open interest is rising while price falls, which means new shorts "
                      "are being opened.")
            elif oi_chg < -1 and direction > 0:
                s += (" Open interest is falling as price rises, which looks more like "
                      "short covering than fresh buying — those moves tend to fade.")
            elif oi_chg < -1:
                s += " Open interest is falling with price, which is positions being closed."
        paras.append(s)

    # the honest closer
    if verdict == "mixed":
        paras.append("With timeframes disagreeing, there is no clean read here. "
                     "Waiting is a position.")
    elif verdict in ("pullback_in_uptrend", "bounce_in_downtrend"):
        paras.append("This is the configuration that produces both the best entries and "
                     "the worst ones: a pullback and a reversal look identical until "
                     "after the fact. The levels above are where the difference shows up.")

    return {
        "verdict": verdict,
        "headline": headline,
        "bullish_timeframes": bulls,
        "bearish_timeframes": bears,
        "neutral_timeframes": neutral,
        "text": "\n\n".join(paras),
    }


# -------------------------------------------------------------- the analyser

class Analyzer:
    def __init__(self, client: BinanceFutures, ttl_s: float = 60.0):
        self.cli = client
        self.ttl = ttl_s
        self._cache: Dict[str, Tuple[float, dict]] = {}
        self._lock = threading.Lock()
        self._symbols: Optional[set] = None
        self._symbols_at = 0.0

    def valid_symbols(self) -> set:
        if self._symbols and time.time() - self._symbols_at < 3600:
            return self._symbols
        info = self.cli.exchange_info()
        if not info:
            return self._symbols or set()
        self._symbols = {s["symbol"] for s in info["symbols"]
                         if s.get("contractType") == "PERPETUAL"
                         and s.get("status") == "TRADING"}
        self._symbols_at = time.time()
        return self._symbols

    def suggest(self, query: str, limit: int = 12) -> List[str]:
        q = query.strip().upper()
        syms = self.valid_symbols()
        if not q:
            return []
        starts = sorted(s for s in syms if s.startswith(q))
        contains = sorted(s for s in syms if q in s and not s.startswith(q))
        return (starts + contains)[:limit]

    def analyse(self, symbol: str, tfs: Optional[List[str]] = None) -> dict:
        symbol = symbol.strip().upper()
        if not symbol.endswith("USDT") and not symbol.endswith("USDC"):
            symbol += "USDT"
        tfs = [ALIASES.get(t, t) for t in (tfs or DEFAULT_TFS)]
        tfs = [t for t in tfs if t in TIMEFRAMES] or DEFAULT_TFS

        key = f"{symbol}|{','.join(tfs)}"
        with self._lock:
            hit = self._cache.get(key)
            if hit and time.time() - hit[0] < self.ttl:
                return hit[1] | {"cached": True,
                                 "age_s": round(time.time() - hit[0], 1)}

        valid = self.valid_symbols()
        if valid and symbol not in valid:
            near = self.suggest(symbol.replace("USDT", ""), 6)
            raise KeyError(f"{symbol} is not a Binance USDⓈ-M perpetual." +
                           (f" Did you mean: {', '.join(near)}?" if near else ""))

        t0 = time.time()
        per_tf: Dict[str, dict] = {}
        errors: Dict[str, str] = {}
        for tf in tfs:
            b = TIMEFRAMES[tf]["binance"]
            raw = self.cli.klines(symbol, b, 500)
            if not raw or len(raw) < 20:
                errors[tf] = "not enough history on this timeframe"
                continue
            df = klines_to_df(raw).iloc[:-1]        # drop the forming bar
            if len(df) < 20:
                errors[tf] = "not enough closed bars"
                continue
            try:
                per_tf[tf] = analyse_timeframe(df, tf, None, None, None)
            except Exception as e:                        # noqa: BLE001
                log.warning("analysis failed for %s %s: %s", symbol, tf, e)
                errors[tf] = str(e)

        if not per_tf:
            raise RuntimeError(f"no usable data for {symbol}")

        futures = self._futures_metrics(symbol)
        summary = narrate(symbol, per_tf, futures)

        out = {
            "symbol": symbol,
            "generated_at": int(time.time() * 1000),
            "elapsed_s": round(time.time() - t0, 2),
            "timeframes": per_tf,
            "timeframe_order": [t for t in DEFAULT_TFS if t in per_tf],
            "errors": errors,
            "futures": futures,
            "summary": summary,
            "cached": False,
        }
        with self._lock:
            self._cache[key] = (time.time(), out)
            if len(self._cache) > 200:                   # bounded, cheap
                oldest = sorted(self._cache.items(), key=lambda kv: kv[1][0])[:50]
                for k, _ in oldest:
                    self._cache.pop(k, None)
        return out

    def _futures_metrics(self, symbol: str) -> dict:
        out: Dict[str, Any] = {"funding_rate": None, "next_funding_time": None,
                               "mark_price": None, "open_interest": None,
                               "oi_change_24h_pct": None, "oi_note": None}
        pi = self.cli._get("/fapi/v1/premiumIndex", {"symbol": symbol}, weight=1)
        if isinstance(pi, dict):
            try:
                out["funding_rate"] = float(pi.get("lastFundingRate"))
                out["mark_price"] = float(pi.get("markPrice"))
                out["next_funding_time"] = int(pi.get("nextFundingTime", 0))
            except (TypeError, ValueError):
                pass
        hist = self.cli.open_interest_hist(symbol, "1h", 25)
        if hist and len(hist) >= 2:
            try:
                vals = [float(x["sumOpenInterest"]) for x in hist]
                out["open_interest"] = vals[-1]
                if vals[0] > 0:
                    out["oi_change_24h_pct"] = round((vals[-1] / vals[0] - 1) * 100, 2)
            except (KeyError, TypeError, ValueError):
                pass
        else:
            out["oi_note"] = ("open interest history unavailable — Binance only "
                              "retains 30 days")
        return out
