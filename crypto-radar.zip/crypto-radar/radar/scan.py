"""
The scanner.

Request budget is the design constraint, not compute. Per cycle:

  exchangeInfo            1 req    weight 1
  ticker/24hr (all)       1 req    weight 40
  premiumIndex (all)      1 req    weight 10
  klines x N symbols      N reqs   weight 2 each   (N=150 -> 300)
  BTC klines              1 req
  /futures/data x 3 x K   3K reqs  (K = deriv_top, separate 1000/5min bucket)

With N=150 and K=60 that is ~350 weight/min on the fapi bucket and 180 reqs
per cycle on the futures/data bucket. At a 5-minute cycle both sit at roughly
a third of the limit, leaving room for retries. Pushing to a 2-minute cycle
over 400 symbols is what gets you IP-banned; the defaults here are chosen to
avoid that, and every one of them is a flag.
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .client import BinanceFutures
from .features import (add_derivatives, add_funding_series, add_relative_strength,
                       compute_features, klines_to_df)
from .score import build_setup, score_row, setup_dict
from .onchain import WhaleTracker
from .store import Store

log = logging.getLogger("radar.scan")

BARS_PER_HOUR = {"1m": 60, "3m": 20, "5m": 12, "15m": 4, "30m": 2, "1h": 1, "4h": 0.25}

# Symbols that are index/leveraged/oddities rather than normal perps.
EXCLUDE_SUFFIX = ("UPUSDT", "DOWNUSDT", "BULLUSDT", "BEARUSDT")


def build_universe(cli: BinanceFutures, top_n: int, min_quote_vol: float) -> pd.DataFrame:
    info = cli.exchange_info()
    if not info:
        raise RuntimeError("exchangeInfo failed -- check connectivity / geo access")
    perps = {
        s["symbol"] for s in info["symbols"]
        if s.get("contractType") == "PERPETUAL"
        and s.get("quoteAsset") == "USDT"
        and s.get("status") == "TRADING"
        and not s["symbol"].endswith(EXCLUDE_SUFFIX)
    }
    tick = cli.ticker_24hr_all() or []
    rows = [
        {"symbol": t["symbol"],
         "quote_volume": float(t["quoteVolume"]),
         "price": float(t["lastPrice"]),
         "pct_24h": float(t["priceChangePercent"])}
        for t in tick if t["symbol"] in perps
    ]
    df = pd.DataFrame(rows)
    df = df[df["quote_volume"] >= min_quote_vol]
    df = df.sort_values("quote_volume", ascending=False).head(top_n).reset_index(drop=True)
    log.info("universe: %d symbols (min 24h quote vol %.0f)", len(df), min_quote_vol)
    return df


def funding_map(cli: BinanceFutures) -> Dict[str, dict]:
    pi = cli.premium_index_all() or []
    return {p["symbol"]: {"funding": float(p.get("lastFundingRate", "nan")),
                          "mark": float(p.get("markPrice", "nan")),
                          "next_funding_ts": int(p.get("nextFundingTime", 0))}
            for p in pi}


def fetch_klines(cli: BinanceFutures, symbol: str, interval: str,
                 limit: int) -> Optional[pd.DataFrame]:
    raw = cli.klines(symbol, interval, limit)
    if not raw or len(raw) < 60:
        return None
    df = klines_to_df(raw)
    # Drop the still-forming final bar: using it is the most common source of
    # backtest-vs-live divergence.
    return df.iloc[:-1]


def fetch_derivatives(cli: BinanceFutures, symbol: str, period: str,
                      limit: int) -> dict:
    out: dict = {"oi": None, "taker_ls": None, "top_pos_ls": None}
    oi = cli.open_interest_hist(symbol, period, limit)
    if oi:
        idx = pd.to_datetime([int(x["timestamp"]) for x in oi], unit="ms", utc=True)
        out["oi"] = pd.Series([float(x["sumOpenInterest"]) for x in oi], index=idx)
    tls = cli.taker_long_short_ratio(symbol, period, 6)
    if tls:
        out["taker_ls"] = float(tls[-1]["buySellRatio"])
    tps = cli.top_trader_position_ratio(symbol, period, 6)
    if tps:
        out["top_pos_ls"] = float(tps[-1]["longShortRatio"])
    return out


def scan_once(cli: BinanceFutures, store: Optional[Store], *,
              interval: str = "15m", klines_limit: int = 500,
              top_n: int = 150, deriv_top: int = 60,
              min_quote_vol: float = 30_000_000, workers: int = 8,
              min_conviction: float = 0.15, atr_mult: float = 1.5,
              account_risk_pct: float = 0.5,
              whales: Optional[WhaleTracker] = None) -> dict:
    t0 = time.time()
    bph = BARS_PER_HOUR[interval]
    uni = build_universe(cli, top_n, min_quote_vol)
    fmap = funding_map(cli)

    btc_df = fetch_klines(cli, "BTCUSDT", interval, klines_limit)
    if btc_df is None:
        raise RuntimeError("BTC klines failed")
    btc_f = compute_features(btc_df, bph)

    # -------------------------------------------------- pass 1: klines only
    feats: Dict[str, pd.DataFrame] = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(fetch_klines, cli, s, interval, klines_limit): s
                for s in uni["symbol"]}
        for fut in as_completed(futs):
            sym = futs[fut]
            try:
                df = fut.result()
            except Exception as e:                       # noqa: BLE001
                log.warning("klines %s failed: %s", sym, e)
                continue
            if df is None:
                continue
            f = compute_features(df, bph)
            f = add_relative_strength(f, btc_f)
            fnd = fmap.get(sym, {}).get("funding")
            f["funding"] = fnd if fnd is not None and np.isfinite(fnd) else np.nan
            f["funding_z_7d"] = np.nan
            feats[sym] = f
    log.info("pass 1: features for %d symbols in %.1fs", len(feats), time.time() - t0)

    # ------------- pass 2: derivatives only for the most interesting symbols
    prelim = []
    for sym, f in feats.items():
        r = f.iloc[-1]
        s = score_row(r)
        prelim.append((sym, abs(s["net"]), s))
    prelim.sort(key=lambda x: -x[1])
    deriv_syms = [p[0] for p in prelim[:deriv_top]]

    deriv: Dict[str, dict] = {}
    with ThreadPoolExecutor(max_workers=min(workers, 5)) as ex:
        futs = {ex.submit(fetch_derivatives, cli, s, "5m", int(8 * bph) + 4): s
                for s in deriv_syms}
        for fut in as_completed(futs):
            sym = futs[fut]
            try:
                deriv[sym] = fut.result()
            except Exception as e:                       # noqa: BLE001
                log.warning("derivatives %s failed: %s", sym, e)

    # ------------------------------------------------------- final scoring
    now_ms = int(time.time() * 1000)
    results, snaps, sigrows = [], [], []
    for sym, f in feats.items():
        d = deriv.get(sym, {})
        oi = d.get("oi")
        # Blend in locally recorded OI history if we have more than the API gives
        if store is not None:
            local = store.oi_series(sym, since_ms=now_ms - 14 * 86400_000)
            if not local.empty and (oi is None or len(local) > len(oi)):
                oi = local if oi is None else pd.concat([local, oi]).sort_index()
                oi = oi[~oi.index.duplicated(keep="last")]

        ff = add_derivatives(f, oi, fmap.get(sym, {}).get("funding"),
                             d.get("taker_ls"), d.get("top_pos_ls"), bph)
        r = ff.iloc[-1]
        s = score_row(r)

        snaps.append({
            "ts": now_ms, "symbol": sym, "close": float(r["close"]),
            "quote_volume": float(r.get("quote_volume", np.nan)),
            "open_interest": float(oi.iloc[-1]) if oi is not None and len(oi) else None,
            "funding": fmap.get(sym, {}).get("funding"),
            "next_funding_ts": fmap.get(sym, {}).get("next_funding_ts"),
            "taker_ls": d.get("taker_ls"), "top_pos_ls": d.get("top_pos_ls"),
            "long_score": s["long_score"], "net": s["net"],
            "conviction": s["conviction"],
        })

        if s["conviction"] < min_conviction or s["direction"] == "FLAT":
            continue
        setup = build_setup(r, s["direction"], atr_mult, account_risk_pct)
        if setup is None:
            continue
        row = {
            "symbol": sym, "price": float(r["close"]),
            **{k: s[k] for k in ("direction", "long_score", "short_score",
                                 "conviction", "agreement", "coverage", "net")},
            **s["squeeze"],
            "regime": s["blocks"]["open_interest"].get("regime", "unknown"),
            "funding": fmap.get(sym, {}).get("funding"),
            "atr_pct": float(r.get("atr_pct", np.nan)),
            "setup": setup_dict(setup),
            "blocks": s["blocks"],
        }
        results.append(row)
        sigrows.append({
            "ts": now_ms, "symbol": sym, "direction": setup.direction,
            "long_score": s["long_score"], "conviction": s["conviction"],
            "entry": setup.entry, "stop": setup.stop, "tp1": setup.tp1,
            "tp2": setup.tp2, "tp3": setup.tp3, "risk_pct": setup.risk_pct,
            "risk_rating": setup.risk_rating,
            "blocks_json": json.dumps(s["blocks"], default=float),
        })

    if store is not None:
        store.write_snapshots(snaps)
        store.write_signals(sigrows)

    # ---- on-chain annotation (NEVER feeds back into the score, by design)
    whale_ctx: Dict[str, Any] = {}
    if whales is not None and whales.enabled:
        try:
            whale_ctx = whales.sweep(list(feats.keys()), time_last="1h")
            for row in results:
                c = whale_ctx.get(row["symbol"])
                if c is None:
                    continue
                row["whale"] = {
                    "flag": c.flag(),
                    "caution": c.caution_for(row["direction"]),
                    "net_to_exchange_usd": round(c.net_to_exchange, 0),
                    "inflow_usd": round(c.inflow_usd, 0),
                    "outflow_usd": round(c.outflow_usd, 0),
                    "n_transfers": c.n_transfers,
                    "largest": c.largest_desc,
                    "dormant_wakes": c.dormant_wakes,
                }
        except Exception as e:                            # noqa: BLE001
            log.warning("arkham sweep failed (continuing without it): %s", e)

    results.sort(key=lambda r: -r["conviction"])
    return {
        "whale_events": [
            {"symbol": sym, "flag": c.flag(), "notable": c.notable,
             "dormant_wakes": c.dormant_wakes,
             "net_to_exchange_usd": round(c.net_to_exchange, 0),
             "largest": c.largest_desc}
            for sym, c in whale_ctx.items()
            if c.dormant_wakes or c.notable
        ],
        "generated_at": now_ms,
        "interval": interval,
        "universe_size": len(feats),
        "derivatives_covered": len(deriv),
        "elapsed_s": round(time.time() - t0, 1),
        "used_weight_1m": cli.last_used_weight,
        "candidates": results,
    }


def print_table(res: dict, n: int = 20) -> None:
    print(f"\n=== AI Crypto Radar | {pd.to_datetime(res['generated_at'], unit='ms', utc=True)} "
          f"| {res['universe_size']} symbols | {res['elapsed_s']}s "
          f"| weight {res['used_weight_1m']}/min ===")
    hdr = (f"{'SYMBOL':<14}{'DIR':<6}{'SCORE':>6}{'CONV':>6}{'REGIME':<17}"
           f"{'FUND%':>8}{'SQZ':>6}{'ENTRY':>13}{'STOP':>13}{'TP2':>13}{'RISK%':>7}  RATING")
    print(hdr)
    print("-" * len(hdr))
    for r in res["candidates"][:n]:
        s = r["setup"]
        sq = max(r["short_squeeze_score"], r["long_squeeze_score"])
        fund = (r["funding"] or 0) * 100
        print(f"{r['symbol']:<14}{r['direction']:<6}{r['long_score']:>6.1f}"
              f"{r['conviction']:>6.2f}{r['regime']:<17}{fund:>8.4f}{sq:>6.0f}"
              f"{s['entry']:>13.6g}{s['stop']:>13.6g}{s['tp2']:>13.6g}"
              f"{s['risk_pct']:>7.2f}  {s['risk_rating']}")
    if not res["candidates"]:
        print("(no candidates above conviction threshold)")


def main() -> None:
    p = argparse.ArgumentParser(description="Binance perp scanner (public data only)")
    p.add_argument("--interval", default="15m", choices=list(BARS_PER_HOUR))
    p.add_argument("--top-n", type=int, default=150)
    p.add_argument("--deriv-top", type=int, default=60)
    p.add_argument("--min-quote-vol", type=float, default=30e6)
    p.add_argument("--min-conviction", type=float, default=0.15)
    p.add_argument("--atr-mult", type=float, default=1.5)
    p.add_argument("--account-risk-pct", type=float, default=0.5)
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--db", default="radar.db")
    p.add_argument("--json-out", default=None, help="write full result JSON here")
    p.add_argument("--loop", type=int, default=0, help="seconds between cycles (0 = once)")
    p.add_argument("--show", type=int, default=20)
    p.add_argument("-v", "--verbose", action="store_true")
    a = p.parse_args()

    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cli = BinanceFutures()
    store = Store(a.db)

    while True:
        try:
            res = scan_once(cli, store, interval=a.interval, top_n=a.top_n,
                            deriv_top=a.deriv_top, min_quote_vol=a.min_quote_vol,
                            workers=a.workers, min_conviction=a.min_conviction,
                            atr_mult=a.atr_mult, account_risk_pct=a.account_risk_pct)
            print_table(res, a.show)
            if a.json_out:
                with open(a.json_out, "w") as fh:
                    json.dump(res, fh, indent=2, default=float)
        except Exception as e:                            # noqa: BLE001
            log.exception("scan cycle failed: %s", e)
        if not a.loop:
            break
        time.sleep(a.loop)


if __name__ == "__main__":
    main()
