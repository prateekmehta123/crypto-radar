"""
On-chain flow feed: large Arkham transfers, grouped and interpreted per coin.

This reads what onchain.py already sweeps and persists, then says what it
plausibly means. Two rules govern the interpretation:

**Ambiguity is stated, not hidden.** A large deposit to an exchange is *often*
pre-sale positioning. It is also, routinely: market-maker inventory, OTC
settlement, collateral posting, or a custodian moving between its own wallets
in a way Arkham has not labelled internal. Where the read is genuinely
uncertain, the text says so instead of picking the dramatic option.

**Nothing here feeds the score.** Same reasoning as onchain.py: flow data
cannot be backtested, and mixing an unvalidated signal into a validated number
destroys the meaning of the validated one.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

import pandas as pd

log = logging.getLogger("radar.news")


def _fmt_usd(v: float) -> str:
    if v >= 1e9:
        return f"${v / 1e9:.2f}B"
    if v >= 1e6:
        return f"${v / 1e6:.1f}M"
    if v >= 1e3:
        return f"${v / 1e3:.0f}K"
    return f"${v:.0f}"


def interpret_symbol(symbol: str, rows: List[dict],
                     price_change_pct: Optional[float] = None) -> Dict[str, Any]:
    """Turn a coin's transfers over the window into a readable summary."""
    inflow = sum(r["usd"] for r in rows if r["direction"] == "exchange_in")
    outflow = sum(r["usd"] for r in rows if r["direction"] == "exchange_out")
    wallet = sum(r["usd"] for r in rows if r["direction"] == "wallet_to_wallet")
    internal = sum(r["usd"] for r in rows if r["direction"] == "exchange_internal")
    net = inflow - outflow
    biggest = max(rows, key=lambda r: r["usd"]) if rows else None

    entities: Dict[str, float] = {}
    for r in rows:
        for e in (r.get("from_entity"), r.get("to_entity")):
            if e:
                entities[e] = entities.get(e, 0.0) + r["usd"]
    top_entities = sorted(entities.items(), key=lambda kv: -kv[1])[:5]

    parts: List[str] = []
    base = symbol.replace("USDT", "")
    total = inflow + outflow + wallet + internal
    parts.append(f"{len(rows)} large {base} transfers totalling {_fmt_usd(total)}.")

    if inflow or outflow:
        if abs(net) < 0.15 * max(inflow, outflow, 1):
            parts.append(
                f"Exchange flow is roughly balanced — {_fmt_usd(inflow)} in against "
                f"{_fmt_usd(outflow)} out. Balanced flow usually means routine "
                f"rebalancing rather than anyone taking a view.")
        elif net > 0:
            parts.append(
                f"Net {_fmt_usd(net)} moved onto exchanges ({_fmt_usd(inflow)} in, "
                f"{_fmt_usd(outflow)} out). Coins arriving on an exchange are coins "
                f"that *can* be sold, which is not the same as coins that will be — "
                f"this is also what market-maker inventory and OTC settlement look "
                f"like. Read it as a reason to be less confident in longs, not as a "
                f"short signal.")
        else:
            parts.append(
                f"Net {_fmt_usd(abs(net))} moved off exchanges ({_fmt_usd(outflow)} "
                f"out, {_fmt_usd(inflow)} in). Withdrawals reduce immediately "
                f"sellable supply and often mean custody or staking, though they can "
                f"equally be an exchange shuffling its own reserves.")

    if internal > 0 and internal > 0.4 * total:
        parts.append(
            f"Note that {_fmt_usd(internal)} of this moved exchange-to-exchange, "
            f"which is plumbing rather than positioning.")

    if price_change_pct is not None and (inflow or outflow):
        if net > 0 and price_change_pct > 1:
            parts.append(
                f"Price is up {price_change_pct:.1f}% over the same window despite "
                f"the net inflow, so whatever arrived is being absorbed.")
        elif net > 0 and price_change_pct < -1:
            parts.append(
                f"Price is down {price_change_pct:.1f}% alongside the inflow — the "
                f"two are consistent, though consistency is not causation.")
        elif net < 0 and price_change_pct > 1:
            parts.append(
                f"Price is up {price_change_pct:.1f}% while coins left exchanges, "
                f"which is the more constructive combination of the two.")

    if biggest:
        src = biggest.get("from_entity") or "an unlabelled wallet"
        dst = biggest.get("to_entity") or "an unlabelled wallet"
        parts.append(f"Largest single move: {_fmt_usd(biggest['usd'])} from {src} to {dst}.")

    return {
        "symbol": symbol,
        "transfers": len(rows),
        "inflow_usd": round(inflow, 0),
        "outflow_usd": round(outflow, 0),
        "net_to_exchange_usd": round(net, 0),
        "wallet_to_wallet_usd": round(wallet, 0),
        "internal_usd": round(internal, 0),
        "biggest": biggest,
        "top_entities": [{"name": k, "usd": round(v, 0)} for k, v in top_entities],
        "lean": ("supply arriving" if net > 0.15 * max(inflow, outflow, 1)
                 else "supply leaving" if net < -0.15 * max(inflow, outflow, 1)
                 else "balanced"),
        "text": " ".join(parts),
    }


def build_feed(store, hours: float = 24.0, min_usd: float = 1_000_000,
               marks: Optional[Dict[str, float]] = None,
               enabled: bool = True) -> Dict[str, Any]:
    """Assemble the feed from persisted transfers."""
    since = int((time.time() - hours * 3600) * 1000)
    try:
        df = store.transfers_df(since_ms=since)
    except Exception as e:                                # noqa: BLE001
        log.warning("could not read transfers: %s", e)
        df = pd.DataFrame()

    if df.empty:
        note = (f"No transfers above {_fmt_usd(min_usd)} recorded in the last "
                f"{hours:.0f} hours. The scanner only records coins in its current "
                f"universe, and quiet periods are genuinely quiet.") if enabled else (
                "On-chain tracking is off and nothing has been recorded yet. Set "
                "ARKHAM_API_KEY to turn it on — the scanner will then sweep large "
                "transfers each cycle and this tab fills in. Access is gated; you "
                "apply at arkm.com/api.")
        return {
            "enabled": enabled, "collecting": enabled, "since_ms": since,
            "hours": hours, "headline": "Nothing to report.",
            "transfers": [], "by_symbol": [],
            "totals": {"transfers": 0, "usd": 0, "inflow_usd": 0, "outflow_usd": 0},
            "note": note,
        }

    df = df[df["usd"] >= min_usd]
    rows = df.sort_values("ts", ascending=False).to_dict("records")

    by_symbol: List[dict] = []
    for sym, grp in df.groupby("symbol"):
        if not sym:
            continue
        by_symbol.append(interpret_symbol(sym, grp.to_dict("records"),
                                          (marks or {}).get(sym)))
    by_symbol.sort(key=lambda x: -(abs(x["net_to_exchange_usd"]) + x["inflow_usd"]
                                   + x["outflow_usd"]))

    total_usd = float(df["usd"].sum())
    inflow = float(df[df["direction"] == "exchange_in"]["usd"].sum())
    outflow = float(df[df["direction"] == "exchange_out"]["usd"].sum())

    if inflow + outflow == 0:
        headline = "No exchange flow in the window — only wallet-to-wallet movement."
    elif inflow > outflow * 1.25:
        headline = (f"Net {_fmt_usd(inflow - outflow)} moved onto exchanges across "
                    f"{len(by_symbol)} coins — more sellable supply on hand than "
                    f"{hours:.0f} hours ago.")
    elif outflow > inflow * 1.25:
        headline = (f"Net {_fmt_usd(outflow - inflow)} moved off exchanges across "
                    f"{len(by_symbol)} coins — supply moving into custody.")
    else:
        headline = (f"Exchange flow is broadly balanced across {len(by_symbol)} coins "
                    f"— nothing here suggests a directional bet.")

    stale = ("" if enabled else
             " Live collection is currently off (no ARKHAM_API_KEY), so this is "
             "what was recorded previously rather than a live feed.")
    return {
        # Data already recorded is shown whether or not collection is running --
        # hiding it because the key was removed would lose information for no gain.
        "enabled": True,
        "collecting": enabled,
        "since_ms": since,
        "hours": hours,
        "headline": headline,
        "totals": {"transfers": len(rows), "usd": round(total_usd, 0),
                   "inflow_usd": round(inflow, 0), "outflow_usd": round(outflow, 0)},
        "by_symbol": by_symbol,
        "transfers": rows[:120],
        "note": ("Interpretation only — on-chain flow is never part of the score, "
                 "because it cannot be backtested. Attribution comes from Arkham; "
                 "unlabelled wallets are shown as addresses." + stale),
    }
