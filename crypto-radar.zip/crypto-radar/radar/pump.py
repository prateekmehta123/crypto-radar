"""
Pump candidates: which coins look primed for a large upward move.

TWO CLAIMS, KEPT SEPARATE
-------------------------
Most "pump scanners" conflate two different predictions:

  1. **A big move is coming.** Volatility compression, open-interest buildup in
     a range, and volume accumulating on flat price all predict *magnitude*.
     They are directionless -- a coiled spring does not know which way it will
     release.
  2. **The move will be up.** Crowded shorts, improving relative strength,
     exchange outflows and upside liquidity lean directional.

Scoring them together produces a number that feels informative and answers
neither question. So this module reports `energy` (how loaded the setup is) and
`lean` (which way it points) separately, and combines them only at the end,
where you can see the arithmetic.

THE TRACK RECORD, AND WHY IT HAS A CONTROL GROUP
------------------------------------------------
Every candidate is written to the database when it is named, before the outcome
exists. After the horizon it is resolved against what price actually did.

The hit rate alone is meaningless. If a third of all coins gain 15% in a good
week, a 35% hit rate on this watchlist is worse than picking at random. So
every resolution also computes the **base rate** -- what fraction of the whole
tracked universe achieved the same move over the same window -- and reports the
difference. That difference, called `edge_vs_base_rate`, is the only number
here worth anything.

If it is not consistently positive over dozens of resolved calls, this feature
does not work, and the honest response is to stop using it rather than to
retune it until it looks better.

WHAT IS AND ISN'T MEASURABLE
----------------------------
Liquidations: Binance publishes no complete public history. The `forceOrders`
REST endpoint is account-scoped, and the public WebSocket stream is throttled to
roughly one event per second per symbol, so it is a sample rather than a record.
What this module uses instead is a *modelled* liquidation cluster: where
positions opened around the OI-weighted average price would be liquidated at
common leverage. It is inference from open interest and price, clearly labelled
`estimated_liq_cluster`, and it is not a data feed.
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

log = logging.getLogger("radar.pump")

DEFAULT_TARGET_PCT = 15.0
DEFAULT_HORIZON_HOURS = 168.0        # 7 days


@dataclass
class Component:
    name: str
    value: float          # 0..1
    weight: float
    kind: str             # "energy" | "lean"
    detail: str
    available: bool = True


def _clip01(x: float) -> float:
    if x is None or not np.isfinite(x):
        return 0.0
    return float(np.clip(x, 0.0, 1.0))


def _pctile_low_is_good(p: float) -> float:
    """Compression: a low percentile means tightly coiled."""
    if p is None or not np.isfinite(p):
        return 0.0
    return _clip01(1.0 - p)


def score_pump(r: pd.Series, whale: Optional[dict] = None) -> Dict[str, Any]:
    """Score one symbol's latest feature row for pump potential."""
    comps: List[Component] = []

    # ---------------------------------------------------------- ENERGY side
    squeeze = r.get("bb_squeeze_pctile", np.nan)
    comps.append(Component(
        "volatility compression", _pctile_low_is_good(squeeze), 0.22, "energy",
        f"Bollinger width at the {squeeze * 100:.0f}th percentile of the last week"
        if np.isfinite(squeeze) else "not enough history",
        bool(np.isfinite(squeeze))))

    atr_exp = r.get("atr_expansion", np.nan)
    comps.append(Component(
        "range contraction", _clip01((1.15 - atr_exp) / 0.5) if np.isfinite(atr_exp) else 0.0,
        0.10, "energy",
        f"ATR at {atr_exp:.2f}x its daily average" if np.isfinite(atr_exp)
        else "not enough history",
        bool(np.isfinite(atr_exp))))

    # OI building while price goes nowhere = positions stacking inside a range
    oi4 = r.get("oi_chg_4h", np.nan)
    ret4 = r.get("ret_4h", np.nan)
    if np.isfinite(oi4) and np.isfinite(ret4):
        coiled = _clip01(oi4 / 0.04) * _clip01(1 - abs(ret4) / 0.05)
        det = (f"open interest {oi4 * 100:+.1f}% over 4h while price moved "
               f"{ret4 * 100:+.1f}%")
    else:
        coiled, det = 0.0, "open interest unavailable"
    comps.append(Component("positions stacking in a range", coiled, 0.18, "energy",
                           det, bool(np.isfinite(oi4))))

    volz = r.get("vol_z", np.nan)
    cvd4 = r.get("cvd_slope_4h", np.nan)
    if np.isfinite(volz) and np.isfinite(ret4):
        accum = _clip01(volz / 2.0) * _clip01(1 - abs(ret4) / 0.06)
        det = f"volume {volz:+.1f}σ on a {ret4 * 100:+.1f}% 4h move"
    else:
        accum, det = 0.0, "volume history unavailable"
    comps.append(Component("volume accumulating on flat price", accum, 0.12, "energy",
                           det, bool(np.isfinite(volz))))

    # ------------------------------------------------------------ LEAN side
    # Crowded shorts are fuel: negative funding means shorts pay longs to hold.
    fz = r.get("funding_z_7d", np.nan)
    fnd = r.get("funding", np.nan)
    if np.isfinite(fz):
        short_crowd = _clip01(-fz / 2.0)
        det = f"funding {fz:+.1f}σ vs its own week"
    elif np.isfinite(fnd):
        short_crowd = _clip01(-fnd * 3000)
        det = f"funding {fnd * 100:+.4f}% per 8h"
    else:
        short_crowd, det = 0.0, "funding unavailable"
    comps.append(Component("shorts crowded (squeeze fuel)", short_crowd, 0.16, "lean",
                           det, bool(np.isfinite(fnd) or np.isfinite(fz))))

    tls = r.get("taker_ls_ratio", np.nan)
    comps.append(Component(
        "aggressive buyers present",
        _clip01((tls - 0.95) / 0.35) if np.isfinite(tls) else 0.0, 0.06, "lean",
        f"taker buy/sell ratio {tls:.2f}" if np.isfinite(tls) else "not available",
        bool(np.isfinite(tls))))

    rs24 = r.get("rs_24h", np.nan)
    rs4 = r.get("rs_4h", np.nan)
    if np.isfinite(rs4) and np.isfinite(rs24):
        # turning up against BTC from a weak base is the interesting shape
        turning = _clip01(rs4 / 0.03) * _clip01((0.02 - rs24) / 0.06 + 0.4)
        det = f"vs BTC: {rs4 * 100:+.1f}% over 4h, {rs24 * 100:+.1f}% over 24h"
    else:
        turning, det = 0.0, "relative strength unavailable"
    comps.append(Component("turning up against BTC", turning, 0.10, "lean", det,
                           bool(np.isfinite(rs4))))

    liq_up = r.get("liq_up_dist", np.nan)
    comps.append(Component(
        "room to run above",
        _clip01(liq_up / 0.08) if np.isfinite(liq_up) else 0.0, 0.06, "lean",
        f"nearest overhead liquidity {liq_up * 100:.1f}% away"
        if np.isfinite(liq_up) else "no clear level above",
        bool(np.isfinite(liq_up))))

    if whale and whale.get("net_to_exchange_usd") is not None:
        net = whale["net_to_exchange_usd"]
        out_lean = _clip01(-net / 5e6)
        det = (f"net ${abs(net) / 1e6:.1f}M "
               f"{'off' if net < 0 else 'onto'} exchanges")
        comps.append(Component("supply leaving exchanges", out_lean, 0.08, "lean",
                               det, True))
    else:
        comps.append(Component("supply leaving exchanges", 0.0, 0.08, "lean",
                               "on-chain tracking off", False))

    # ------------------------------------------------------------- combine
    def _agg(kind: str) -> Tuple[float, float]:
        sel = [c for c in comps if c.kind == kind]
        w = sum(c.weight for c in sel if c.available)
        if w <= 0:
            return 0.0, 0.0
        return sum(c.value * c.weight for c in sel if c.available) / w, \
            w / sum(c.weight for c in sel)

    energy, e_cov = _agg("energy")
    lean, l_cov = _agg("lean")
    coverage = (e_cov + l_cov) / 2

    # A big move needs energy; an UP move needs lean. Multiplying means a
    # coiled spring with no directional edge scores low, which is correct --
    # compression alone is as likely to resolve downward.
    score = 100.0 * math.sqrt(max(energy, 0.0) * max(lean, 0.0)) * coverage

    return {
        "pump_score": round(score, 1),
        "energy": round(energy * 100, 1),
        "lean": round(lean * 100, 1),
        "coverage": round(coverage, 2),
        "components": [asdict(c) for c in comps],
        "reasons": [c.detail for c in sorted(comps, key=lambda x: -x.value * x.weight)
                    if c.available and c.value > 0.15][:4],
        "estimated_liq_cluster": _liq_cluster(r),
        "caveat": ("Compression predicts size, not direction. `energy` is how loaded "
                   "the setup is; `lean` is which way it points. A high energy score "
                   "with a low lean means a big move is plausible and its direction "
                   "is a coin flip."),
    }


def _liq_cluster(r: pd.Series) -> Optional[dict]:
    """Modelled, not observed. See the module docstring."""
    px = float(r.get("close", np.nan))
    if not np.isfinite(px):
        return None
    vwap_dist = r.get("vwap_dist", np.nan)
    if not np.isfinite(vwap_dist):
        return None
    avg_entry = px / (1 + vwap_dist)
    out = {}
    for lev in (10, 25, 50):
        out[f"{lev}x_shorts"] = round(avg_entry * (1 + 1 / lev), 8)
        out[f"{lev}x_longs"] = round(avg_entry * (1 - 1 / lev), 8)
    out["basis"] = ("modelled from the volume-weighted average price, not a "
                    "liquidation feed — Binance publishes no complete public history")
    return out


# --------------------------------------------------------------- watchlist

def build_watchlist(feats_by_symbol: Dict[str, pd.Series],
                    whale_ctx: Optional[Dict[str, dict]] = None,
                    min_score: float = 35.0, limit: int = 15) -> List[dict]:
    rows = []
    for sym, r in feats_by_symbol.items():
        s = score_pump(r, (whale_ctx or {}).get(sym))
        if s["pump_score"] < min_score:
            continue
        rows.append({"symbol": sym, "price": float(r.get("close", np.nan)), **s})
    rows.sort(key=lambda x: -x["pump_score"])
    return rows[:limit]


# ------------------------------------------------------------ track record

def record_calls(store, watchlist: List[dict], now_ms: int,
                 target_pct: float = DEFAULT_TARGET_PCT,
                 horizon_hours: float = DEFAULT_HORIZON_HOURS,
                 recall_hours: float = 24.0) -> int:
    """Write each candidate as a falsifiable call, before the outcome exists.

    One call per symbol per `recall_hours` window, so a coin sitting on the
    watchlist for three days is one prediction rather than seventy-two.
    """
    if store is None:
        return 0
    written = 0
    for row in watchlist:
        if store.pump_call_recent(row["symbol"], now_ms - int(recall_hours * 3600_000)):
            continue
        store.record_pump_call({
            "ts": now_ms, "symbol": row["symbol"], "price_at_call": row["price"],
            "pump_score": row["pump_score"], "energy": row["energy"],
            "lean": row["lean"], "target_pct": target_pct,
            "horizon_ms": int(horizon_hours * 3600_000),
            "reasons": " | ".join(row.get("reasons", [])),
        })
        written += 1
    return written


def resolve_calls(store, cli, now_ms: int) -> int:
    """Resolve matured calls against what price actually did, with a control."""
    if store is None:
        return 0
    pending = store.pump_calls_to_resolve(now_ms)
    resolved = 0
    for call in pending:
        start, end = call["ts"], call["ts"] + call["horizon_ms"]
        stats = _max_move(cli, call["symbol"], start, end)
        if stats is None:
            continue
        base = _base_rate(store, cli, start, end, call["target_pct"],
                          exclude=call["symbol"])
        hit = stats["max_gain_pct"] >= call["target_pct"]
        store.resolve_pump_call(call["ts"], call["symbol"], {
            "resolved_ms": now_ms,
            "max_gain_pct": stats["max_gain_pct"],
            "max_drawdown_pct": stats["max_drawdown_pct"],
            "hours_to_peak": stats["hours_to_peak"],
            "final_pct": stats["final_pct"],
            "hit": 1 if hit else 0,
            "base_rate_pct": base,
        })
        resolved += 1
    return resolved


def _max_move(cli, symbol: str, start_ms: int, end_ms: int) -> Optional[dict]:
    from .features import klines_to_df
    raw = cli.klines(symbol, "1h", 500, start_ms=start_ms, end_ms=end_ms)
    if not raw or len(raw) < 3:
        return None
    df = klines_to_df(raw)
    entry = float(df["open"].iloc[0])
    if entry <= 0:
        return None
    hi = df["high"].cummax()
    peak_i = int(np.argmax(df["high"].values))
    return {
        "max_gain_pct": round((float(df["high"].max()) / entry - 1) * 100, 2),
        "max_drawdown_pct": round((float(df["low"].min()) / entry - 1) * 100, 2),
        "final_pct": round((float(df["close"].iloc[-1]) / entry - 1) * 100, 2),
        "hours_to_peak": int(peak_i),
    }


def _base_rate(store, cli, start_ms: int, end_ms: int, target_pct: float,
               exclude: str = "", sample: int = 25) -> Optional[float]:
    """What fraction of the tracked universe achieved the same move?

    This is the control group. Without it a hit rate is unreadable -- in a
    strong week a third of everything moves 15%, and a watchlist that matches
    the market has found nothing.
    """
    try:
        syms = store.symbols_seen_near(start_ms)
    except Exception:                                     # noqa: BLE001
        return None
    syms = [s for s in syms if s != exclude][:sample]
    if len(syms) < 8:
        return None
    hits = 0
    counted = 0
    for s in syms:
        st = _max_move(cli, s, start_ms, end_ms)
        if st is None:
            continue
        counted += 1
        if st["max_gain_pct"] >= target_pct:
            hits += 1
    return round(hits / counted * 100, 1) if counted >= 8 else None


def track_record(store, target_pct: float = DEFAULT_TARGET_PCT) -> Dict[str, Any]:
    if store is None:
        return {"resolved": 0}
    rows = store.pump_calls()
    done = [r for r in rows if r.get("resolved_ms")]
    pending = [r for r in rows if not r.get("resolved_ms")]
    n = len(done)
    if not n:
        return {
            "target_pct": target_pct, "resolved": 0, "pending": len(pending),
            "calls": rows[-50:][::-1],
            "verdict": ("No calls have matured yet. The first ones resolve a week "
                        "after they were made — nothing here means anything until "
                        "then."),
        }

    hits = sum(1 for r in done if r["hit"])
    hit_rate = hits / n * 100
    bases = [r["base_rate_pct"] for r in done if r.get("base_rate_pct") is not None]
    base = float(np.mean(bases)) if bases else None
    edge = round(hit_rate - base, 1) if base is not None else None
    gains = [r["max_gain_pct"] for r in done]

    return {
        "target_pct": target_pct,
        "resolved": n,
        "pending": len(pending),
        "hits": hits,
        "hit_rate_pct": round(hit_rate, 1),
        "base_rate_pct": round(base, 1) if base is not None else None,
        "edge_vs_base_rate": edge,
        "avg_max_gain_pct": round(float(np.mean(gains)), 2),
        "median_max_gain_pct": round(float(np.median(gains)), 2),
        "avg_max_drawdown_pct": round(
            float(np.mean([r["max_drawdown_pct"] for r in done])), 2),
        "avg_hours_to_peak": round(
            float(np.mean([r["hours_to_peak"] for r in done if r["hours_to_peak"]])), 1)
        if any(r["hours_to_peak"] for r in done) else None,
        "best": max(done, key=lambda r: r["max_gain_pct"]),
        "calls": rows[-50:][::-1],
        "verdict": _verdict(n, hit_rate, base, edge),
    }


def _verdict(n: int, hit_rate: float, base: Optional[float],
             edge: Optional[float]) -> str:
    if n < 10:
        return (f"{n} resolved call(s), {hit_rate:.0f}% hit the target. Far too few "
                f"to read anything into — at this sample size a run of hits is "
                f"ordinary luck.")
    if base is None:
        return (f"{n} resolved, {hit_rate:.0f}% hit rate. No base rate could be "
                f"computed, so there is nothing to compare it against — the number "
                f"on its own is not interpretable.")
    if edge is None:
        return f"{n} resolved, {hit_rate:.0f}% hit rate against a {base:.0f}% base rate."

    strength = ("still noisy" if n < 30 else
                "worth taking seriously" if n < 100 else "reasonably solid")
    if edge > 8:
        read = (f"beating the market's own rate by {edge:+.0f} points, which is the "
                f"result you want")
    elif edge > 2:
        read = f"ahead of the base rate by {edge:+.0f} points, which is modest"
    elif edge > -2:
        read = ("indistinguishable from picking coins at random — the watchlist is "
                "not adding information")
    else:
        read = (f"{abs(edge):.0f} points WORSE than random. The screen is actively "
                f"selecting against you and should not be traded")
    return (f"{n} resolved calls: {hit_rate:.0f}% reached +{DEFAULT_TARGET_PCT:.0f}% "
            f"versus a {base:.0f}% base rate for the universe — {read}. "
            f"At {n} calls this reading is {strength}.")
