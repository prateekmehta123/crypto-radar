"""
Signal track record, replayed from history.

WHAT THIS IS, AND WHAT IT IS NOT
--------------------------------
This replays the current scoring rules over past bars and resolves each signal
against what price actually did next. It is a **backtest**, and it is weaker
evidence than the Challenge tab, for one unavoidable reason: the rules already
existed when I looked backwards. Every weight in score.py was chosen by someone
who had already seen this data.

The Challenge tab does not have that problem -- the signal is recorded before
the outcome exists. So when the two disagree, believe the Challenge.

What this is good for: immediate feedback on a coin you are looking at right
now, across every timeframe at once, without waiting a month. Treat it as a
sanity check ("do these rules produce anything coherent on SOL?"), not as proof.

Resolution rules match backtest.py and challenge.py exactly:
  * entry fills at the OPEN of the bar after the signal
  * stop at atr_mult x ATR, targets at 1R / 2R / 3R
  * a bar whose range covers both stop and target counts as the STOP
  * signals too recent to have resolved are reported as unresolved, never as wins
"""

from __future__ import annotations

import logging
import math
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .analyze import TIMEFRAMES
from .client import BinanceFutures
from .features import (add_derivatives, add_funding_series, add_relative_strength,
                       compute_features, klines_to_df)
from .score import DEFAULT_WEIGHTS, aggregate, block_frame

log = logging.getLogger("radar.track")

# Bars to allow a signal to resolve, per timeframe. Roughly a day or two of
# market time on fast charts, a few weeks on slow ones.
MAX_HOLD_BARS = {
    "1m": 120, "3m": 100, "5m": 96, "15m": 64, "1h": 48,
    "4h": 30, "1d": 20, "3d": 14, "1w": 10, "1M": 6,
}


def replay(df: pd.DataFrame, tf: str, min_conviction: float = 0.15,
           atr_mult: float = 1.5, want: int = 10,
           cooldown_bars: Optional[int] = None) -> Dict[str, Any]:
    """Find the most recent `want` signals on this timeframe and resolve them."""
    meta = TIMEFRAMES.get(tf)
    if meta is None or len(df) < 120:
        return {"signals": [], "stats": _stats([]), "note": "not enough history"}

    bph = meta["bars_per_hour"]
    max_hold = MAX_HOLD_BARS.get(tf, 48)
    if cooldown_bars is None:
        cooldown_bars = max(3, max_hold // 6)

    f = compute_features(df, bph)
    f = f.dropna(subset=["atr", "close"])
    if len(f) < 60:
        return {"signals": [], "stats": _stats([]), "note": "not enough usable bars"}

    vals, avail = block_frame(f)
    agg = aggregate(vals, avail, DEFAULT_WEIGHTS)
    hits = agg[(agg["conviction"] >= min_conviction) & (agg["direction"] != "FLAT")]
    if hits.empty:
        return {"signals": [], "stats": _stats([]),
                "note": f"no signal crossed {min_conviction:.2f} conviction in "
                        f"{len(f)} bars"}

    idx = list(f.index)
    pos = {t: i for i, t in enumerate(idx)}
    o = df["open"].reindex(f.index).values
    hi = df["high"].reindex(f.index).values
    lo = df["low"].reindex(f.index).values
    cl = df["close"].reindex(f.index).values
    atr_v = f["atr"].values
    n = len(idx)

    # walk newest-first, respecting a cooldown so one trend isn't 40 signals
    out: List[dict] = []
    last_i = 10 ** 9
    for t in reversed(hits.index):
        i = pos.get(t)
        if i is None or i + 1 >= n:
            continue
        if last_i - i < cooldown_bars:
            continue
        last_i = i

        row = hits.loc[t]
        direction = row["direction"]
        long = direction == "LONG"
        entry = float(o[i + 1])
        a = float(atr_v[i])
        if not np.isfinite(entry) or not np.isfinite(a) or a <= 0:
            continue
        risk = atr_mult * a
        stop = entry - risk if long else entry + risk
        tps = [entry + k * risk if long else entry - k * risk for k in (1, 2, 3)]

        reached = 0
        outcome = "open"
        exit_px: Optional[float] = None
        bars_held = 0
        for j in range(i + 1, min(i + 1 + max_hold, n)):
            bars_held = j - i
            h, l = hi[j], lo[j]
            hit_stop = (l <= stop) if long else (h >= stop)
            level = 0
            for k, tp in enumerate(tps, start=1):
                if (h >= tp) if long else (l <= tp):
                    level = k
            # pessimistic: both in one bar is a stop
            if hit_stop:
                outcome, exit_px = ("tp_then_stop" if reached else "stop"), stop
                break
            if level:
                reached = max(reached, level)
                if reached >= 3:
                    outcome, exit_px = "tp3", tps[2]
                    break
        else:
            if i + 1 + max_hold <= n:
                outcome = f"tp{reached}" if reached else "timeout"
                exit_px = tps[reached - 1] if reached else float(cl[min(i + max_hold, n - 1)])

        unresolved = outcome == "open"
        if unresolved:
            exit_px = float(cl[n - 1])

        gross = ((exit_px - entry) if long else (entry - exit_px)) / entry
        r_mult = gross * entry / risk

        out.append({
            "time": t.isoformat(),
            "timeframe": tf,
            "direction": direction,
            "conviction": round(float(row["conviction"]), 3),
            "score": round(50 * (1 + float(row["net"])), 1),
            "entry": entry, "stop": stop,
            "tp1": tps[0], "tp2": tps[1], "tp3": tps[2],
            "reached_tp": int(reached),
            "outcome": outcome,
            "resolved": not unresolved,
            "exit": exit_px,
            "bars_held": bars_held,
            "r_multiple": round(float(r_mult), 2),
            "return_pct": round(float(gross) * 100, 2),
        })
        if len(out) >= want:
            break

    return {"signals": out, "stats": _stats(out), "note": None}


def _stats(sigs: List[dict]) -> Dict[str, Any]:
    resolved = [s for s in sigs if s["resolved"]]
    n = len(resolved)
    if not n:
        return {"resolved": 0, "unresolved": len(sigs) - n,
                "tp1_or_better_pct": None, "tp2_or_better_pct": None,
                "tp3_pct": None, "stopped_pct": None, "avg_r": None,
                "expectancy_r": None}
    tp1 = sum(1 for s in resolved if s["reached_tp"] >= 1)
    tp2 = sum(1 for s in resolved if s["reached_tp"] >= 2)
    tp3 = sum(1 for s in resolved if s["reached_tp"] >= 3)
    stopped = sum(1 for s in resolved if s["outcome"] in ("stop", "tp_then_stop"))
    rs = [s["r_multiple"] for s in resolved]
    return {
        "resolved": n,
        "unresolved": len(sigs) - n,
        "tp1_or_better_pct": round(tp1 / n * 100, 1),
        "tp2_or_better_pct": round(tp2 / n * 100, 1),
        "tp3_pct": round(tp3 / n * 100, 1),
        "stopped_pct": round(stopped / n * 100, 1),
        "avg_r": round(float(np.mean(rs)), 2),
        "expectancy_r": round(float(np.mean(rs)), 2),
    }


def track_symbol(cli: BinanceFutures, symbol: str,
                 timeframes: Optional[List[str]] = None,
                 want: int = 10, min_conviction: float = 0.15) -> Dict[str, Any]:
    tfs = timeframes or list(TIMEFRAMES)
    per: Dict[str, Any] = {}
    all_sigs: List[dict] = []
    for tf in tfs:
        b = TIMEFRAMES[tf]["binance"]
        raw = cli.klines(symbol, b, 500)
        if not raw or len(raw) < 120:
            per[tf] = {"signals": [], "stats": _stats([]),
                       "note": "not enough history on this timeframe"}
            continue
        df = klines_to_df(raw).iloc[:-1]
        try:
            per[tf] = replay(df, tf, min_conviction=min_conviction, want=want)
            all_sigs.extend(per[tf]["signals"])
        except Exception as e:                            # noqa: BLE001
            log.warning("replay failed %s %s: %s", symbol, tf, e)
            per[tf] = {"signals": [], "stats": _stats([]), "note": str(e)}

    combined = _stats(all_sigs)
    best = None
    worst = None
    ranked = [(tf, d["stats"]) for tf, d in per.items()
              if d["stats"]["resolved"] >= 4 and d["stats"]["expectancy_r"] is not None]
    if ranked:
        best = max(ranked, key=lambda kv: kv[1]["expectancy_r"])[0]
        worst = min(ranked, key=lambda kv: kv[1]["expectancy_r"])[0]

    return {
        "symbol": symbol,
        "per_timeframe": per,
        "timeframe_order": [t for t in TIMEFRAMES if t in per],
        "combined": combined,
        "best_timeframe": best,
        "worst_timeframe": worst,
        "verdict": _verdict(combined, len(ranked)),
        "disclaimer": (
            "Replayed from history using today's rules, so it is a backtest and not "
            "a track record — the weights were chosen by someone who had already "
            "seen these bars. The Challenge tab is the honest version, because "
            "there the signal is recorded before the outcome exists."),
    }


def _verdict(stats: dict, n_tfs: int) -> str:
    n = stats.get("resolved") or 0
    if n < 8:
        return (f"Only {n} resolved signals across all timeframes. That is far too "
                f"few to read anything into.")
    tp1 = stats.get("tp1_or_better_pct")
    ex = stats.get("expectancy_r")
    if tp1 is None or ex is None:
        return "Not enough resolved signals to summarise."
    if n < 25:
        strength = "a hint, no more"
    elif n < 60:
        strength = "suggestive but not settled"
    else:
        strength = "reasonably informative"
    lean = ("positive" if ex > 0.1 else "negative" if ex < -0.1 else "roughly flat")
    return (f"{n} resolved signals, {tp1:.0f}% reached at least the first target, "
            f"expectancy {ex:+.2f}R — {lean}, and with this sample size that is "
            f"{strength}.")
