"""
Hyperliquid public data: order book imbalance and open positions.

WHY THIS EXCHANGE
-----------------
Two things Binance cannot give you.

**A real order book.** `l2Book` returns full depth, free, no key. Your
highest-weighted scoring block is order flow, and it currently runs on
aggregated kline taker fields -- the coarsest version of that data available.
Actual resting depth is a different quality of input.

**Public positions.** Hyperliquid settles on-chain, so `clearinghouseState`
returns any address's open positions, entry price, leverage and liquidation
price. Not an aggregate long/short ratio -- the actual positions. There is no
equivalent anywhere on Binance.

WHAT THIS IS NOT
----------------
* **Not a liquidation feed.** Hyperliquid publishes no aggregate public
  liquidation stream; liquidations surface as individual fills, so a global
  view means indexing every fill or paying someone who has. The
  "liquidation heatmaps" you see elsewhere, including in the terminal that
  prompted this module, are *modelled* from open interest and price. So is
  ours, in pump.py, and it says so.
* **Not a replacement for Binance.** Hyperliquid's book is thinner. A 200k
  wall there means something different from 200k on Binance, and the same
  imbalance number implies less. Treat it as a second opinion.
* **Not unspoofable.** Resting depth is an intention, not a commitment. Large
  visible size can be pulled the moment it is approached, and on a thin book
  that is cheap to do. This is why book imbalance is wired as a *veto* on
  trades already justified by other means, never as a reason to enter.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import requests

log = logging.getLogger("radar.hyperliquid")

INFO_URL = "https://api.hyperliquid.xyz/info"
# Unofficial stats host used by the web UI's leaderboard. Not part of the
# documented API, so it is best-effort: if it moves or breaks, the watchlist
# simply stays empty and everything else carries on.
LEADERBOARD_URL = "https://stats-data.hyperliquid.xyz/Mainnet/leaderboard"


def to_hl_coin(symbol: str) -> str:
    """BTCUSDT -> BTC. Hyperliquid names coins without the quote asset."""
    s = symbol.upper()
    for suffix in ("USDT", "USDC", "USD"):
        if s.endswith(suffix):
            return s[: -len(suffix)]
    return s


class HyperliquidClient:
    def __init__(self, timeout: float = 12.0, min_gap_s: float = 0.12,
                 cache_ttl: float = 20.0):
        self.timeout = timeout
        self.min_gap = min_gap_s          # ~8 req/s ceiling, well under the limit
        self.cache_ttl = cache_ttl
        self._last = 0.0
        self._lock = threading.Lock()
        self._cache: Dict[str, Tuple[float, Any]] = {}
        self._s = requests.Session()
        self._s.headers.update({"Content-Type": "application/json",
                                "User-Agent": "crypto-radar/1.0"})
        self.enabled = os.environ.get("HYPERLIQUID_ENABLED", "1") not in ("0", "false")
        self.last_error: Optional[str] = None

    def _post(self, body: dict, cache_key: Optional[str] = None) -> Optional[Any]:
        if not self.enabled:
            return None
        if cache_key:
            hit = self._cache.get(cache_key)
            if hit and time.time() - hit[0] < self.cache_ttl:
                return hit[1]
        for attempt in range(3):
            with self._lock:
                gap = time.monotonic() - self._last
                if gap < self.min_gap:
                    time.sleep(self.min_gap - gap)
                self._last = time.monotonic()
            try:
                r = self._s.post(INFO_URL, json=body, timeout=self.timeout)
            except requests.RequestException as e:
                self.last_error = str(e)
                time.sleep(0.5 * (attempt + 1))
                continue
            if r.status_code == 200:
                try:
                    data = r.json()
                except ValueError as e:
                    self.last_error = f"bad JSON: {e}"
                    return None
                self.last_error = None
                if cache_key:
                    self._cache[cache_key] = (time.time(), data)
                    if len(self._cache) > 400:
                        for k, _ in sorted(self._cache.items(),
                                           key=lambda kv: kv[1][0])[:150]:
                            self._cache.pop(k, None)
                return data
            if r.status_code == 429:
                self.last_error = "rate limited"
                time.sleep(2.0 * (attempt + 1))
                continue
            self.last_error = f"HTTP {r.status_code}: {r.text[:120]}"
            log.debug("hyperliquid %s -> %s", body.get("type"), self.last_error)
            return None
        return None

    # ------------------------------------------------------------- market

    def l2_book(self, coin: str) -> Optional[dict]:
        return self._post({"type": "l2Book", "coin": coin}, f"book:{coin}")

    def market_context(self) -> Optional[Tuple[dict, list]]:
        """Every coin's funding, open interest and mark price in one request."""
        data = self._post({"type": "metaAndAssetCtxs"}, "ctx")
        if not isinstance(data, list) or len(data) < 2:
            return None
        return data[0], data[1]

    def clearinghouse_state(self, address: str) -> Optional[dict]:
        return self._post({"type": "clearinghouseState", "user": address},
                          f"chs:{address}")

    def leaderboard(self, limit: int = 40) -> List[str]:
        """Top accounts by PnL, for seeding a watchlist automatically.

        Best-effort. This is the endpoint the Hyperliquid web UI uses rather
        than a documented one, so it is wrapped tightly -- a failure here means
        no watchlist, not a broken scanner.
        """
        hit = self._cache.get("leaderboard")
        if hit and time.time() - hit[0] < 3600:
            return hit[1]
        try:
            r = self._s.get(LEADERBOARD_URL, timeout=self.timeout)
            if r.status_code != 200:
                log.info("hyperliquid leaderboard unavailable (HTTP %s)", r.status_code)
                return []
            data = r.json()
        except Exception as e:                            # noqa: BLE001
            log.info("hyperliquid leaderboard unavailable: %s", e)
            return []

        rows = data.get("leaderboardRows") if isinstance(data, dict) else data
        if not isinstance(rows, list):
            return []
        scored: List[Tuple[float, str]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            addr = row.get("ethAddress") or row.get("user") or row.get("address")
            if not isinstance(addr, str) or not addr.startswith("0x"):
                continue
            try:
                val = float(row.get("accountValue") or 0)
            except (TypeError, ValueError):
                val = 0.0
            scored.append((val, addr))
        scored.sort(key=lambda kv: -kv[0])
        addrs = [a for _, a in scored[:limit]]
        self._cache["leaderboard"] = (time.time(), addrs)
        log.info("hyperliquid leaderboard seeded %d address(es)", len(addrs))
        return addrs


# --------------------------------------------------------------- order book

@dataclass
class BookRead:
    coin: str
    mid: float
    spread_bps: float
    bid_depth_usd: float
    ask_depth_usd: float
    imbalance: float                 # -1 all asks .. +1 all bids
    near_imbalance: float            # same, but only the tightest band
    thin: bool                       # too little depth to read anything into
    note: str = ""

    def vetoes(self, direction: str, threshold: float = 0.35) -> bool:
        """True when the book argues clearly against the trade.

        Deliberately asymmetric with the entry logic: this can stop a trade,
        never start one. Resting size is an intention that can be withdrawn,
        and on a thin book withdrawing it is cheap.
        """
        if self.thin:
            return False
        if direction == "LONG":
            return self.imbalance <= -threshold
        return self.imbalance >= threshold


def read_book(coin: str, raw: dict, band_bps: float = 25.0,
              min_side_usd: float = 25_000) -> Optional[BookRead]:
    """Turn an l2Book response into depth imbalance around the mid."""
    levels = (raw or {}).get("levels")
    if not levels or len(levels) < 2 or not levels[0] or not levels[1]:
        return None
    try:
        bids = [(float(x["px"]), float(x["sz"])) for x in levels[0]]
        asks = [(float(x["px"]), float(x["sz"])) for x in levels[1]]
    except (KeyError, TypeError, ValueError):
        return None
    if not bids or not asks:
        return None

    best_bid, best_ask = bids[0][0], asks[0][0]
    mid = (best_bid + best_ask) / 2
    if mid <= 0:
        return None
    spread_bps = (best_ask - best_bid) / mid * 10_000

    def side_usd(levels_, lo, hi):
        return sum(px * sz for px, sz in levels_ if lo <= px <= hi)

    band = mid * band_bps / 10_000
    bid_usd = side_usd(bids, mid - band, mid)
    ask_usd = side_usd(asks, mid, mid + band)
    near_band = mid * (band_bps / 4) / 10_000
    near_bid = side_usd(bids, mid - near_band, mid)
    near_ask = side_usd(asks, mid, mid + near_band)

    total = bid_usd + ask_usd
    imb = (bid_usd - ask_usd) / total if total > 0 else 0.0
    near_total = near_bid + near_ask
    near_imb = (near_bid - near_ask) / near_total if near_total > 0 else 0.0

    thin = min(bid_usd, ask_usd) < min_side_usd
    note = ""
    if thin:
        note = (f"only ${min(bid_usd, ask_usd):,.0f} resting on the thinner side "
                f"— too little to read")
    return BookRead(coin=coin, mid=mid, spread_bps=round(spread_bps, 2),
                    bid_depth_usd=round(bid_usd, 0), ask_depth_usd=round(ask_usd, 0),
                    imbalance=round(imb, 3), near_imbalance=round(near_imb, 3),
                    thin=thin, note=note)


# ------------------------------------------------------------ whale positions

@dataclass
class WalletPosition:
    address: str
    coin: str
    side: str                        # LONG | SHORT
    notional_usd: float
    size: float
    entry_px: Optional[float] = None
    leverage: Optional[float] = None
    liq_px: Optional[float] = None
    unrealised_pnl: Optional[float] = None

    def short_addr(self) -> str:
        return f"{self.address[:6]}…{self.address[-4:]}" if self.address else "?"


@dataclass
class CoinPositioning:
    coin: str
    long_usd: float = 0.0
    short_usd: float = 0.0
    n_long: int = 0
    n_short: int = 0
    wallets_seen: int = 0
    biggest_long_usd: float = 0.0
    biggest_short_usd: float = 0.0
    positions: List["WalletPosition"] = field(default_factory=list)

    def top(self, n: int = 5) -> List["WalletPosition"]:
        return sorted(self.positions, key=lambda p: -p.notional_usd)[:n]

    @property
    def net_usd(self) -> float:
        return self.long_usd - self.short_usd

    @property
    def skew(self) -> float:
        """-1 (all short) .. +1 (all long), by notional."""
        tot = self.long_usd + self.short_usd
        return (self.long_usd - self.short_usd) / tot if tot > 0 else 0.0

    def lean(self) -> float:
        """0..1 bullishness, for the pump score. Neutral when nothing is held."""
        return float(np.clip((self.skew + 1) / 2, 0.0, 1.0))

    def as_dict(self, n: int = 5) -> dict:
        return {
            "coin": self.coin,
            "long_usd": round(self.long_usd, 0),
            "short_usd": round(self.short_usd, 0),
            "net_usd": round(self.net_usd, 0),
            "skew": round(self.skew, 3),
            "lean": round(self.lean(), 3),
            "n_long": self.n_long, "n_short": self.n_short,
            "wallets_seen": self.wallets_seen,
            "describe": self.describe(),
            "top": [{"address": p.short_addr(), "side": p.side,
                     "notional_usd": p.notional_usd, "size": p.size,
                     "entry_px": p.entry_px, "leverage": p.leverage,
                     "liq_px": p.liq_px, "unrealised_pnl": p.unrealised_pnl}
                    for p in self.top(n)],
        }

    def describe(self) -> str:
        if not self.wallets_seen:
            return "no tracked wallets hold this"
        tot = self.long_usd + self.short_usd
        return (f"{self.n_long} long / {self.n_short} short across "
                f"{self.wallets_seen} tracked wallets, ${tot / 1e6:.1f}M notional, "
                f"net {'long' if self.net_usd > 0 else 'short'} "
                f"${abs(self.net_usd) / 1e6:.1f}M")


class WhaleWatcher:
    """Aggregates open positions across a watchlist of Hyperliquid addresses.

    "Whale" means whoever is on your list. There is no oracle for which wallets
    matter -- seed it from the leaderboard or from addresses you have reason to
    follow, and treat the output as "what these specific accounts are doing",
    not "what smart money is doing".
    """

    def __init__(self, client: HyperliquidClient,
                 addresses: Optional[List[str]] = None, ttl_s: float = 300.0):
        self.cli = client
        env = os.environ.get("HL_WHALE_ADDRESSES", "")
        self.addresses = [a.strip() for a in (addresses or env.split(","))
                          if a.strip().startswith("0x")]
        self.autoseed = os.environ.get("HL_AUTOSEED", "1") not in ("0", "false")
        self.seeded_from = "config" if self.addresses else None
        self.ttl = ttl_s
        self._cache: Tuple[float, Dict[str, CoinPositioning]] = (0.0, {})
        self._lock = threading.Lock()

    @property
    def enabled(self) -> bool:
        return bool(self.cli.enabled and (self.addresses or self.autoseed))

    def _ensure_addresses(self) -> None:
        """Fall back to the public leaderboard when nothing is configured."""
        if self.addresses or not self.autoseed:
            return
        addrs = self.cli.leaderboard()
        if addrs:
            self.addresses = addrs
            self.seeded_from = "leaderboard"

    def positions_by_coin(self) -> Dict[str, CoinPositioning]:
        if not self.cli.enabled:
            return {}
        self._ensure_addresses()
        if not self.addresses:
            return {}
        with self._lock:
            ts, cached = self._cache
            if time.time() - ts < self.ttl and cached:
                return cached

        out: Dict[str, CoinPositioning] = {}
        seen = 0
        for addr in self.addresses[:40]:               # bound the request count
            state = self.cli.clearinghouse_state(addr)
            if not state:
                continue
            seen += 1
            for ap in state.get("assetPositions", []):
                pos = ap.get("position") or {}
                coin = pos.get("coin")
                if not coin:
                    continue
                try:
                    szi = float(pos.get("szi", 0))
                    notional = abs(float(pos.get("positionValue", 0)))
                except (TypeError, ValueError):
                    continue
                if szi == 0 or notional <= 0:
                    continue
                cp = out.setdefault(coin, CoinPositioning(coin=coin))

                def _num(key):
                    try:
                        return float(pos.get(key))
                    except (TypeError, ValueError):
                        return None
                lev = pos.get("leverage") or {}
                wp = WalletPosition(
                    address=addr, coin=coin,
                    side="LONG" if szi > 0 else "SHORT",
                    notional_usd=notional, size=abs(szi),
                    entry_px=_num("entryPx"), liq_px=_num("liquidationPx"),
                    unrealised_pnl=_num("unrealizedPnl"),
                    leverage=(float(lev.get("value")) if isinstance(lev, dict)
                              and lev.get("value") is not None else None))
                cp.positions.append(wp)
                if szi > 0:
                    cp.long_usd += notional
                    cp.n_long += 1
                    cp.biggest_long_usd = max(cp.biggest_long_usd, notional)
                else:
                    cp.short_usd += notional
                    cp.n_short += 1
                    cp.biggest_short_usd = max(cp.biggest_short_usd, notional)
        for cp in out.values():
            cp.wallets_seen = seen

        with self._lock:
            self._cache = (time.time(), out)
        return out

    def for_symbol(self, symbol: str) -> Optional[CoinPositioning]:
        return self.positions_by_coin().get(to_hl_coin(symbol))

    def notable_for(self, symbol: str, min_usd: float = 250_000,
                    limit: int = 6) -> List[dict]:
        """Biggest open positions in this coin, among watched wallets.

        The qualifier matters: this cannot answer "who holds the largest BTC
        position on Hyperliquid". Enumerating every address needs an indexer,
        which the public API does not provide. It answers "of the wallets I
        watch, who holds what" -- useful precisely to the extent your
        watchlist is.
        """
        cp = self.for_symbol(symbol)
        if not cp:
            return []
        return [{
            "wallet": p.short_addr(), "address": p.address, "side": p.side,
            "notional_usd": round(p.notional_usd, 0), "size": p.size,
            "entry": p.entry_px, "leverage": p.leverage,
            "liquidation_px": p.liq_px,
            "unrealised_pnl": (round(p.unrealised_pnl, 0)
                               if p.unrealised_pnl is not None else None),
        } for p in cp.top(limit) if p.notional_usd >= min_usd]


# --------------------------------------------------------------- facade

class Hyperliquid:
    """What the rest of the app talks to."""

    def __init__(self, addresses: Optional[List[str]] = None):
        self.cli = HyperliquidClient()
        self.whales = WhaleWatcher(self.cli, addresses)

    @property
    def enabled(self) -> bool:
        return self.cli.enabled

    def book(self, symbol: str) -> Optional[BookRead]:
        coin = to_hl_coin(symbol)
        raw = self.cli.l2_book(coin)
        if not raw:
            return None
        return read_book(coin, raw)

    def status(self) -> dict:
        return {
            "enabled": self.cli.enabled,
            "whale_addresses": len(self.whales.addresses),
            "whales_enabled": self.whales.enabled,
            "watchlist_source": self.whales.seeded_from,
            "last_error": self.cli.last_error,
            "note": (
                "Order book and positions come straight from Hyperliquid's public "
                "API. Book depth is used only to veto trades, never to justify "
                "them — resting size can be withdrawn the moment it is "
                "approached. Position data covers the wallets on your watchlist "
                "and nobody else."),
        }
