"""
Offline self-test. No network required.

Generates synthetic OHLCV with realistic microstructure, then runs the full
pipeline: features -> score -> setup -> triple-barrier simulation -> metrics
-> ML fit. Run this after any edit; it catches shape errors, lookahead in the
label loop, and NaN propagation before you point the thing at real money.

    python selftest.py
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from radar.backtest import Costs, metrics, run, signals_from_weights, simulate_trades
from radar.features import (add_derivatives, add_funding_series,
                            add_relative_strength, compute_features)
from radar.model import assemble, fit_and_evaluate
from radar.score import DEFAULT_WEIGHTS, build_setup, score_row


def synth(n=3000, seed=0, start="2024-01-01", freq="15min", s0=100.0,
          trend=0.00002, vol=0.004):
    rng = np.random.default_rng(seed)
    idx = pd.date_range(start, periods=n, freq=freq, tz="UTC")
    # regime-switching drift so the data is not a single trend
    regime = np.repeat(rng.choice([-1, 0, 1], size=n // 200 + 1), 200)[:n]
    ret = rng.normal(trend * regime, vol, n)
    close = s0 * np.exp(np.cumsum(ret))
    spread = np.abs(rng.normal(0, vol * 0.8, n)) * close
    high = close + spread * rng.uniform(0.3, 1.0, n)
    low = close - spread * rng.uniform(0.3, 1.0, n)
    open_ = np.concatenate([[s0], close[:-1]])
    high = np.maximum.reduce([high, open_, close])
    low = np.minimum.reduce([low, open_, close])
    vol_base = rng.lognormal(8, 0.6, n) * (1 + 3 * np.abs(ret) / vol)
    taker_buy = vol_base * np.clip(0.5 + ret / (vol * 6), 0.05, 0.95)
    df = pd.DataFrame({
        "open": open_, "high": high, "low": low, "close": close,
        "volume": vol_base, "quote_volume": vol_base * close,
        "trades": (vol_base / 10).astype(int),
        "taker_buy_base": taker_buy,
        "taker_buy_quote": taker_buy * close,
        "close_time": idx + pd.Timedelta(freq),
    }, index=idx)
    df.index.name = "open_time"
    return df


def synth_funding(idx, seed=1):
    rng = np.random.default_rng(seed)
    ft = pd.date_range(idx[0], idx[-1], freq="8h", tz="UTC")
    return pd.Series(rng.normal(0.0001, 0.0003, len(ft)), index=ft)


def _refuses_public_bind():
    """serve() must exit rather than publish market data on a public IP."""
    import radar.api as _a
    saved = _a.AUTH_PASS
    _a.AUTH_PASS = ""
    try:
        _a.serve(host="0.0.0.0", port=8399)
        return False
    except SystemExit:
        return True
    except Exception:                                     # noqa: BLE001
        return False
    finally:
        _a.AUTH_PASS = saved


def check(name, cond, extra=""):
    print(f"  [{'PASS' if cond else 'FAIL'}] {name} {extra}")
    return bool(cond)


def main():
    ok = True
    print("\n1. features")
    df = synth(3000, seed=0)
    btc = synth(3000, seed=42, s0=60000.0)
    f = compute_features(df, bars_per_hour=4)
    bf = compute_features(btc, bars_per_hour=4)
    f = add_relative_strength(f, bf)
    f = add_funding_series(f, synth_funding(df.index))
    oi = pd.Series(np.cumsum(np.random.default_rng(3).normal(0, 1e4, len(df))) + 5e6,
                   index=df.index)
    f = add_derivatives(f, oi, 0.0001, 1.05, 1.12, 4)

    ok &= check("feature frame shape", f.shape[0] == len(df) and f.shape[1] > 45,
                f"-> {f.shape}")
    tail = f.iloc[300:]
    nan_frac = tail.isna().mean().mean()
    ok &= check("NaN fraction after warmup < 10%", nan_frac < 0.10,
                f"-> {nan_frac:.3%}")

    # lookahead probe: features at bar t must not change when future bars change
    df2 = df.copy()
    df2.iloc[2000:, df2.columns.get_loc("close")] *= 1.5
    f1 = compute_features(df, bars_per_hour=4)
    f2 = compute_features(df2, bars_per_hour=4)
    cols = [c for c in f1.columns if f1[c].dtype.kind == "f"]
    same = np.allclose(f1[cols].iloc[1000:1500].fillna(0).values,
                       f2[cols].iloc[1000:1500].fillna(0).values, rtol=1e-9)
    ok &= check("no lookahead (past features unchanged by future bars)", same)

    print("\n2. scoring")
    s = score_row(f.iloc[-1])
    ok &= check("score in range", 0 <= s["long_score"] <= 100, f"-> {s['long_score']}")
    ok &= check("mirror", abs(s["long_score"] + s["short_score"] - 100) < 1e-6)
    ok &= check("blocks present", len(s["blocks"]) == len(DEFAULT_WEIGHTS))
    ok &= check("squeeze scores bounded",
                0 <= s["squeeze"]["short_squeeze_score"] <= 100)
    print(f"     dir={s['direction']} score={s['long_score']} conv={s['conviction']} "
          f"cov={s['coverage']} regime={s['blocks']['open_interest'].get('regime')}")

    print("\n2b. vectorised scoring matches row-wise scoring")
    from radar.score import aggregate, block_frame
    sample = f.dropna(subset=["atr", "close"]).iloc[-400:]
    vals, avail = block_frame(sample)
    agg = aggregate(vals, avail, DEFAULT_WEIGHTS)
    ref = np.array([score_row(sample.iloc[i], DEFAULT_WEIGHTS)["net"]
                    for i in range(len(sample))])
    maxdiff = float(np.nanmax(np.abs(agg["net"].values - ref)))
    ok &= check("net matches row-wise scorer", maxdiff < 1e-9, f"-> max diff {maxdiff:.2e}")
    ref_dir = np.array([score_row(sample.iloc[i], DEFAULT_WEIGHTS)["direction"]
                        for i in range(len(sample))])
    ok &= check("direction matches", bool((agg["direction"].values == ref_dir).all()))

    print("\n3. setup")
    st = build_setup(f.iloc[-1], "LONG", 1.5)
    ok &= check("long setup ordering", st and st.stop < st.entry < st.tp1 < st.tp2 < st.tp3)
    sh = build_setup(f.iloc[-1], "SHORT", 1.5)
    ok &= check("short setup ordering", sh and sh.stop > sh.entry > sh.tp1 > sh.tp2 > sh.tp3)
    ok &= check("risk positive", st.risk_pct > 0, f"-> {st.risk_pct:.2f}%")
    print(f"     entry={st.entry:.4f} stop={st.stop:.4f} tp2={st.tp2:.4f} "
          f"risk={st.risk_pct:.2f}% rating={st.risk_rating}")

    print("\n4. simulation")
    feats = f.dropna(subset=["atr", "close"])
    sig = signals_from_weights(feats, DEFAULT_WEIGHTS, 0.10)
    ok &= check("signals generated", len(sig) > 20, f"-> {len(sig)}")
    tr = simulate_trades(df, feats, sig, synth_funding(df.index),
                         Costs(), max_bars=48, atr_mult=1.5)
    ok &= check("trades generated", len(tr) > 5, f"-> {len(tr)}")
    if len(tr):
        ok &= check("entry always after signal bar",
                    bool((tr["exit_time"] >= tr["entry_time"]).all()))
        ok &= check("costs charged on every trade", bool((tr["cost_pct"] > 0).all()))
        m = metrics(tr)
        print("     ", {k: m[k] for k in ("trades", "win_rate", "avg_r",
                                          "profit_factor", "max_dd_r")})
        # On random-walk data with costs, expectancy should be <= 0.
        ok &= check("no free lunch on synthetic random walk", m["avg_r"] < 0.25,
                    f"-> avg_r {m['avg_r']}")

    print("\n5. multi-symbol run")
    panel = {}
    for i, sym in enumerate(["AAAUSDT", "BBBUSDT", "CCCUSDT"]):
        d = synth(3000, seed=10 + i, s0=10.0 * (i + 1))
        ff = compute_features(d, 4)
        ff = add_relative_strength(ff, bf)
        fr = synth_funding(d.index, seed=i)
        ff = add_funding_series(ff, fr)
        for c in ["oi", "oi_chg_1h", "oi_chg_4h", "oi_z_24h",
                  "taker_ls_ratio", "top_pos_ls_ratio"]:
            ff[c] = np.nan
        panel[sym] = {"df": d, "feats": ff.dropna(subset=["atr", "close"]), "funding": fr}
    trades = run(panel, DEFAULT_WEIGHTS, 0.12, Costs(), 48, 1.5)
    ok &= check("pooled trades", len(trades) > 10, f"-> {len(trades)}")
    print("     ", metrics(trades))

    print("\n6. ML labelling + purged CV")
    data = assemble(panel, "LONG", 1.5, 2.0, 48)
    ok &= check("label balance sane", 0.05 < data["y"].mean() < 0.95,
                f"-> base rate {data['y'].mean():.3f}")
    try:
        _, rep = fit_and_evaluate(data, max_bars=48, bar_ms=900_000, n_splits=3)
        print("     ", {k: rep[k] for k in ("n_samples", "base_rate",
                                            "cv_auc_mean", "cv_brier")})
        ok &= check("AUC computed", rep["cv_auc_mean"] is not None)
        ok &= check("brier beats or matches base rate on noise",
                    rep["cv_brier"] <= rep["brier_of_always_base_rate"] * 1.15,
                    f"-> {rep['cv_brier']} vs {rep['brier_of_always_base_rate']}")
    except Exception as e:                                 # noqa: BLE001
        ok = check(f"ML fit ({e})", False)

    print("\n7. arkham on-chain overlay (offline, mocked responses)")
    import tempfile, os as _os
    from radar.store import Store
    from radar.score import setup_dict
    from radar.onchain import ArkhamClient, Transfer, WhaleTracker, _parse_transfer

    raw = {
        "transactionHash": "0xabc", "blockTimestamp": "2026-07-27T04:00:00Z",
        "tokenSymbol": "sol", "historicalUSD": 8_400_000, "unitValueUsd": 1,
        "chain": "solana",
        "fromAddress": {"address": "Whale111", "chain": "solana"},
        "toAddress": {"address": "Bin222", "chain": "solana",
                      "arkhamEntity": {"id": "binance", "name": "Binance", "type": "cex"}},
    }
    t = _parse_transfer(raw)
    ok &= check("parses transfer", t is not None and t.token == "SOL")
    ok &= check("uses historicalUSD not unitValueUsd", t.usd == 8_400_000)
    ok &= check("classifies deposit as exchange_in", t.direction() == "exchange_in")

    out = _parse_transfer({**raw,
        "fromAddress": {"address": "Bin222", "arkhamEntity":
                        {"id": "binance", "name": "Binance", "type": "cex"}},
        "toAddress": {"address": "Whale111"}})
    ok &= check("classifies withdrawal as exchange_out", out.direction() == "exchange_out")
    both = _parse_transfer({**raw,
        "fromAddress": {"address": "A", "arkhamEntity": {"id": "okx", "type": "cex"}},
        "toAddress": {"address": "B", "arkhamEntity": {"id": "binance", "type": "cex"}}})
    ok &= check("exchange-to-exchange treated as internal plumbing",
                both.direction() == "exchange_internal")

    class FakeArkham(ArkhamClient):
        def __init__(self, transfers): self.key = "test"; self._t = transfers
        @property
        def enabled(self): return True
        def transfers(self, **kw): return self._t
        def address_last_activity_ms(self, address, chain=None):
            return 1 if address == "Dormant999" else t.ts_ms - 86_400_000

    dormant = _parse_transfer({**raw, "transactionHash": "0xdead",
                               "fromAddress": {"address": "Dormant999"},
                               "historicalUSD": 12_000_000})
    recent = _parse_transfer({**raw, "transactionHash": "0xfeed",
                              "fromAddress": {"address": "Active888"},
                              "historicalUSD": 9_000_000})
    dbp2 = _os.path.join(tempfile.mkdtemp(), "w.db")
    st2 = Store(dbp2)
    wt = WhaleTracker(FakeArkham([t, out, dormant, recent]), store=st2,
                      dormancy_min_usd=5_000_000)
    ctx = wt.sweep(["SOLUSDT", "BTCUSDT"])
    c = ctx.get("SOLUSDT")
    ok &= check("maps token symbol to Binance pair", c is not None)
    ok &= check("nets exchange flow",
                abs(c.net_to_exchange - (8.4e6 + 12e6 + 9e6 - 8.4e6)) < 1,
                f"-> {c.net_to_exchange:,.0f}")
    ok &= check("detects dormant wallet wake", len(c.dormant_wakes) == 1,
                f"-> {c.dormant_wakes}")
    ok &= check("ignores recently-active wallet",
                not any("Active888" in w for w in c.dormant_wakes))
    ok &= check("caution flags against LONG on net inflow", c.caution_for("LONG"))
    ok &= check("no caution against SHORT on net inflow", not c.caution_for("SHORT"))
    ok &= check("transfers persisted for later backtesting",
                len(st2.transfers_df(symbol="SOLUSDT")) == 4,
                f"-> {len(st2.transfers_df(symbol='SOLUSDT'))} rows")

    st2.close()

    print("\n8. web layer (real HTTP server, no network)")
    import json as _json, threading as _th, time
    import urllib.request as _u, urllib.error as _ue
    _os.environ.setdefault("RADAR_DB", _os.path.join(tempfile.mkdtemp(), "api.db"))
    import radar.api as _api
    from http.server import ThreadingHTTPServer

    row = f.iloc[-1]
    b = _json.loads(_json.dumps(score_row(row)["blocks"], default=float))
    _api.svc.latest = {
        "generated_at": int(time.time() * 1000), "interval": "15m",
        "universe_size": 150, "derivatives_covered": 60, "elapsed_s": 41.2,
        "used_weight_1m": 352, "whale_events": [],
        "candidates": [{"symbol": "SOLUSDT", "price": float(row["close"]),
                        "direction": "LONG", "long_score": 71.3, "short_score": 28.7,
                        "conviction": 0.42, "agreement": 0.86, "coverage": 1.0,
                        "net": 0.42, "regime": "new longs", "funding": 0.0001,
                        "atr_pct": 0.009, "short_squeeze_score": 63.0,
                        "long_squeeze_score": 12.0,
                        "setup": setup_dict(build_setup(row, "LONG", 1.5)),
                        "blocks": b, "whale": None}]}
    _api.svc.status.update(state="ok",
                           last_ok_ms=_api.svc.latest["generated_at"], cycles=1)
    srv = ThreadingHTTPServer(("127.0.0.1", 8231), _api.Handler)
    srv.daemon_threads = True
    _th.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.4)

    def _get(path):
        try:
            with _u.urlopen("http://127.0.0.1:8231" + path) as r:
                return r.status, r.read().decode()
        except _ue.HTTPError as e:
            return e.code, e.read().decode()

    ok &= check("refuses to bind a public interface without a password",
                _refuses_public_bind())

    for path, exp in [("/", 200), ("/api/latest", 200), ("/api/symbol/SOLUSDT", 200),
                      ("/api/symbol/NOPEUSDT", 404), ("/api/whales", 200),
                      ("/api/history", 200), ("/nope", 404)]:
        code, _ = _get(path)
        ok &= check(f"GET {path}", code == exp, f"-> {code}")

    code, body = _get("/healthz")
    ok &= check("healthz reports fresh", code == 200 and not _json.loads(body)["stale"])
    _api.svc.status["last_ok_ms"] = int(time.time() * 1000) - 3_600_000
    code, body = _get("/healthz")
    ok &= check("healthz 503s when the scan loop stalls",
                code == 503 and _json.loads(body)["stale"], f"-> {code}")

    # --- auth
    _api.AUTH_PASS = "s3cret"
    code, _ = _get("/api/latest")
    ok &= check("401 without credentials once a password is set", code == 401, f"-> {code}")
    code, _ = _get("/healthz")
    ok &= check("healthz stays open for uptime monitors", code in (200, 503), f"-> {code}")

    import base64 as _b64
    def _get_auth(path, user="radar", pw="s3cret"):
        req = _u.Request("http://127.0.0.1:8231" + path)
        tok = _b64.b64encode(f"{user}:{pw}".encode()).decode()
        req.add_header("Authorization", "Basic " + tok)
        try:
            with _u.urlopen(req) as r:
                return r.status, r.read().decode()
        except _ue.HTTPError as e:
            return e.code, e.read().decode()

    code, _ = _get_auth("/api/latest")
    ok &= check("200 with correct credentials", code == 200, f"-> {code}")
    code, _ = _get_auth("/api/latest", pw="wrong")
    ok &= check("401 with wrong password", code == 401, f"-> {code}")
    code, _ = _get_auth("/api/latest", user="nope")
    ok &= check("401 with wrong user", code == 401, f"-> {code}")
    _api.AUTH_PASS = ""

    # --- strict JSON: browsers reject NaN/Infinity even though Python accepts them
    def _strict(txt):
        def boom(tok):
            raise ValueError(f"non-JSON token {tok!r} in response")
        return _json.loads(txt, parse_constant=boom)

    for path in ("/api/latest", "/api/symbol/SOLUSDT", "/api/whales", "/healthz"):
        code, body = _get(path)
        try:
            _strict(body)
            ok &= check(f"{path} is strictly valid JSON", True)
        except ValueError as e:
            ok &= check(f"{path} is strictly valid JSON", False, f"-> {e}")

    _, page = _get("/")
    ok &= check("dashboard renders with no external JS",
                "CONVICTION" in page and "<script" in page and "src=" not in page.split("<script")[1][:200])
    srv.shutdown()

    print("\n9. multi-timeframe analysis (offline)")
    from radar.analyze import (TIMEFRAMES, analyse_timeframe, narrate,
                               support_resistance)
    from radar.features import atr as _atr

    d = synth(600, seed=5)
    lv = support_resistance(d, _atr(d, 14))
    px = float(d["close"].iloc[-1])
    ok &= check("finds support/resistance levels", len(lv) > 0, f"-> {len(lv)}")
    ok &= check("levels sit on the correct side of price",
                all((x.price < px) == (x.kind == "support") for x in lv))
    ok &= check("strength bounded 0..1", all(0 <= x.strength <= 1 for x in lv))

    per = {}
    for tf in TIMEFRAMES:
        try:
            per[tf] = analyse_timeframe(synth(400, seed=abs(hash(tf)) % 997),
                                        tf, None, None, None)
        except Exception as e:                            # noqa: BLE001
            ok &= check(f"timeframe {tf}", False, f"-> {type(e).__name__}: {e}")
    ok &= check("every timeframe analyses cleanly", len(per) == len(TIMEFRAMES),
                f"-> {len(per)}/{len(TIMEFRAMES)}")
    ok &= check("bias always one of three values",
                all(p["bias"] in ("bullish", "bearish", "neutral") for p in per.values()))

    short = analyse_timeframe(synth(120, seed=3), "1M", None, None, None)
    ok &= check("EMA200 declared unavailable rather than faked",
                short["ema200"]["available"] is False and short["ema200"]["note"])

    nar = narrate("SOLUSDT", per, {"funding_rate": 0.0001, "oi_change_24h_pct": 4.2})
    ok &= check("narrative generated", len(nar["text"]) > 200, f"-> {len(nar['text'])} chars")
    ok &= check("verdict classified", nar["verdict"] in (
        "aligned_bullish", "aligned_bearish", "pullback_in_uptrend",
        "bounce_in_downtrend", "mixed"))

    print("\n10. challenge / paper trading (offline)")
    from radar.challenge import Challenge, RiskConfig

    class _Cli:
        def __init__(self): self.bars = {}
        def klines(self, sym, interval="1m", limit=500, **kw):
            return self.bars.get(sym, [])
        def funding_rate_history(self, *a, **k):
            return [{"fundingRate": "0.0001"}]

    def _bars(start_ms, rows):
        return [[start_ms + (i + 1) * 60000, str(o), str(h), str(l), str(cl), "10",
                 start_ms + (i + 1) * 60000 + 59999, "1000", 5, "5", "500", "0"]
                for i, (o, h, l, cl) in enumerate(rows)]

    cdb = _os.path.join(tempfile.mkdtemp(), "ch.db")
    cst = Store(cdb)
    cli = _Cli()
    cfg = RiskConfig(starting_equity=10000, risk_per_trade_pct=1.0,
                     cooldown_minutes_after_loss=0)
    ch = Challenge(cli, cst, cfg)
    t0 = int(time.time() * 1000) - 7200_000
    cand = {"symbol": "BTCUSDT", "direction": "LONG", "conviction": 0.42,
            "setup": {"entry": 100000.0, "stop": 99000.0}}

    pos = ch.maybe_open(cand, t0)
    ok &= check("opens a paper position", pos is not None)
    ok &= check("risks exactly 1% of equity", abs(pos.risk_amount - 100.0) < 1.0,
                f"-> ${pos.risk_amount:.2f}")
    ok &= check("size derived from stop distance, not chosen first",
                abs(pos.qty * pos.r_per_unit - pos.risk_amount) < 0.01)
    ok &= check("fill is worse than the signal price", pos.entry > 100000.0)
    ok &= check("rejects a second position in the same symbol",
                not ch.can_open("BTCUSDT", t0)[0])
    ok &= check("rejects symbols outside BTC/ETH",
                not ch.can_open("SOLUSDT", t0)[0])

    rr = pos.r_per_unit
    cli.bars["BTCUSDT"] = _bars(t0, [
        (pos.entry, pos.entry + rr * 1.05, pos.entry - rr * 0.2, pos.entry + rr),
        (pos.entry + rr, pos.entry + rr * 0.5, pos.entry - 0.01, pos.entry)])
    done = ch.manage(t0 + 300000)
    ok &= check("partial at 1R then breakeven stop", len(done) == 1,
                f"-> {[d.outcome for d in done]}")
    ok &= check("breakeven exit nets positive after the partial", done[0].net_pnl > 0,
                f"-> ${done[0].net_pnl:.2f}")
    ok &= check("fees and funding charged",
                done[0].fees > 0 and abs(done[0].funding) > 0)

    ch.blocked_until_ms = 0
    p2 = ch.maybe_open(cand, t0 + 600000)
    r2 = p2.r_per_unit
    cli.bars["BTCUSDT"] = _bars(t0 + 600000,
                                [(p2.entry, p2.entry + r2 * 3, p2.stop - 1, p2.entry)])
    d2 = ch.manage(t0 + 900000)
    ok &= check("bar covering both barriers scores as the stop",
                d2 and d2[0].outcome == "stop", f"-> {d2[0].outcome}")
    ok &= check("cooldown engages after a loss", ch.blocked_until_ms > 0)

    # Day so far: +0.45R then -1.05R. Still inside the -2R limit, so trading
    # must continue -- a limit that fires early is as wrong as one that never does.
    ch.blocked_until_ms = 0
    day = ch._today_stats()["realised_r"]
    allowed, why = ch.can_open("BTCUSDT", int(time.time() * 1000))
    ok &= check("still trading while inside the daily limit",
                allowed and day > -cfg.daily_loss_limit_r, f"-> day {day:+.2f}R")

    # now push it past the limit and confirm it stops
    p3 = ch.maybe_open(cand, t0 + 1_200_000)
    r3 = p3.r_per_unit
    cli.bars["BTCUSDT"] = _bars(t0 + 1_200_000,
                                [(p3.entry, p3.entry + r3 * .2, p3.stop - 1, p3.stop)])
    ch.manage(t0 + 1_500_000)
    ch.blocked_until_ms = 0
    day = ch._today_stats()["realised_r"]
    # Tighten the limit to just above where the day actually sits, so the
    # boundary itself is under test rather than the size of the losses.
    ch.cfg.daily_loss_limit_r = abs(day) - 0.1
    allowed, why = ch.can_open("BTCUSDT", int(time.time() * 1000))
    ok &= check("daily loss limit halts trading once crossed", not allowed,
                f"-> day {day:+.2f}R vs limit -{ch.cfg.daily_loss_limit_r:.2f}R, {why}")
    ch.cfg.daily_loss_limit_r = cfg.daily_loss_limit_r

    snap = ch.snapshot({"BTCUSDT": 100500.0})
    ok &= check("stats and equity curve produced",
                snap["trades_total"] == 3 and len(snap["equity_curve"]) == 3,
                f"-> {snap['trades_total']} trades")
    ok &= check("small sample is flagged, not glossed over",
                any(w in snap["confidence_note"].lower() for w in ("too few", "noise")))
    ch2 = Challenge(_Cli(), Store(cdb), cfg)
    ok &= check("state survives a restart", abs(ch2.equity - ch.equity) < 0.01)
    cst.close()

    print("\n11. signal track record + on-chain feed (offline)")
    from radar.track import replay
    from radar.news import build_feed

    rep = replay(synth(1200, seed=7), "15m", min_conviction=0.12, want=10)
    ok &= check("replays past signals", len(rep["signals"]) > 0, f"-> {len(rep['signals'])}")
    ok &= check("returns at most the requested count", len(rep["signals"]) <= 10)
    stt = rep["stats"]
    ok &= check("TP1+ hit rate computed", stt["tp1_or_better_pct"] is not None,
                f"-> TP1+ {stt['tp1_or_better_pct']}%, TP2+ {stt['tp2_or_better_pct']}%")
    ok &= check("TP2+ can never exceed TP1+",
                stt["tp2_or_better_pct"] <= stt["tp1_or_better_pct"])
    ok &= check("TP3 can never exceed TP2+", stt["tp3_pct"] <= stt["tp2_or_better_pct"])
    ok &= check("unresolved signals excluded from the hit rate",
                stt["resolved"] + stt["unresolved"] == len(rep["signals"]))
    ok &= check("newest signal listed first",
                rep["signals"][0]["time"] >= rep["signals"][-1]["time"])

    rr = [replay(synth(1200, seed=200 + i), "15m", min_conviction=0.12)["stats"]["avg_r"]
          for i in range(5)]
    rr = [x for x in rr if x is not None]
    ok &= check("no free lunch replaying random walks",
                float(np.mean(rr)) < 0.35, f"-> {np.mean(rr):+.2f}R")

    ndb = Store(_os.path.join(tempfile.mkdtemp(), "news.db"))
    tnow = int(time.time() * 1000)
    for row in [("0xa", tnow - 3.6e6, "SOLUSDT", "SOL", 12e6, "exchange_in",
                 None, "Binance", "W1", "B1"),
                ("0xb", tnow - 7.2e6, "SOLUSDT", "SOL", 3e6, "exchange_out",
                 "Binance", None, "B1", "W2")]:
        ndb.record_transfer(row[0], int(row[1]), *row[2:])
    feed = build_feed(ndb, hours=24, min_usd=1e6, enabled=True)
    ok &= check("flow feed groups by coin", len(feed["by_symbol"]) == 1)
    sol = feed["by_symbol"][0]
    ok &= check("net exchange flow computed", sol["net_to_exchange_usd"] == 9e6,
                f"-> {sol['net_to_exchange_usd']:,.0f}")
    ok &= check("interpretation hedges rather than overclaims",
                "not the same as" in sol["text"])
    ok &= check("flow states it is kept out of the score",
                "cannot be backtested" in feed["note"])
    paused = build_feed(ndb, hours=24, min_usd=1e6, enabled=False)
    ok &= check("recorded data still shown when collection is paused",
                len(paused["by_symbol"]) == 1 and paused["collecting"] is False)
    ndb.close()

    print("\n12. pump candidates + track record (offline)")
    from radar.pump import (build_watchlist, record_calls, score_pump,
                            track_record)

    def _prow(sq, oi4, ret4, volz, fz, tls, rs4, rs24, liq):
        return pd.Series({"close": 100.0, "bb_squeeze_pctile": sq,
                          "atr_expansion": 0.8, "oi_chg_4h": oi4, "ret_4h": ret4,
                          "vol_z": volz, "cvd_slope_4h": 0.05, "funding_z_7d": fz,
                          "funding": fz * 1e-4, "taker_ls_ratio": tls,
                          "rs_4h": rs4, "rs_24h": rs24, "liq_up_dist": liq,
                          "vwap_dist": 0.004})

    coiled_flat = score_pump(_prow(0.02, .05, .001, 2.5, 0.0, 1.0, 0.0, 0.0, 0.0))
    coiled_up = score_pump(_prow(0.02, .05, .001, 2.5, -2.5, 1.35, .03, -.04, .09))
    loose_up = score_pump(_prow(0.95, 0.0, .04, 0.0, -2.5, 1.35, .03, -.04, .09))

    ok &= check("energy is direction-blind",
                abs(coiled_flat["energy"] - coiled_up["energy"]) < 1.0,
                f"-> {coiled_flat['energy']} vs {coiled_up['energy']}")
    ok &= check("compression without direction scores near zero",
                coiled_flat["pump_score"] < 20, f"-> {coiled_flat['pump_score']}")
    ok &= check("same energy plus lean scores far higher",
                coiled_up["pump_score"] > 3 * coiled_flat["pump_score"],
                f"-> {coiled_up['pump_score']} vs {coiled_flat['pump_score']}")
    ok &= check("lean without compression scores lower than both",
                loose_up["pump_score"] < coiled_up["pump_score"])
    ok &= check("liquidation cluster labelled as modelled, not a feed",
                "not a liquidation feed" in
                coiled_up["estimated_liq_cluster"]["basis"])
    ok &= check("caveat states compression is directionless",
                "not direction" in coiled_up["caveat"])

    pdb = Store(_os.path.join(tempfile.mkdtemp(), "pump.db"))
    wl = build_watchlist({"AAAUSDT": _prow(0.02, .05, .001, 2.5, -2.5, 1.35,
                                           .03, -.04, .09)}, min_score=0.0)
    pnow = int(time.time() * 1000)
    ok &= check("calls recorded before the outcome exists",
                record_calls(pdb, wl, pnow) == 1)
    ok &= check("no duplicate call inside the recall window",
                record_calls(pdb, wl, pnow + 3_600_000) == 0)
    rec0 = track_record(pdb)
    ok &= check("claims nothing before calls mature",
                rec0["resolved"] == 0 and "nothing here means anything" in rec0["verdict"])

    for i in range(20):
        pdb.record_pump_call({"ts": pnow - 300 * 3600_000 + i * 1000,
                              "symbol": f"Z{i}USDT", "price_at_call": 100,
                              "pump_score": 55, "energy": 70, "lean": 50,
                              "target_pct": 15.0, "horizon_ms": 168 * 3600_000,
                              "reasons": "t"})
        pdb.resolve_pump_call(pnow - 300 * 3600_000 + i * 1000, f"Z{i}USDT",
                              {"resolved_ms": pnow,
                               "max_gain_pct": 21.0 if i < 5 else 6.0,
                               "max_drawdown_pct": -9.0, "hours_to_peak": 40,
                               "final_pct": 8.0, "hit": 1 if i < 5 else 0,
                               "base_rate_pct": 24.0})
    rec = track_record(pdb)
    ok &= check("hit rate and base rate both reported",
                rec["hit_rate_pct"] == 25.0 and rec["base_rate_pct"] == 24.0,
                f"-> {rec['hit_rate_pct']}% vs {rec['base_rate_pct']}%")
    ok &= check("a screen matching the base rate is called out as useless",
                "not adding information" in rec["verdict"] or
                "worse than random" in rec["verdict"],
                f"-> edge {rec['edge_vs_base_rate']:+}")
    pdb.close()

    print(f"\n{'ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED'}\n")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
