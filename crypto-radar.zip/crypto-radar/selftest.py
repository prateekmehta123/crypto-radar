"""
Offline self-test. No network required.

Generates synthetic OHLCV with realistic microstructure, then runs the full
pipeline: features -> score -> setup -> triple-barrier simulation -> metrics
-> ML fit. Run this after any edit; it catches shape errors, lookahead in the
label loop, and NaN propagation before you point the thing at real money.

    python selftest.py
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from radar.backtest import Costs, metrics, run, signals_from_weights, simulate_trades
from radar.features import (add_derivatives, add_funding_series,
                            add_relative_strength, compute_features)
from radar.model import assemble, fit_and_evaluate
from radar.score import DEFAULT_WEIGHTS, build_setup, score_row


def synth(n=3000, seed=0, start="2024-01-01", freq="15min", s0=100.0,
          trend=0.00002, vol=0.004):
    rng = np.random.default_rng(seed)
    idx = pd.date_range(start, periods=n, freq=freq, tz="UTC")
    # regime-switching drift so the data is not a single trend
    regime = np.repeat(rng.choice([-1, 0, 1], size=n // 200 + 1), 200)[:n]
    ret = rng.normal(trend * regime, vol, n)
    close = s0 * np.exp(np.cumsum(ret))
    spread = np.abs(rng.normal(0, vol * 0.8, n)) * close
    high = close + spread * rng.uniform(0.3, 1.0, n)
    low = close - spread * rng.uniform(0.3, 1.0, n)
    open_ = np.concatenate([[s0], close[:-1]])
    high = np.maximum.reduce([high, open_, close])
    low = np.minimum.reduce([low, open_, close])
    vol_base = rng.lognormal(8, 0.6, n) * (1 + 3 * np.abs(ret) / vol)
    taker_buy = vol_base * np.clip(0.5 + ret / (vol * 6), 0.05, 0.95)
    df = pd.DataFrame({
        "open": open_, "high": high, "low": low, "close": close,
        "volume": vol_base, "quote_volume": vol_base * close,
        "trades": (vol_base / 10).astype(int),
        "taker_buy_base": taker_buy,
        "taker_buy_quote": taker_buy * close,
        "close_time": idx + pd.Timedelta(freq),
    }, index=idx)
    df.index.name = "open_time"
    return df


def synth_funding(idx, seed=1):
    rng = np.random.default_rng(seed)
    ft = pd.date_range(idx[0], idx[-1], freq="8h", tz="UTC")
    return pd.Series(rng.normal(0.0001, 0.0003, len(ft)), index=ft)


def _refuses_public_bind():
    """serve() must exit rather than publish market data on a public IP."""
    import radar.api as _a
    saved = _a.AUTH_PASS
    _a.AUTH_PASS = ""
    try:
        _a.serve(host="0.0.0.0", port=8399)
        return False
    except SystemExit:
        return True
    except Exception:                                     # noqa: BLE001
        return False
    finally:
        _a.AUTH_PASS = saved


def check(name, cond, extra=""):
    print(f"  [{'PASS' if cond else 'FAIL'}] {name} {extra}")
    return bool(cond)


def main():
    ok = True
    print("\n1. features")
    df = synth(3000, seed=0)
    btc = synth(3000, seed=42, s0=60000.0)
    f = compute_features(df, bars_per_hour=4)
    bf = compute_features(btc, bars_per_hour=4)
    f = add_relative_strength(f, bf)
    f = add_funding_series(f, synth_funding(df.index))
    oi = pd.Series(np.cumsum(np.random.default_rng(3).normal(0, 1e4, len(df))) + 5e6,
                   index=df.index)
    f = add_derivatives(f, oi, 0.0001, 1.05, 1.12, 4)

    ok &= check("feature frame shape", f.shape[0] == len(df) and f.shape[1] > 45,
                f"-> {f.shape}")
    tail = f.iloc[300:]
    nan_frac = tail.isna().mean().mean()
    ok &= check("NaN fraction after warmup < 10%", nan_frac < 0.10,
                f"-> {nan_frac:.3%}")

    # lookahead probe: features at bar t must not change when future bars change
    df2 = df.copy()
    df2.iloc[2000:, df2.columns.get_loc("close")] *= 1.5
    f1 = compute_features(df, bars_per_hour=4)
    f2 = compute_features(df2, bars_per_hour=4)
    cols = [c for c in f1.columns if f1[c].dtype.kind == "f"]
    same = np.allclose(f1[cols].iloc[1000:1500].fillna(0).values,
                       f2[cols].iloc[1000:1500].fillna(0).values, rtol=1e-9)
    ok &= check("no lookahead (past features unchanged by future bars)", same)

    print("\n2. scoring")
    s = score_row(f.iloc[-1])
    ok &= check("score in range", 0 <= s["long_score"] <= 100, f"-> {s['long_score']}")
    ok &= check("mirror", abs(s["long_score"] + s["short_score"] - 100) < 1e-6)
    ok &= check("blocks present", len(s["blocks"]) == len(DEFAULT_WEIGHTS))
    ok &= check("squeeze scores bounded",
                0 <= s["squeeze"]["short_squeeze_score"] <= 100)
    print(f"     dir={s['direction']} score={s['long_score']} conv={s['conviction']} "
          f"cov={s['coverage']} regime={s['blocks']['open_interest'].get('regime')}")

    print("\n2b. vectorised scoring matches row-wise scoring")
    from radar.score import aggregate, block_frame
    sample = f.dropna(subset=["atr", "close"]).iloc[-400:]
    vals, avail = block_frame(sample)
    agg = aggregate(vals, avail, DEFAULT_WEIGHTS)
    ref = np.array([score_row(sample.iloc[i], DEFAULT_WEIGHTS)["net"]
                    for i in range(len(sample))])
    maxdiff = float(np.nanmax(np.abs(agg["net"].values - ref)))
    ok &= check("net matches row-wise scorer", maxdiff < 1e-9, f"-> max diff {maxdiff:.2e}")
    ref_dir = np.array([score_row(sample.iloc[i], DEFAULT_WEIGHTS)["direction"]
                        for i in range(len(sample))])
    ok &= check("direction matches", bool((agg["direction"].values == ref_dir).all()))

    print("\n3. setup")
    st = build_setup(f.iloc[-1], "LONG", 1.5)
    ok &= check("long setup ordering", st and st.stop < st.entry < st.tp1 < st.tp2 < st.tp3)
    sh = build_setup(f.iloc[-1], "SHORT", 1.5)
    ok &= check("short setup ordering", sh and sh.stop > sh.entry > sh.tp1 > sh.tp2 > sh.tp3)
    ok &= check("risk positive", st.risk_pct > 0, f"-> {st.risk_pct:.2f}%")
    print(f"     entry={st.entry:.4f} stop={st.stop:.4f} tp2={st.tp2:.4f} "
          f"risk={st.risk_pct:.2f}% rating={st.risk_rating}")

    print("\n4. simulation")
    feats = f.dropna(subset=["atr", "close"])
    sig = signals_from_weights(feats, DEFAULT_WEIGHTS, 0.10)
    ok &= check("signals generated", len(sig) > 20, f"-> {len(sig)}")
    tr = simulate_trades(df, feats, sig, synth_funding(df.index),
                         Costs(), max_bars=48, atr_mult=1.5)
    ok &= check("trades generated", len(tr) > 5, f"-> {len(tr)}")
    if len(tr):
        ok &= check("entry always after signal bar",
                    bool((tr["exit_time"] >= tr["entry_time"]).all()))
        ok &= check("costs charged on every trade", bool((tr["cost_pct"] > 0).all()))
        m = metrics(tr)
        print("     ", {k: m[k] for k in ("trades", "win_rate", "avg_r",
                                          "profit_factor", "max_dd_r")})
        # On random-walk data with costs, expectancy should be <= 0.
        ok &= check("no free lunch on synthetic random walk", m["avg_r"] < 0.25,
                    f"-> avg_r {m['avg_r']}")

    print("\n5. multi-symbol run")
    panel = {}
    for i, sym in enumerate(["AAAUSDT", "BBBUSDT", "CCCUSDT"]):
        d = synth(3000, seed=10 + i, s0=10.0 * (i + 1))
        ff = compute_features(d, 4)
        ff = add_relative_strength(ff, bf)
        fr = synth_funding(d.index, seed=i)
        ff = add_funding_series(ff, fr)
        for c in ["oi", "oi_chg_1h", "oi_chg_4h", "oi_z_24h",
                  "taker_ls_ratio", "top_pos_ls_ratio"]:
            ff[c] = np.nan
        panel[sym] = {"df": d, "feats": ff.dropna(subset=["atr", "close"]), "funding": fr}
    trades = run(panel, DEFAULT_WEIGHTS, 0.12, Costs(), 48, 1.5)
    ok &= check("pooled trades", len(trades) > 10, f"-> {len(trades)}")
    print("     ", metrics(trades))

    print("\n6. ML labelling + purged CV")
    data = assemble(panel, "LONG", 1.5, 2.0, 48)
    ok &= check("label balance sane", 0.05 < data["y"].mean() < 0.95,
                f"-> base rate {data['y'].mean():.3f}")
    try:
        _, rep = fit_and_evaluate(data, max_bars=48, bar_ms=900_000, n_splits=3)
        print("     ", {k: rep[k] for k in ("n_samples", "base_rate",
                                            "cv_auc_mean", "cv_brier")})
        ok &= check("AUC computed", rep["cv_auc_mean"] is not None)
        ok &= check("brier beats or matches base rate on noise",
                    rep["cv_brier"] <= rep["brier_of_always_base_rate"] * 1.15,
                    f"-> {rep['cv_brier']} vs {rep['brier_of_always_base_rate']}")
    except Exception as e:                                 # noqa: BLE001
        ok = check(f"ML fit ({e})", False)

    print("\n7. arkham on-chain overlay (offline, mocked responses)")
    import tempfile, os as _os
    from radar.store import Store
    from radar.score import setup_dict
    from radar.onchain import ArkhamClient, Transfer, WhaleTracker, _parse_transfer

    raw = {
        "transactionHash": "0xabc", "blockTimestamp": "2026-07-27T04:00:00Z",
        "tokenSymbol": "sol", "historicalUSD": 8_400_000, "unitValueUsd": 1,
        "chain": "solana",
        "fromAddress": {"address": "Whale111", "chain": "solana"},
        "toAddress": {"address": "Bin222", "chain": "solana",
                      "arkhamEntity": {"id": "binance", "name": "Binance", "type": "cex"}},
    }
    t = _parse_transfer(raw)
    ok &= check("parses transfer", t is not None and t.token == "SOL")
    ok &= check("uses historicalUSD not unitValueUsd", t.usd == 8_400_000)
    ok &= check("classifies deposit as exchange_in", t.direction() == "exchange_in")

    out = _parse_transfer({**raw,
        "fromAddress": {"address": "Bin222", "arkhamEntity":
                        {"id": "binance", "name": "Binance", "type": "cex"}},
        "toAddress": {"address": "Whale111"}})
    ok &= check("classifies withdrawal as exchange_out", out.direction() == "exchange_out")
    both = _parse_transfer({**raw,
        "fromAddress": {"address": "A", "arkhamEntity": {"id": "okx", "type": "cex"}},
        "toAddress": {"address": "B", "arkhamEntity": {"id": "binance", "type": "cex"}}})
    ok &= check("exchange-to-exchange treated as internal plumbing",
                both.direction() == "exchange_internal")

    class FakeArkham(ArkhamClient):
        def __init__(self, transfers): self.key = "test"; self._t = transfers
        @property
        def enabled(self): return True
        def transfers(self, **kw): return self._t
        def address_last_activity_ms(self, address, chain=None):
            return 1 if address == "Dormant999" else t.ts_ms - 86_400_000

    dormant = _parse_transfer({**raw, "transactionHash": "0xdead",
                               "fromAddress": {"address": "Dormant999"},
                               "historicalUSD": 12_000_000})
    recent = _parse_transfer({**raw, "transactionHash": "0xfeed",
                              "fromAddress": {"address": "Active888"},
                              "historicalUSD": 9_000_000})
    dbp2 = _os.path.join(tempfile.mkdtemp(), "w.db")
    st2 = Store(dbp2)
    wt = WhaleTracker(FakeArkham([t, out, dormant, recent]), store=st2,
                      dormancy_min_usd=5_000_000)
    ctx = wt.sweep(["SOLUSDT", "BTCUSDT"])
    c = ctx.get("SOLUSDT")
    ok &= check("maps token symbol to Binance pair", c is not None)
    ok &= check("nets exchange flow",
                abs(c.net_to_exchange - (8.4e6 + 12e6 + 9e6 - 8.4e6)) < 1,
                f"-> {c.net_to_exchange:,.0f}")
    ok &= check("detects dormant wallet wake", len(c.dormant_wakes) == 1,
                f"-> {c.dormant_wakes}")
    ok &= check("ignores recently-active wallet",
                not any("Active888" in w for w in c.dormant_wakes))
    ok &= check("caution flags against LONG on net inflow", c.caution_for("LONG"))
    ok &= check("no caution against SHORT on net inflow", not c.caution_for("SHORT"))
    ok &= check("transfers persisted for later backtesting",
                len(st2.transfers_df(symbol="SOLUSDT")) == 4,
                f"-> {len(st2.transfers_df(symbol='SOLUSDT'))} rows")

    st2.close()

    print("\n8. web layer (real HTTP server, no network)")
    import json as _json, threading as _th, time
    import urllib.request as _u, urllib.error as _ue
    _os.environ.setdefault("RADAR_DB", _os.path.join(tempfile.mkdtemp(), "api.db"))
    import radar.api as _api
    from http.server import ThreadingHTTPServer

    row = f.iloc[-1]
    b = _json.loads(_json.dumps(score_row(row)["blocks"], default=float))
    _api.svc.latest = {
        "generated_at": int(time.time() * 1000), "interval": "15m",
        "universe_size": 150, "derivatives_covered": 60, "elapsed_s": 41.2,
        "used_weight_1m": 352, "whale_events": [],
        "candidates": [{"symbol": "SOLUSDT", "price": float(row["close"]),
                        "direction": "LONG", "long_score": 71.3, "short_score": 28.7,
                        "conviction": 0.42, "agreement": 0.86, "coverage": 1.0,
                        "net": 0.42, "regime": "new longs", "funding": 0.0001,
                        "atr_pct": 0.009, "short_squeeze_score": 63.0,
                        "long_squeeze_score": 12.0,
                        "setup": setup_dict(build_setup(row, "LONG", 1.5)),
                        "blocks": b, "whale": None}]}
    _api.svc.status.update(state="ok",
                           last_ok_ms=_api.svc.latest["generated_at"], cycles=1)
    srv = ThreadingHTTPServer(("127.0.0.1", 8231), _api.Handler)
    srv.daemon_threads = True
    _th.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.4)

    def _get(path):
        try:
            with _u.urlopen("http://127.0.0.1:8231" + path) as r:
                return r.status, r.read().decode()
        except _ue.HTTPError as e:
            return e.code, e.read().decode()

    ok &= check("refuses to bind a public interface without a password",
                _refuses_public_bind())

    for path, exp in [("/", 200), ("/api/latest", 200), ("/api/symbol/SOLUSDT", 200),
                      ("/api/symbol/NOPEUSDT", 404), ("/api/whales", 200),
                      ("/api/history", 200), ("/nope", 404)]:
        code, _ = _get(path)
        ok &= check(f"GET {path}", code == exp, f"-> {code}")

    code, body = _get("/healthz")
    ok &= check("healthz reports fresh", code == 200 and not _json.loads(body)["stale"])
    _api.svc.status["last_ok_ms"] = int(time.time() * 1000) - 3_600_000
    code, body = _get("/healthz")
    ok &= check("healthz 503s when the scan loop stalls",
                code == 503 and _json.loads(body)["stale"], f"-> {code}")

    # --- auth
    _api.AUTH_PASS = "s3cret"
    code, _ = _get("/api/latest")
    ok &= check("401 without credentials once a password is set", code == 401, f"-> {code}")
    code, _ = _get("/healthz")
    ok &= check("healthz stays open for uptime monitors", code in (200, 503), f"-> {code}")

    import base64 as _b64
    def _get_auth(path, user="radar", pw="s3cret"):
        req = _u.Request("http://127.0.0.1:8231" + path)
        tok = _b64.b64encode(f"{user}:{pw}".encode()).decode()
        req.add_header("Authorization", "Basic " + tok)
        try:
            with _u.urlopen(req) as r:
                return r.status, r.read().decode()
        except _ue.HTTPError as e:
            return e.code, e.read().decode()

    code, _ = _get_auth("/api/latest")
    ok &= check("200 with correct credentials", code == 200, f"-> {code}")
    code, _ = _get_auth("/api/latest", pw="wrong")
    ok &= check("401 with wrong password", code == 401, f"-> {code}")
    code, _ = _get_auth("/api/latest", user="nope")
    ok &= check("401 with wrong user", code == 401, f"-> {code}")
    _api.AUTH_PASS = ""

    # --- strict JSON: browsers reject NaN/Infinity even though Python accepts them
    def _strict(txt):
        def boom(tok):
            raise ValueError(f"non-JSON token {tok!r} in response")
        return _json.loads(txt, parse_constant=boom)

    for path in ("/api/latest", "/api/symbol/SOLUSDT", "/api/whales", "/healthz"):
        code, body = _get(path)
        try:
            _strict(body)
            ok &= check(f"{path} is strictly valid JSON", True)
        except ValueError as e:
            ok &= check(f"{path} is strictly valid JSON", False, f"-> {e}")

    _, page = _get("/")
    ok &= check("dashboard renders with no external JS",
                "CONVICTION" in page and "<script" in page and "src=" not in page.split("<script")[1][:200])
    srv.shutdown()

    print("\n9. multi-timeframe analysis (offline)")
    from radar.analyze import (TIMEFRAMES, analyse_timeframe, narrate,
                               support_resistance)
    from radar.features import atr as _atr

    d = synth(600, seed=5)
    lv = support_resistance(d, _atr(d, 14))
    px = float(d["close"].iloc[-1])
    ok &= check("finds support/resistance levels", len(lv) > 0, f"-> {len(lv)}")
    ok &= check("levels sit on the correct side of price",
                all((x.price < px) == (x.kind == "support") for x in lv))
    ok &= check("strength bounded 0..1", all(0 <= x.strength <= 1 for x in lv))

    per = {}
    for tf in TIMEFRAMES:
        try:
            per[tf] = analyse_timeframe(synth(400, seed=abs(hash(tf)) % 997),
                                        tf, None, None, None)
        except Exception as e:                            # noqa: BLE001
            ok &= check(f"timeframe {tf}", False, f"-> {type(e).__name__}: {e}")
    ok &= check("every timeframe analyses cleanly", len(per) == len(TIMEFRAMES),
                f"-> {len(per)}/{len(TIMEFRAMES)}")
    ok &= check("bias always one of three values",
                all(p["bias"] in ("bullish", "bearish", "neutral") for p in per.values()))

    short = analyse_timeframe(synth(120, seed=3), "1M", None, None, None)
    ok &= check("EMA200 declared unavailable rather than faked",
                short["ema200"]["available"] is False and short["ema200"]["note"])

    nar = narrate("SOLUSDT", per, {"funding_rate": 0.0001, "oi_change_24h_pct": 4.2})
    ok &= check("narrative generated", len(nar["text"]) > 200, f"-> {len(nar['text'])} chars")
    ok &= check("verdict classified", nar["verdict"] in (
        "aligned_bullish", "aligned_bearish", "pullback_in_uptrend",
        "bounce_in_downtrend", "mixed"))

    print("\n10. challenge / paper trading (offline)")
    from radar.challenge import Challenge, RiskConfig

    class _Cli:
        def __init__(self): self.bars = {}
        def klines(self, sym, interval="1m", limit=500, **kw):
            return self.bars.get(sym, [])
        def funding_rate_history(self, *a, **k):
            return [{"fundingRate": "0.0001"}]

    def _bars(start_ms, rows):
        return [[start_ms + (i + 1) * 60000, str(o), str(h), str(l), str(cl), "10",
                 start_ms + (i + 1) * 60000 + 59999, "1000", 5, "5", "500", "0"]
                for i, (o, h, l, cl) in enumerate(rows)]

    cdb = _os.path.join(tempfile.mkdtemp(), "ch.db")
    cst = Store(cdb)
    cli = _Cli()
    cfg = RiskConfig(starting_equity=10000, risk_per_trade_pct=1.0,
                     cooldown_minutes_after_loss=0)
    ch = Challenge(cli, cst, cfg)
    t0 = int(time.time() * 1000) - 7200_000
    cand = {"symbol": "BTCUSDT", "direction": "LONG", "conviction": 0.42,
            "setup": {"entry": 100000.0, "stop": 99000.0}}

    pos = ch.maybe_open(cand, t0)
    ok &= check("opens a paper position", pos is not None)
    ok &= check("risks exactly 1% of equity", abs(pos.risk_amount - 100.0) < 1.0,
                f"-> ${pos.risk_amount:.2f}")
    ok &= check("size derived from stop distance, not chosen first",
                abs(pos.qty * pos.r_per_unit - pos.risk_amount) < 0.01)
    ok &= check("fill is worse than the signal price", pos.entry > 100000.0)
    ok &= check("rejects a second position in the same symbol",
                not ch.can_open("BTCUSDT", t0)[0])
    ok &= check("rejects symbols outside BTC/ETH",
                not ch.can_open("SOLUSDT", t0)[0])

    rr = pos.r_per_unit
    cli.bars["BTCUSDT"] = _bars(t0, [
        (pos.entry, pos.entry + rr * 1.05, pos.entry - rr * 0.2, pos.entry + rr),
        (pos.entry + rr, pos.entry + rr * 0.5, pos.entry - 0.01, pos.entry)])
    done = ch.manage(t0 + 300000)
    ok &= check("partial at 1R then breakeven stop", len(done) == 1,
                f"-> {[d.outcome for d in done]}")
    ok &= check("breakeven exit nets positive after the partial", done[0].net_pnl > 0,
                f"-> ${done[0].net_pnl:.2f}")
    ok &= check("fees and funding charged",
                done[0].fees > 0 and abs(done[0].funding) > 0)

    ch.blocked_until_ms = 0
    p2 = ch.maybe_open(cand, t0 + 600000)
    r2 = p2.r_per_unit
    cli.bars["BTCUSDT"] = _bars(t0 + 600000,
                                [(p2.entry, p2.entry + r2 * 3, p2.stop - 1, p2.entry)])
    d2 = ch.manage(t0 + 900000)
    ok &= check("bar covering both barriers scores as the stop",
                d2 and d2[0].outcome == "stop", f"-> {d2[0].outcome}")
    ok &= check("cooldown engages after a loss", ch.blocked_until_ms > 0)

    # Day so far: +0.45R then -1.05R. Still inside the -2R limit, so trading
    # must continue -- a limit that fires early is as wrong as one that never does.
    ch.blocked_until_ms = 0
    day = ch._today_stats()["realised_r"]
    allowed, why = ch.can_open("BTCUSDT", int(time.time() * 1000))
    ok &= check("still trading while inside the daily limit",
                allowed and day > -cfg.daily_loss_limit_r, f"-> day {day:+.2f}R")

    # now push it past the limit and confirm it stops
    p3 = ch.maybe_open(cand, t0 + 1_200_000)
    r3 = p3.r_per_unit
    cli.bars["BTCUSDT"] = _bars(t0 + 1_200_000,
                                [(p3.entry, p3.entry + r3 * .2, p3.stop - 1, p3.stop)])
    ch.manage(t0 + 1_500_000)
    ch.blocked_until_ms = 0
    day = ch._today_stats()["realised_r"]
    # Tighten the limit to just above where the day actually sits, so the
    # boundary itself is under test rather than the size of the losses.
    ch.cfg.daily_loss_limit_r = abs(day) - 0.1
    allowed, why = ch.can_open("BTCUSDT", int(time.time() * 1000))
    ok &= check("daily loss limit halts trading once crossed", not allowed,
                f"-> day {day:+.2f}R vs limit -{ch.cfg.daily_loss_limit_r:.2f}R, {why}")
    ch.cfg.daily_loss_limit_r = cfg.daily_loss_limit_r

    snap = ch.snapshot({"BTCUSDT": 100500.0})
    ok &= check("stats and equity curve produced",
                snap["trades_total"] == 3 and len(snap["equity_curve"]) == 3,
                f"-> {snap['trades_total']} trades")
    ok &= check("small sample is flagged, not glossed over",
                any(w in snap["confidence_note"].lower() for w in ("too few", "noise")))
    ch2 = Challenge(_Cli(), Store(cdb), cfg)
    ok &= check("state survives a restart", abs(ch2.equity - ch.equity) < 0.01)
    cst.close()

    print("\n11. signal track record + on-chain feed (offline)")
    from radar.track import replay
    from radar.news import build_feed

    rep = replay(synth(1200, seed=7), "15m", min_conviction=0.12, want=10)
    ok &= check("replays past signals", len(rep["signals"]) > 0, f"-> {len(rep['signals'])}")
    ok &= check("returns at most the requested count", len(rep["signals"]) <= 10)
    stt = rep["stats"]
    ok &= check("TP1+ hit rate computed", stt["tp1_or_better_pct"] is not None,
                f"-> TP1+ {stt['tp1_or_better_pct']}%, TP2+ {stt['tp2_or_better_pct']}%")
    ok &= check("TP2+ can never exceed TP1+",
                stt["tp2_or_better_pct"] <= stt["tp1_or_better_pct"])
    ok &= check("TP3 can never exceed TP2+", stt["tp3_pct"] <= stt["tp2_or_better_pct"])
    ok &= check("unresolved signals excluded from the hit rate",
                stt["resolved"] + stt["unresolved"] == len(rep["signals"]))
    ok &= check("newest signal listed first",
                rep["signals"][0]["time"] >= rep["signals"][-1]["time"])

    rr = [replay(synth(1200, seed=200 + i), "15m", min_conviction=0.12)["stats"]["avg_r"]
          for i in range(5)]
    rr = [x for x in rr if x is not None]
    ok &= check("no free lunch replaying random walks",
                float(np.mean(rr)) < 0.35, f"-> {np.mean(rr):+.2f}R")

    ndb = Store(_os.path.join(tempfile.mkdtemp(), "news.db"))
    tnow = int(time.time() * 1000)
    for row in [("0xa", tnow - 3.6e6, "SOLUSDT", "SOL", 12e6, "exchange_in",
                 None, "Binance", "W1", "B1"),
                ("0xb", tnow - 7.2e6, "SOLUSDT", "SOL", 3e6, "exchange_out",
                 "Binance", None, "B1", "W2")]:
        ndb.record_transfer(row[0], int(row[1]), *row[2:])
    feed = build_feed(ndb, hours=24, min_usd=1e6, enabled=True)
    ok &= check("flow feed groups by coin", len(feed["by_symbol"]) == 1)
    sol = feed["by_symbol"][0]
    ok &= check("net exchange flow computed", sol["net_to_exchange_usd"] == 9e6,
                f"-> {sol['net_to_exchange_usd']:,.0f}")
    ok &= check("interpretation hedges rather than overclaims",
                "not the same as" in sol["text"])
    ok &= check("flow states it is kept out of the score",
                "cannot be backtested" in feed["note"])
    paused = build_feed(ndb, hours=24, min_usd=1e6, enabled=False)
    ok &= check("recorded data still shown when collection is paused",
                len(paused["by_symbol"]) == 1 and paused["collecting"] is False)
    ndb.close()

    print("\n12. pump candidates + track record (offline)")
    from radar.pump import (build_watchlist, record_calls, score_pump,
                            track_record)

    def _prow(sq, oi4, ret4, volz, fz, tls, rs4, rs24, liq):
        return pd.Series({"close": 100.0, "bb_squeeze_pctile": sq,
                          "atr_expansion": 0.8, "oi_chg_4h": oi4, "ret_4h": ret4,
                          "vol_z": volz, "cvd_slope_4h": 0.05, "funding_z_7d": fz,
                          "funding": fz * 1e-4, "taker_ls_ratio": tls,
                          "rs_4h": rs4, "rs_24h": rs24, "liq_up_dist": liq,
                          "vwap_dist": 0.004})

    coiled_flat = score_pump(_prow(0.02, .05, .001, 2.5, 0.0, 1.0, 0.0, 0.0, 0.0))
    coiled_up = score_pump(_prow(0.02, .05, .001, 2.5, -2.5, 1.35, .03, -.04, .09))
    loose_up = score_pump(_prow(0.95, 0.0, .04, 0.0, -2.5, 1.35, .03, -.04, .09))

    ok &= check("energy is direction-blind",
                abs(coiled_flat["energy"] - coiled_up["energy"]) < 1.0,
                f"-> {coiled_flat['energy']} vs {coiled_up['energy']}")
    ok &= check("compression without direction scores near zero",
                coiled_flat["pump_score"] < 20, f"-> {coiled_flat['pump_score']}")
    ok &= check("same energy plus lean scores far higher",
                coiled_up["pump_score"] > 3 * coiled_flat["pump_score"],
                f"-> {coiled_up['pump_score']} vs {coiled_flat['pump_score']}")
    ok &= check("lean without compression scores lower than both",
                loose_up["pump_score"] < coiled_up["pump_score"])
    ok &= check("liquidation cluster labelled as modelled, not a feed",
                "not a liquidation feed" in
                coiled_up["estimated_liq_cluster"]["basis"])
    ok &= check("caveat states compression is directionless",
                "not direction" in coiled_up["caveat"])

    pdb = Store(_os.path.join(tempfile.mkdtemp(), "pump.db"))
    wl = build_watchlist({"AAAUSDT": _prow(0.02, .05, .001, 2.5, -2.5, 1.35,
                                           .03, -.04, .09)}, min_score=0.0)
    pnow = int(time.time() * 1000)
    ok &= check("calls recorded before the outcome exists",
                record_calls(pdb, wl, pnow) == 1)
    ok &= check("no duplicate call inside the recall window",
                record_calls(pdb, wl, pnow + 3_600_000) == 0)
    rec0 = track_record(pdb)
    ok &= check("claims nothing before calls mature",
                rec0["resolved"] == 0 and "nothing here means anything" in rec0["verdict"])

    for i in range(20):
        pdb.record_pump_call({"ts": pnow - 300 * 3600_000 + i * 1000,
                              "symbol": f"Z{i}USDT", "price_at_call": 100,
                              "pump_score": 55, "energy": 70, "lean": 50,
                              "target_pct": 15.0, "horizon_ms": 168 * 3600_000,
                              "reasons": "t"})
        pdb.resolve_pump_call(pnow - 300 * 3600_000 + i * 1000, f"Z{i}USDT",
                              {"resolved_ms": pnow,
                               "max_gain_pct": 21.0 if i < 5 else 6.0,
                               "max_drawdown_pct": -9.0, "hours_to_peak": 40,
                               "final_pct": 8.0, "hit": 1 if i < 5 else 0,
                               "base_rate_pct": 24.0})
    rec = track_record(pdb)
    ok &= check("hit rate and base rate both reported",
                rec["hit_rate_pct"] == 25.0 and rec["base_rate_pct"] == 24.0,
                f"-> {rec['hit_rate_pct']}% vs {rec['base_rate_pct']}%")
    ok &= check("a screen matching the base rate is called out as useless",
                "not adding information" in rec["verdict"] or
                "worse than random" in rec["verdict"],
                f"-> edge {rec['edge_vs_base_rate']:+}")
    pdb.close()

    print("\n13. trade notifications (offline)")
    edb = Store(_os.path.join(tempfile.mkdtemp(), "ev.db"))
    ech = Challenge(_Cli(), edb, RiskConfig(cooldown_minutes_after_loss=0))
    e0 = int(time.time() * 1000) - 3600_000
    ecand = {"symbol": "BTCUSDT", "direction": "LONG", "conviction": 0.42,
             "setup": {"entry": 100000.0, "stop": 99000.0}}
    ep = ech.maybe_open(ecand, e0)
    evs = edb.events_since(0)
    ok &= check("opening a trade emits an event",
                len(evs) == 1 and evs[0]["kind"] == "open")
    ok &= check("open event carries the levels and the risk",
                "Entry" in evs[0]["body"] and "risking $" in evs[0]["body"])

    er = ep.r_per_unit
    ech.cli.bars["BTCUSDT"] = _bars(e0, [
        (ep.entry, ep.entry + er * 1.05, ep.entry - er * .2, ep.entry + er),
        (ep.entry + er, ep.entry + er * .5, ep.entry - 0.01, ep.entry)])
    ech.manage(e0 + 300000)
    later = edb.events_since(evs[0]["id"])
    kinds = [e["kind"] for e in later]
    ok &= check("partial and close both emit events",
                kinds == ["partial", "close"], f"-> {kinds}")
    ok &= check("partial explains the breakeven move",
                "breakeven" in later[0]["body"])
    ok &= check("close reports R and resulting equity",
                "R)" in later[1]["title"] and "Equity now" in later[1]["body"])
    ok &= check("cursor returns nothing once caught up",
                edb.events_since(edb.latest_event_id()) == [])
    ok &= check("notification failure cannot break a trade",
                ep is not None and ech.equity != 10000)
    edb.close()

    print("\n14. disclaimers")
    import re as _re
    _page = open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),
                               "web", "index.html")).read()
    _flat = _re.sub(r"\s+", " ", _page)
    for _p in ["educational purposes only",
               "No responsibility is accepted for any losses",
               "not financial advice", "more than you deposit"]:
        ok &= check(f"banner states {_p!r}", _p.lower() in _flat.lower())
    ok &= check("banner is never hidden", 'id="disclaimer" hidden' not in _page)
    ok &= check("appended to every tab", _page.count("+ LEGAL") >= 5,
                f"-> {_page.count('+ LEGAL')}")
    from radar.api import ScannerService as _SS
    ok &= check("API payloads carry it",
                "educational" in _SS.DISCLAIMER.lower()
                and "no responsibility" in _SS.DISCLAIMER.lower())

    print("\n15. two challenges side by side (offline)")
    import sqlite3 as _sq
    from radar.challenge import SCALP, SWING

    ok &= check("scalp caps at 5 trades a day", SCALP.max_trades_per_day == 5)
    ok &= check("scalp reads a faster chart than swing",
                SCALP.timeframe == "5m" and SWING.timeframe == "15m")
    ok &= check("scalp risks less per trade",
                SCALP.risk_per_trade_pct < SWING.risk_per_trade_pct,
                f"-> {SCALP.risk_per_trade_pct}% vs {SWING.risk_per_trade_pct}%")
    ok &= check("scalp worst-case daily risk stays bounded",
                SCALP.risk_per_trade_pct * SCALP.max_trades_per_day <= 3.0,
                f"-> {SCALP.risk_per_trade_pct * SCALP.max_trades_per_day}%/day")
    ok &= check("scalp holds hours, swing holds a day",
                SCALP.max_hold_hours < SWING.max_hold_hours)

    # a pre-existing single-challenge database must survive the upgrade
    old = _os.path.join(tempfile.mkdtemp(), "old.db")
    _c = _sq.connect(old)
    _c.executescript("""
        CREATE TABLE challenge_state (id INTEGER PRIMARY KEY CHECK (id=1),
          equity REAL, peak_equity REAL, blocked_until_ms INTEGER, updated_ms INTEGER);
        INSERT INTO challenge_state VALUES (1, 10450.25, 10500.0, 0, 1);
        CREATE TABLE challenge_trades (opened_ms INTEGER NOT NULL,
          closed_ms INTEGER NOT NULL, symbol TEXT, direction TEXT, entry REAL,
          exit REAL, initial_stop REAL, qty REAL, gross_pnl REAL, fees REAL,
          funding REAL, net_pnl REAL, r_multiple REAL, outcome TEXT,
          conviction REAL, equity_after REAL, PRIMARY KEY (opened_ms, symbol));
        INSERT INTO challenge_trades VALUES
          (1,2,'BTCUSDT','LONG',100,101,99,1,1,0.1,0,0.9,0.9,'tp2',0.4,10450.25);
    """)
    _c.commit(); _c.close()
    _st = Store(old)
    ok &= check("migration preserves equity",
                abs(_st.challenge_state("main")["equity"] - 10450.25) < 0.01)
    ok &= check("migration preserves trade history",
                len(_st.challenge_trades(name="main")) == 1)
    ok &= check("new challenge starts from scratch",
                _st.challenge_state("scalp") is None
                and _st.challenge_trades(name="scalp") == [])
    _st.save_challenge_state(9800.0, 10000.0, 0, "scalp")
    ok &= check("the two accounts never mix",
                _st.challenge_state("main")["equity"] == 10450.25
                and _st.challenge_state("scalp")["equity"] == 9800.0)

    _c1 = Challenge(_Cli(), _st, SWING, "main")
    _c2 = Challenge(_Cli(), _st, SCALP, "scalp")
    _t = int(time.time() * 1000) - 3600_000
    _cd = {"symbol": "BTCUSDT", "direction": "LONG", "conviction": 0.42,
           "setup": {"entry": 100000.0, "stop": 99000.0}}
    _p1, _p2 = _c1.maybe_open(_cd, _t), _c2.maybe_open(_cd, _t)
    ok &= check("both hold the same symbol independently", _p1 and _p2)
    ok &= check("scalp takes the smaller position",
                _p2.risk_amount < _p1.risk_amount,
                f"-> ${_p2.risk_amount:.2f} vs ${_p1.risk_amount:.2f}")
    _st.close()

    print("\n16. correlated-risk gate (offline)")
    import math as _m
    from radar.challenge import _max_addable_risk

    # the sizing maths
    for _ex, _rho, _bud in [(100, 0.9, 120), (100, 0.0, 120), (100, 0.5, 150)]:
        _x = _max_addable_risk(_ex, _rho, _bud)
        _c = _m.sqrt(_ex ** 2 + _x ** 2 + 2 * _rho * _ex * _x)
        ok &= check(f"sizing solves the budget (existing ${_ex}, r={_rho})",
                    abs(_c - _bud) < 0.01, f"-> add ${_x:.2f}, combined ${_c:.2f}")
    ok &= check("nothing open means the full budget is available",
                _max_addable_risk(0, 0.9, 120) == 120)

    def _corr_series(n, seed, base=None, rho=0.9):
        _r = np.random.default_rng(seed)
        b = _r.normal(0, 0.01, n)
        if base is not None:
            b = rho * base + np.sqrt(max(0, 1 - rho ** 2)) * _r.normal(0, 0.01, n)
        return 100 * np.exp(np.cumsum(b)), b

    class _CorrCli:
        def __init__(self, rho):
            self.bars = {}
            pa, ra = _corr_series(200, 1)
            pb, _ = _corr_series(200, 2, base=ra, rho=rho)
            self.hourly = {"BTCUSDT": pa, "ETHUSDT": pb}
        def klines(self, sym, interval="1m", limit=500, **kw):
            if interval == "1h":
                p = self.hourly.get(sym)
                return None if p is None else [
                    [i * 3600000, str(v), str(v), str(v), str(v), "10",
                     i * 3600000 + 1, "100", 5, "5", "50", "0"]
                    for i, v in enumerate(p)]
            return self.bars.get(sym, [])
        def funding_rate_history(self, *a, **k):
            return [{"fundingRate": "0.0001"}]

    def _mk(rho, budget):
        return Challenge(
            _CorrCli(rho), Store(_os.path.join(tempfile.mkdtemp(), "c.db")),
            RiskConfig(starting_equity=10000, risk_per_trade_pct=1.0,
                       max_correlated_risk_pct=budget, correlation_threshold=0.6,
                       cooldown_minutes_after_loss=0), "t")

    _n = int(time.time() * 1000) - 3600_000
    _B = {"symbol": "BTCUSDT", "direction": "LONG", "conviction": 0.4,
          "setup": {"entry": 100000., "stop": 99000.}}
    _E = {"symbol": "ETHUSDT", "direction": "LONG", "conviction": 0.4,
          "setup": {"entry": 3000., "stop": 2970.}}

    # the invariant, wherever the pair IS correlated
    for _bud in (1.0, 1.2, 1.5, 2.0):
        _ch = _mk(0.92, _bud)
        _rho = _ch.correlation("BTCUSDT", "ETHUSDT")
        _p1, _p2 = _ch.maybe_open(_B, _n), _ch.maybe_open(_E, _n)
        _r1 = _p1.risk_amount if _p1 else 0.0
        _r2 = _p2.risk_amount if _p2 else 0.0
        _comb = (_m.sqrt(_r1 ** 2 + _r2 ** 2 + 2 * _rho * _r1 * _r2)
                 if (_r1 and _r2) else max(_r1, _r2))
        ok &= check(f"combined cluster risk within budget at {_bud}%",
                    _comb <= 10000 * _bud / 100 + 1.0,
                    f"-> ${_comb:.2f} of ${10000 * _bud / 100:.0f}"
                    + (" (2nd declined)" if _p2 is None else f", 2nd ${_r2:.0f}"))

    _ch = _mk(0.92, 1.2)
    ok &= check("measured correlation, not assumed",
                _ch.correlation("BTCUSDT", "ETHUSDT") > 0.7)
    _ch.maybe_open(_B, _n)
    _hedge = _ch.maybe_open({**_E, "direction": "SHORT",
                             "setup": {"entry": 3000., "stop": 3030.}}, _n)
    ok &= check("opposite direction never penalised — a hedge is not a cluster",
                _hedge and abs(_hedge.risk_amount - 100) < 1)

    _ch2 = _mk(0.05, 1.2)
    _ch2.maybe_open(_B, _n)
    _ind = _ch2.maybe_open(_E, _n)
    ok &= check("uncorrelated pair both trade full size — the cluster cap "
                "governs correlated positions only",
                _ind and abs(_ind.risk_amount - 100) < 1,
                f"-> r={_ch2.correlation('BTCUSDT', 'ETHUSDT'):.2f}")

    _ch3 = _mk(0.92, 1.2)
    _pa = _ch3.maybe_open(_B, _n)
    _pa.stop, _pa.partial_done = _pa.entry, True
    _used, _, _ = _ch3.correlated_risk("ETHUSDT", "LONG")
    ok &= check("a breakeven stop frees the budget it was holding", _used == 0)
    ok &= check("and full size becomes available again",
                (lambda x: x and abs(x.risk_amount - 100) < 1)(_ch3.maybe_open(_E, _n)))

    print("\n17. hyperliquid: book veto + public positions (offline)")
    from radar.hyperliquid import (BookRead, CoinPositioning, HyperliquidClient,
                                   WhaleWatcher, read_book, to_hl_coin)
    from radar.challenge import SCALP as _SCALP, SWING as _SWING
    from radar.pump import score_pump as _sp

    ok &= check("symbol mapping", to_hl_coin("BTCUSDT") == "BTC"
                and to_hl_coin("HYPE") == "HYPE")

    def _bk(bids, asks, mid=100000.0, tick=10.0):
        return {"levels": [
            [{"px": str(mid - tick * (i + 1)), "sz": str(v)} for i, v in enumerate(bids)],
            [{"px": str(mid + tick * (i + 1)), "sz": str(v)} for i, v in enumerate(asks)]]}

    _bid = read_book("BTC", _bk([2, 2, 2, 2], [0.4, 0.4, 0.4, 0.4]))
    _ask = read_book("BTC", _bk([0.4, 0.4, 0.4, 0.4], [2, 2, 2, 2]))
    _bal = read_book("BTC", _bk([1, 1, 1, 1], [1, 1, 1, 1]))
    _thin = read_book("BTC", _bk([0.0001], [0.02]))
    ok &= check("bid-heavy book reads positive", _bid.imbalance > 0.4)
    ok &= check("it vetoes a short but not a long",
                _bid.vetoes("SHORT") and not _bid.vetoes("LONG"))
    ok &= check("ask-heavy book vetoes a long but not a short",
                _ask.vetoes("LONG") and not _ask.vetoes("SHORT"))
    ok &= check("balanced book vetoes nothing",
                not _bal.vetoes("LONG") and not _bal.vetoes("SHORT"))
    ok &= check("thin book flagged and never vetoes",
                _thin.thin and not _thin.vetoes("LONG") and not _thin.vetoes("SHORT"),
                f"-> imbalance {_thin.imbalance} ignored")
    ok &= check("malformed book returns None",
                read_book("BTC", {"levels": [[], []]}) is None)

    class _HL:
        def __init__(self, imb, thin=False): self.imb, self.thin = imb, thin
        def book(self, sym):
            return BookRead("BTC", 100000., 1.0, 5e5, 5e5, self.imb, self.imb, self.thin)

    class _Broken:
        def book(self, sym): raise RuntimeError("hyperliquid unreachable")

    def _mkc(hl, veto):
        return Challenge(_Cli(), Store(_os.path.join(tempfile.mkdtemp(), "h.db")),
                         RiskConfig(cooldown_minutes_after_loss=0,
                                    use_book_veto=veto, min_conviction=0.18),
                         "scalp", hyperliquid=hl)
    _n2 = int(time.time() * 1000) - 3600_000
    _B2 = {"symbol": "BTCUSDT", "direction": "LONG", "conviction": 0.4,
           "setup": {"entry": 100000., "stop": 99000.}}
    ok &= check("veto on for scalps, off for swings",
                _SCALP.use_book_veto and not _SWING.use_book_veto)
    ok &= check("heavily offered book blocks the long",
                _mkc(_HL(-0.6), True).maybe_open(_B2, _n2) is None)
    ok &= check("supportive book lets it through",
                _mkc(_HL(0.5), True).maybe_open(_B2, _n2) is not None)
    ok &= check("thin book never blocks",
                _mkc(_HL(-0.95, True), True).maybe_open(_B2, _n2) is not None)
    ok &= check("swing ignores the book",
                _mkc(_HL(-0.9), False).maybe_open(_B2, _n2) is not None)
    ok &= check("a Hyperliquid outage cannot stop trading",
                _mkc(_Broken(), True).maybe_open(_B2, _n2) is not None)

    _cp = CoinPositioning("BTC", long_usd=8e6, short_usd=2e6, n_long=3,
                          n_short=1, wallets_seen=6)
    ok &= check("skew and lean computed",
                abs(_cp.skew - 0.6) < 0.01 and _cp.lean() > 0.5)
    ok &= check("holding nothing reads neutral", CoinPositioning("BTC").lean() == 0.5)

    class _FC(HyperliquidClient):
        def __init__(self): super().__init__(); self.enabled = True
        def clearinghouse_state(self, a):
            return ({"assetPositions": [
                {"position": {"coin": "BTC", "szi": "1.5", "positionValue": "150000"}},
                {"position": {"coin": "ETH", "szi": "-40", "positionValue": "120000"}}]}
                if a == "0xaaa" else None)
    _w = WhaleWatcher(_FC(), ["0xaaa"])
    _pos = _w.positions_by_coin()
    ok &= check("positions aggregated per coin",
                _pos["BTC"].long_usd == 150000 and _pos["ETH"].short_usd == 120000)
    ok &= check("watchlist required to enable", not WhaleWatcher(_FC(), []).enabled)

    _prow = pd.Series({"close": 100., "bb_squeeze_pctile": 0.05, "atr_expansion": .75,
                       "oi_chg_4h": .045, "ret_4h": .002, "vol_z": 2.2,
                       "cvd_slope_4h": .06, "funding_z_7d": -2.2, "funding": -0.00022,
                       "taker_ls_ratio": 1.3, "rs_4h": .028, "rs_24h": -.03,
                       "liq_up_dist": .085, "vwap_dist": .004})
    _no = _sp(_prow)
    _lg = _sp(_prow, hl_positioning={"wallets_seen": 8, "lean": 0.9, "describe": "x"})
    _sh = _sp(_prow, hl_positioning={"wallets_seen": 8, "lean": 0.1, "describe": "y"})
    ok &= check("whales long lean higher than whales short",
                _lg["lean"] > _sh["lean"], f"-> {_lg['lean']} vs {_sh['lean']}")
    ok &= check("a configured watchlist raises coverage",
                _lg["coverage"] > _no["coverage"],
                f"-> {_lg['coverage']} vs {_no['coverage']}")

    print(f"\n{'ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED'}\n")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
